import React from 'react';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import {NavigationContainer} from '@react-navigation/native';
import Login from './src/screens/Login';
import Home from './src/screens/Home Screen/Home';
import ProjectTarget from './src/screens/ProjectTarget/ProjectTarget';
import AddProjectTarget from './src/screens/ProjectTarget/AddProjectTarget';
import ClientAgreementMaster from './src/screens/Client Agreement Master/ClientAgreementMaster';
import AddClientAgreement from './src/screens/Client Agreement Master/AddClientAgreement';
import AccountMaster from './src/screens/Account Master/AccountMaster';
import AddAccountant from './src/screens/Account Master/AddAccountant';
import TechnologyMaster from './src/screens/Technology Master/TechnologyMaster';
import AddTechnology from './src/screens/Technology Master/AddTechnology';
import InvoiceHistory from './src/screens/InvoiceHistory';
import CompareReport from './src/screens/Compare Report/CompareReport';
import ResourceMaster from './src/screens/Resource/ResourceMaster';
import AddResource from './src/screens/Resource/AddResource';
import ExternalResourcesMaster from './src/screens/External Resources/ExternalResourcesMaster';
import AddExternalResource from './src/screens/External Resources/AddExternalResource';
import ExternalProductMaster from './src/screens/External Product/ExternalProductMaster';
import AddExternalProduct from './src/screens/External Product/AddExternalProduct';
import PurchaseOrderMaster from './src/screens/Purchase Order/PurchaseOrderMaster';
import AddPurchaseOrder from './src/screens/Purchase Order/AddPurchaseOrder';
import DrawerNav from './src/components/DrawerNav';
import ForgotPassword from './src/screens/ForgotPassword';
import EditScreen from './src/screens/Account Master/EditScreen';
import Vendor from './src/screens/Vendor Master/Vendor';
import AddVendor from './src/screens/Vendor Master/AddVendor';
import UserSetting from './src/screens/User Setting/UserSetting';
import ClientRequest from './src/screens/Client Request/ClientRequest';
import EditTechnology from './src/screens/Technology Master/EditTechnology';
import EditExternalProduct from './src/screens/External Product/EditExternalProduct';
import EditPurchaseOrder from './src/screens/Purchase Order/EditPurchase';
import EditProjectTarget from './src/screens/ProjectTarget/EditProjectTarget';
import EditClientAgreement from './src/screens/Client Agreement Master/EditClientAgreement';
import EditExternalResource from './src/screens/External Resources/EditExternalResource';
import EditResource from './src/screens/Resource/EditResource';
import EditVendor from './src/screens/Vendor Master/EditVendor';
import AddUserSetting from './src/screens/User Setting/AddUserSetting';
import UpdateModal from './src/screens/Client Request/UpdateModal';
import EditUserSetting from './src/screens/User Setting/Edit UserSetting';
import ClientMaster from './src/screens/Client Master/ClientMaster';
import Setting from './src/screens/Setting Master/Setting';
import EditSetting from './src/screens/Setting Master/EditSetting';
import AddClient from './src/screens/Client Master/AddClient';
import EditClient from './src/screens/Client Master/EditClient';
import ViewModal from './src/screens/ProjectTarget/Viewmodal';
import Interview from './src/screens/Interview/Interview';
import AddInterview from './src/screens/Interview/AddInterview';
import ExternalInterview from './src/screens/External Interview/ExternalInterview';
import AddExternalInterview from './src/screens/External Interview/AddExternalInterview';
import JoiningScreen from './src/screens/Joining Screen/JoiningScreen';
import AddJoiningScreen from './src/screens/Joining Screen/AddJoiningScreen';
import LeavingScreen from './src/screens/Leaving Screen/LeavingScreen';
import AddLeavingScreen from './src/screens/Leaving Screen/AddLeavingScreen';
import NonJoiningScreen from './src/screens/NonJoining Screen/NonJoining';
import AddNonJoiningScreen from './src/screens/NonJoining Screen/AddNonJoiningScreen';
import EditLeavingScreen from './src/screens/Leaving Screen/EditLeavingScreen';
import AllInterview from './src/screens/All Interview/AllInterview';
import AddAllInterview from './src/screens/All Interview/AddAllInterview';
import EditExternalInterview from './src/screens/External Interview/EditExternalInterview';
import EditInterview from './src/screens/Interview/EditInterview';
import ExternalInterviewReport from './src/screens/External Interview Report/ExternalInterviewReport';
import InternalInterviewReport from './src/screens/Internal Interview Report/InternalInterviewReport';
import ExternalScreen from './src/screens/Compare Report/ExternalScreen';
import CurrentScreen from './src/screens/Home Screen/CurrentScreen';
import ExternalScreenH from './src/screens/Home Screen/ExternalScreenH';
import ProjectScreenH from './src/screens/Home Screen/ProjectScreenH';
import UpcomingScreen from './src/screens/Home Screen/UpcomingScreen';
import InternalScreen from './src/screens/Compare Report/InternalScreen';
import InvoiceStatus from './src/screens/Invoice Status/InvoiceStatus';
import TableScreen from './src/screens/Invoice Status/TableScreen';
import TableModal from './src/screens/Invoice Status/TableModal';
const Stack = createNativeStackNavigator();

const App = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator
        initialRouteName="LoginScreen"
        initialRouteName="Drawer Nav"
        screenOptions={{
          headerShown: false,
        }}>
        <Stack.Screen name="LoginScreen" component={Login} />
        <Stack.Screen name="Drawer Nav" component={DrawerNav} />

        <Stack.Screen name="ForgotPasswordScreen" component={ForgotPassword} />
        <Stack.Screen name="HomeScreen" component={Home} />
        <Stack.Screen name="CurrentScreen" component={CurrentScreen} />
        <Stack.Screen name="ExternalScreenH" component={ExternalScreenH} />
        <Stack.Screen name="ProjectScreenH" component={ProjectScreenH} />
        <Stack.Screen name="UpcomingScreen" component={UpcomingScreen} />
        <Stack.Screen name="ViewModal" component={ViewModal} />
        <Stack.Screen name="ProjectScreen" component={ProjectTarget} />
        <Stack.Screen name="AddProjectScreen" component={AddProjectTarget} />
        <Stack.Screen
          name="ClientAgreementMasterScreen"
          component={ClientAgreementMaster}
        />
        <Stack.Screen
          name="AddClientAgreementScreen"
          component={AddClientAgreement}
        />
        <Stack.Screen name="AccountMasterScreen" component={AccountMaster} />
        <Stack.Screen name="AddAccountantScreen" component={AddAccountant} />
        <Stack.Screen
          name="TechnologyMasterScreen"
          component={TechnologyMaster}
        />
        <Stack.Screen name="AddTechnologyScreen" component={AddTechnology} />

        <Stack.Screen name="Invoice History" component={InvoiceHistory} />
        <Stack.Screen name="Invoice Status" component={InvoiceStatus} />
        <Stack.Screen name="Table Screen" component={TableScreen} />
        <Stack.Screen name="Table Modal" component={TableModal} />
        <Stack.Screen name="Compare Report" component={CompareReport} />
        <Stack.Screen name="ExternalScreen" component={ExternalScreen} />
        <Stack.Screen name="InternalScreen" component={InternalScreen} />

        <Stack.Screen name="Resource Master" component={ResourceMaster} />
        <Stack.Screen name="Add Resource" component={AddResource} />
        <Stack.Screen name="Interview" component={Interview} />
        <Stack.Screen name="Add Interview" component={AddInterview} />
        <Stack.Screen name="Edit Interview" component={EditInterview} />
        <Stack.Screen name="Joining Screen" component={JoiningScreen} />
        <Stack.Screen name="Add Joining Screen" component={AddJoiningScreen} />
        <Stack.Screen name="Leaving Screen" component={LeavingScreen} />
        <Stack.Screen name="Add Leaving Screen" component={AddLeavingScreen} />
        <Stack.Screen
          name="Edit Leaving Screen"
          component={EditLeavingScreen}
        />
        <Stack.Screen name="NonJoining Screen" component={NonJoiningScreen} />
        <Stack.Screen name="Add NonJoining" component={AddNonJoiningScreen} />
        <Stack.Screen name="All Interview" component={AllInterview} />
        <Stack.Screen name="Add All Interview" component={AddAllInterview} />
        <Stack.Screen
          name=" External Interview Report"
          component={ExternalInterviewReport}
        />
        <Stack.Screen
          name=" Internal Interview Report"
          component={InternalInterviewReport}
        />
        <Stack.Screen
          name=" External Interview"
          component={ExternalInterview}
        />
        <Stack.Screen
          name="Add External Interview"
          component={AddExternalInterview}
        />
        <Stack.Screen
          name="Edit External Interview"
          component={EditExternalInterview}
        />
        <Stack.Screen
          name="External Resources Master"
          component={ExternalResourcesMaster}
        />
        <Stack.Screen
          name="Add External Resource"
          component={AddExternalResource}
        />
        <Stack.Screen
          name="External Product Master"
          component={ExternalProductMaster}
        />
        <Stack.Screen
          name="Add External Product"
          component={AddExternalProduct}
        />
        <Stack.Screen
          name="Purchase Order Master"
          component={PurchaseOrderMaster}
        />
        <Stack.Screen name="Add Purchase Order" component={AddPurchaseOrder} />
        <Stack.Screen name="Edit Screen" component={EditScreen} />
        <Stack.Screen name=" Vendor Master" component={Vendor} />
        <Stack.Screen name="AddVendor" component={AddVendor} />

        <Stack.Screen name=" User Setting" component={UserSetting} />
        <Stack.Screen name="Client Request" component={ClientRequest} />
        <Stack.Screen name="Edit Technology" component={EditTechnology} />
        <Stack.Screen
          name="Edit ExternalProduct"
          component={EditExternalProduct}
        />
        <Stack.Screen
          name="Edit Purchase Order"
          component={EditPurchaseOrder}
        />
        <Stack.Screen
          name="Edit Project Target"
          component={EditProjectTarget}
        />
        <Stack.Screen
          name="Edit Client Agreenent"
          component={EditClientAgreement}
        />

        <Stack.Screen
          name="Edit External Resource"
          component={EditExternalResource}
        />

        <Stack.Screen name="Edit Resource" component={EditResource} />
        <Stack.Screen name="Edit Vendor" component={EditVendor} />
        <Stack.Screen name="Add UserSetting" component={AddUserSetting} />
        <Stack.Screen name="Edit UserSetting" component={EditUserSetting} />
        <Stack.Screen name="UpdateModal" component={UpdateModal} />
        <Stack.Screen name="Client Master" component={ClientMaster} />
        <Stack.Screen name="Setting Master" component={Setting} />
        <Stack.Screen name="Edit Setting" component={EditSetting} />

        <Stack.Screen name="Add Client" component={AddClient} />
        <Stack.Screen name="Edit Client" component={EditClient} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default App;
