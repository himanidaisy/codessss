import React, {useState, useEffect} from 'react';
import {
  SafeAreaView,
  ScrollView,
  Text,
  TextInput,
  View,
  Dimensions,
  TouchableOpacity,
  ToastAndroid,
} from 'react-native';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import {URL} from '../../constants/configure';
import CustomNavigationBar from '../../components/CustomNavigationBar';
import DatePicker from 'react-native-datepicker';
import {COLORS, GLOBALSTYLES, FONTS} from '../../constants/theme';
import EmailIcon from 'react-native-vector-icons/MaterialCommunityIcons';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import {Picker} from '@react-native-picker/picker';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {Formik} from 'formik';
import axios from 'axios';
import * as yup from 'yup';
import {date} from 'yup/lib/locale';

const {height, width} = Dimensions.get('window');

const AddResource = ({navigation}) => {
  const [newData, setNewData] = useState([]);
  const [technologys, setTechnologys] = useState([]);
  const [extern, setExtern] = useState([]);
  const [venders, setVendors] = useState([]);
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [year, setYear] = useState('');
  const [venid, setVenid] = useState();
  const [exid, setExid] = useState();
  const [name, setName] = useState('');
  const [lame, setLame] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddres] = useState('');
  const [email, setEmail] = useState('');
  const [refer, setRefer] = useState('');
  const [language, setLanguage] = useState('');
  const [otherLanguage, setOtherLanguage] = useState('');
  const [resume, setResume] = useState('');
  const [contractFile, setContractFile] = useState('');
  const [checklist, setChecklist] = useState('');
  const [passing, setPassing] = useState('');
  const [otherDocs, setOtherDocs] = useState('');
  const [personalEmail, setPersonalEmail] = useState('');
  const [project, setProject] = useState('');
  const [panLink, setPanLink] = useState('');
  const [pf, setPf] = useState('');
  const [exidTouched, setexidTouched] = useState('');
  const [venidTouched, setvenidTouched] = useState();
  const [nameTouched, setnameTouched] = useState('');
  const [lnameTouched, setlnameTouched] = useState('');
  const [phoneTouched, setphoneTouched] = useState('');
  const [emailTouched, setemailTouched] = useState('');
  const [yearTouched, setyearTouched] = useState('');
  const [addressTouched, setaddressTouched] = useState('');
  const [pemailTouched, setpemailTouched] = useState('');
  const [languageTouched, setlanguageTouched] = useState('');
  const [referTouched, setreferTouched] = useState('');
  const [pfTouched, setpfTouched] = useState('');
  const [olanguageTouched, setolanguageTouched] = useState('');
  const [resumeTouched, setresumeTouched] = useState('');
  const [panTouched, setpanTouched] = useState('');
  const [sdateTouched, setsdateTouched] = useState('');
  const [passingTouched, setpassingTouched] = useState('');
  const [edateTouched, setedateTouched] = useState('');
  const [projectTouched, setprojectTouched] = useState('');

  const [otherTouched, setotherTouched] = useState('');
  const [checklistTouched, setchecklistTouched] = useState('');
  const [contractTouched, setcontractTouched] = useState('');
  // const [end, setEnd] = useState('');

  useEffect(() => {
    getResource();
    getTechnology();
    getExternal();
    getVendor();
  }, []);

  const getResource = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
      // console.log(requestOptions);
      const data = await axios.get(URL.BASE_URL + '/resource', requestOptions);

      // console.log(data.data.data.resources);

      setNewData(data.data.data.resources);
    } catch (error) {
      console.log(error);
    }
  };
  const getTechnology = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
      // console.log(requestOptions);
      const data = await axios.get(
        URL.BASE_URL + '/technology',
        requestOptions,
      );

      // console.log(data.data.data.externalResource);

      setTechnologys(data.data.data.technologies);
    } catch (error) {
      console.log(error);
    }
  };

  const getExternal = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
      // console.log(requestOptions);
      const data = await axios.get(
        URL.BASE_URL + '/external-resource',
        requestOptions,
      );

      // console.log(data.data.data.resources);

      setExtern(data.data.data.externalResource);
    } catch (error) {
      console.log(error);
    }
  };

  //post api

  const postUser = async () => {
    if (exid === '') {
      setexidTouched(true);
    }
    if (venid === '') {
      setvenidTouched(true);
    }
    if (name === '') {
      setnameTouched(true);
    }
    if (lame === '') {
      setlnameTouched(true);
    }
    if (endDate === '') {
      setedateTouched(true);
    }
    if (startDate === '') {
      setsdateTouched(true);
    }
    if (phone === '') {
      setphoneTouched(true);
    }
    if (email === '') {
      setemailTouched(true);
    }
    if (resume == '') {
      setresumeTouched(true);
    }
    if (language == '') {
      setlanguageTouched(true);
    }
    if (project == '') {
      setprojectTouched(true);
    }
    if (year == '') {
      setyearTouched(true);
    }
    if (address == '') {
      setaddressTouched(true);
    }
    if (personalEmail == '') {
      setpemailTouched(true);
    }
    if (passing == '') {
      setpassingTouched(true);
    }
    if (panLink == '') {
      setpanTouched(true);
    }
    if (refer == '') {
      setreferTouched(true);
    }
    if (otherLanguage == '') {
      setolanguageTouched(true);
    }
    if (pf == '') {
      setpfTouched(true);
    }

    if (otherDocs == '') {
      setotherTouched(true);
    }
    if (contractFile == '') {
      setcontractTouched(true);
    }
    if (checklist == '') {
      setchecklistTouched(true);
    }
    const store = {
      external_resource_id: exid,
      vendor_id: venid,
      fname: name,
      lname: lame,

      phone: phone,
      exp_date: year,
      resident_address: address,
      email: email,
      refer_no: refer,
      language: language,
      otherlanguage: otherLanguage,
      resume: resume,
      contract_file: contractFile,
      contract_start_date: startDate,
      contract_end_date: endDate,
      checklist: checklist,
      passing_year: passing,
      other_docs: otherDocs,
      personal_email: personalEmail,
      project: project,
      pan_link: panLink,
      pf_opt_out_form_link: pf,
    };
    //console.log('vinay-------->', store);

    try {
      const token = await AsyncStorage.getItem('token');

      const requestOptions = {
        method: 'POST',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };

      const {data} = await axios.post(
        'http://newresourcing.nimapinfotech.com/api/resource',
        store,
        requestOptions,
      );
      // console.log('check-------------->', data);
      if (data.message) {
        ToastAndroid.showWithGravity(
          'Resource Added Successfully',
          ToastAndroid.LONG,
          ToastAndroid.TOP,
        );
      }
      navigation.goBack();
    } catch (err) {
      console.log(err.response);
      ToastAndroid.showWithGravity(
        'Resource Not Added Successfully',
        ToastAndroid.SHORT,
        ToastAndroid.BOTTOM,
      );
    }
  };
  const getVendor = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
      // console.log(requestOptions);
      const data = await axios.get(URL.BASE_URL + '/vendor', requestOptions);

      // console.log(data.data.data.externalResource);

      setVendors(data.data.data.vendors);
    } catch (error) {
      console.log(error);
    }
  };
  const clientsOptions = extern.filter(t => t.fname !== null);
  const technologyCheck = technologys.filter(t => t.technology !== null);
  // const others = te.filter(t => t.technology !== null);
  const clientsVendor = venders.filter(t => t.company_name !== null);

  return (
    <SafeAreaView style={GLOBALSTYLES.mainContainer}>
      <CustomNavigationBar back={true} headername="Add Resource" />
      <View style={{height: height / 1.2}}>
        <ScrollView>
          <View style={{height: height / 0.4}}>
            <View
              style={{
                width: wp('90%'),
                height: hp('7%'),
                margin: 5,
                marginStart: 20,
                backgroundColor: COLORS.pureWhite,
                borderRadius: 10,
                marginTop: 10,
              }}>
              <Picker
                style={{margin: 5}}
                selectedValue={exid}
                mode="dropdown"
                onValueChange={value => {
                  setExid(value);
                  setexidTouched(false);
                }}>
                <Picker.Item
                  label="Select External Resource"
                  value=""
                  color="grey"
                />

                {clientsOptions.map((item, index) => (
                  <Picker.Item
                    key={item.id}
                    label={item.fname}
                    value={item.id}
                  />
                ))}
              </Picker>
            </View>
            {exidTouched === true ? (
              <Text style={{color: 'red', fontSize: 15, alignSelf: 'center'}}>
                {' '}
                Field Required
              </Text>
            ) : null}
            <View style={GLOBALSTYLES.textInputView}>
              <Picker
                selectedValue={venid}
                style={{margin: 5}}
                mode="dropdown"
                onValueChange={value => {
                  setVenid(value);
                  setvenidTouched(false);
                }}>
                <Picker.Item label="Vendor List" value="" color="grey" />

                {clientsVendor.map((item, index) => (
                  <Picker.Item
                    key={item.id}
                    label={item.company_name}
                    value={item.id}
                  />
                ))}
              </Picker>
            </View>
            {venidTouched === true ? (
              <Text style={{color: 'red', fontSize: 15, alignSelf: 'center'}}>
                {' '}
                Field Required
              </Text>
            ) : null}
            <View style={GLOBALSTYLES.textInputView}>
              <TextInput
                placeholder="First Name*"
                style={GLOBALSTYLES.textInput}
                value={name}
                onChangeText={data => {
                  setName(data);
                  setnameTouched(false);
                }}
                keyboardType="default"
              />
            </View>
            {nameTouched === true ? (
              <Text style={{color: 'red', fontSize: 15, alignSelf: 'center'}}>
                {' '}
                Field Required
              </Text>
            ) : null}
            <View style={GLOBALSTYLES.textInputView}>
              <TextInput
                placeholder="Last Name*"
                style={GLOBALSTYLES.textInput}
                value={lame}
                onChangeText={data => {
                  setLame(data);
                  setlnameTouched(false);
                }}
                keyboardType="default"
              />
            </View>
            {lnameTouched === true ? (
              <Text style={{color: 'red', fontSize: 15, alignSelf: 'center'}}>
                {' '}
                Field Required
              </Text>
            ) : null}
            <View
              style={{
                width: width - 40,
                height: height / 15,
                margin: 5,
                flexDirection: 'row',
                backgroundColor: COLORS.pureWhite,
                marginStart: 20,
                borderRadius: 10,
              }}>
              <View
                style={{
                  justifyContent: 'center',
                  borderRadius: 10,
                  padding: 12,

                  backgroundColor: COLORS.whiteBlue,
                }}>
                <FontAwesome
                  name="phone"
                  size={25}
                  style={{right: 12, marginStart: 20}}
                />
              </View>
              <TextInput
                placeholder="Phone Number*"
                style={GLOBALSTYLES.textInput}
                value={phone}
                onChangeText={data => {
                  setPhone(data);
                  setphoneTouched(false);
                }}
                keyboardType="number-pad"
              />
            </View>
            {phoneTouched === true ? (
              <Text style={{color: 'red', fontSize: 15, alignSelf: 'center'}}>
                {' '}
                Field Required
              </Text>
            ) : null}
            <View
              style={{
                width: width - 40,
                height: height / 15,
                margin: 5,
                flexDirection: 'row',
                backgroundColor: COLORS.pureWhite,
                marginStart: 20,
                borderRadius: 10,
              }}>
              <View
                style={{
                  justifyContent: 'center',
                  borderRadius: 10,
                  padding: 8,
                  backgroundColor: COLORS.whiteBlue,
                }}>
                <EmailIcon
                  name="email-outline"
                  size={25}
                  style={{right: 12, marginStart: 20}}
                />
              </View>
              <TextInput
                placeholder="Email Id*"
                style={GLOBALSTYLES.textInput}
                value={email}
                onChangeText={data => {
                  setEmail(data);
                  setemailTouched(false);
                }}
                keyboardType="email-address"
              />
            </View>
            {emailTouched === true ? (
              <Text style={{color: 'red', fontSize: 15, alignSelf: 'center'}}>
                {' '}
                Field Required
              </Text>
            ) : null}
            <View style={GLOBALSTYLES.textInputView}>
              <TextInput
                placeholder="Reference Number"
                style={GLOBALSTYLES.textInput}
                value={refer}
                onChangeText={data => {
                  setRefer(data);
                  setreferTouched(false);
                }}
                keyboardType="default"
              />
            </View>
            {referTouched === true ? (
              <Text style={{color: 'red', fontSize: 15, alignSelf: 'center'}}>
                {' '}
                Field Required
              </Text>
            ) : null}
            <View
              style={{
                width: wp('90%'),
                height: hp('7%'),
                margin: 5,
                marginStart: 20,
                backgroundColor: COLORS.pureWhite,
                borderRadius: 10,
              }}>
              <Picker
                selectedValue={language}
                style={{margin: 5}}
                mode="dropdown"
                onValueChange={value => {
                  setLanguage(value);

                  setlanguageTouched(false);
                }}>
                <Picker.Item label="Select Language" value="" color="grey" />

                {technologyCheck.map((item, index) => (
                  <Picker.Item
                    key={item.id}
                    label={item.technology}
                    value={item.id}
                  />
                ))}
              </Picker>
            </View>
            {languageTouched === true ? (
              <Text style={{color: 'red', fontSize: 15, alignSelf: 'center'}}>
                {' '}
                Field Required
              </Text>
            ) : null}
            <View style={GLOBALSTYLES.textInputView}>
              <Picker
                selectedValue={otherLanguage}
                style={{margin: 5}}
                mode="dropdown"
                onValueChange={value => {
                  setOtherLanguage(value);
                  setolanguageTouched(false);
                }}>
                <Picker.Item
                  label="Other Language Specification"
                  value=""
                  color="grey"
                />

                {technologyCheck.map((item, index) => (
                  <Picker.Item
                    key={item.id}
                    label={item.technology}
                    value={item.id}
                  />
                ))}
              </Picker>
            </View>
            {olanguageTouched === true ? (
              <Text style={{color: 'red', fontSize: 15, alignSelf: 'center'}}>
                {' '}
                Field Required
              </Text>
            ) : null}
            <View style={GLOBALSTYLES.textInputView}>
              <TextInput
                placeholder="Experience Year"
                style={GLOBALSTYLES.textInput}
                value={year}
                onChangeText={data => {
                  setYear(data);
                  setyearTouched(false);
                }}
                keyboardType="default"
              />
            </View>
            {yearTouched === true ? (
              <Text style={{color: 'red', fontSize: 15, alignSelf: 'center'}}>
                {' '}
                Field Required
              </Text>
            ) : null}
            <View
              style={{
                width: width - 40,
                height: height / 7,
                margin: 5,
                marginStart: 20,
                backgroundColor: COLORS.pureWhite,
                borderRadius: 10,
              }}>
              <TextInput
                placeholder=" Residential Address"
                style={{
                  marginHorizontal: 20,
                  ...FONTS.appFontSemiBold,

                  marginTop: 1,
                }}
                value={address}
                onChangeText={data => {
                  setAddres(data);
                  setaddressTouched(false);
                }}
                keyboardType="default"
              />
            </View>
            {addressTouched === true ? (
              <Text style={{color: 'red', fontSize: 15, alignSelf: 'center'}}>
                {' '}
                Field Required
              </Text>
            ) : null}
            <View style={GLOBALSTYLES.textInputView}>
              <TextInput
                placeholder="Resume Link"
                style={GLOBALSTYLES.textInput}
                value={resume}
                onChangeText={data => {
                  setResume(data);
                  setresumeTouched(false);
                }}
                keyboardType="default"
              />
            </View>
            {resumeTouched === true ? (
              <Text style={{color: 'red', fontSize: 15, alignSelf: 'center'}}>
                {' '}
                Field Required
              </Text>
            ) : null}
            <TouchableOpacity
              style={{
                width: wp('90%'),
                height: hp('7%'),
                margin: 5,
                flexDirection: 'row',
                justifyContent: 'space-between',
                backgroundColor: COLORS.pureWhite,
                marginStart: 20,
                borderRadius: 10,
              }}>
              <DatePicker
                value={startDate}
                date={startDate}
                style={{width: '100%', top: 7}}
                mode="date"
                placeholder="Contract Start Date"
                format="DD MMMM YYYY"
                minDate="01 01 2016"
                maxDate="01 01 2025"
                confirmBtnText="Confirm"
                cancelBtnText="Cancel"
                showIcon={false}
                customStyles={{
                  dateInput: {
                    borderWidth: 0,

                    position: 'absolute',
                    left: 20,
                    ...FONTS.appFontSemiBold,
                  },
                }}
                onDateChange={startDate => {
                  setStartDate(startDate);
                  setsdateTouched(false);
                }}
              />
              <FontAwesome
                name="calendar-o"
                size={20}
                style={{alignSelf: 'center', right: 30}}
              />
            </TouchableOpacity>
            {sdateTouched === true ? (
              <Text style={{color: 'red', fontSize: 15, alignSelf: 'center'}}>
                {' '}
                Field Required
              </Text>
            ) : null}
            <TouchableOpacity
              style={{
                width: wp('90%'),
                height: hp('7%'),
                margin: 5,
                flexDirection: 'row',
                justifyContent: 'space-between',
                backgroundColor: COLORS.pureWhite,
                marginStart: 20,
                borderRadius: 10,
              }}>
              <DatePicker
                value={endDate}
                date={endDate}
                style={{width: '100%', top: 7}}
                mode="date"
                placeholder="Contract End Date"
                format="DD MMMM YYYY"
                minDate="01 01 2016"
                maxDate="01 01 2025"
                confirmBtnText="Confirm"
                cancelBtnText="Cancel"
                showIcon={false}
                customStyles={{
                  dateInput: {
                    borderWidth: 0,

                    position: 'absolute',
                    left: 20,
                    ...FONTS.appFontSemiBold,
                  },
                }}
                onDateChange={endDate => {
                  setEndDate(endDate);
                  setedateTouched(false);
                }}
              />

              <FontAwesome
                name="calendar-o"
                size={20}
                style={{alignSelf: 'center', right: 30}}
              />
            </TouchableOpacity>
            {edateTouched === true ? (
              <Text style={{color: 'red', fontSize: 15, alignSelf: 'center'}}>
                {' '}
                Field Required
              </Text>
            ) : null}
            <View style={GLOBALSTYLES.textInputView}>
              <TextInput
                placeholder="Contract File Link"
                style={GLOBALSTYLES.textInput}
                value={contractFile}
                onChangeText={data => {
                  setContractFile(data);
                  setchecklistTouched(false);
                }}
                keyboardType="default"
              />
            </View>
            {contractTouched === true ? (
              <Text style={{color: 'red', fontSize: 15, alignSelf: 'center'}}>
                {' '}
                Field Required
              </Text>
            ) : null}
            <View style={GLOBALSTYLES.textInputView}>
              <TextInput
                placeholder="Personal Email"
                style={GLOBALSTYLES.textInput}
                value={personalEmail}
                onChangeText={data => {
                  setPersonalEmail(data);
                  setpemailTouched(false);
                }}
                keyboardType="default"
              />
            </View>
            {pemailTouched === true ? (
              <Text style={{color: 'red', fontSize: 15, alignSelf: 'center'}}>
                {' '}
                Field Required
              </Text>
            ) : null}
            <View style={GLOBALSTYLES.textInputView}>
              <TextInput
                placeholder="Checklist"
                style={GLOBALSTYLES.textInput}
                value={checklist}
                onChangeText={data => {
                  setChecklist(data);
                  setchecklistTouched(false);
                }}
                keyboardType="default"
              />
            </View>
            {checklistTouched === true ? (
              <Text style={{color: 'red', fontSize: 15, alignSelf: 'center'}}>
                {' '}
                Field Required
              </Text>
            ) : null}
            <View style={GLOBALSTYLES.textInputView}>
              <TextInput
                placeholder="Other Documents"
                style={GLOBALSTYLES.textInput}
                value={otherDocs}
                onChangeText={data => {
                  setOtherDocs(data);
                  setotherTouched(false);
                }}
                keyboardType="default"
              />
            </View>
            {otherTouched === true ? (
              <Text style={{color: 'red', fontSize: 15, alignSelf: 'center'}}>
                {' '}
                Field Required
              </Text>
            ) : null}
            <View style={GLOBALSTYLES.textInputView}>
              <TextInput
                placeholder="Passing Year"
                style={GLOBALSTYLES.textInput}
                value={passing}
                onChangeText={data => {
                  setPassing(data);
                  setpassingTouched(false);
                }}
                keyboardType="default"
              />
            </View>
            {passingTouched === true ? (
              <Text style={{color: 'red', fontSize: 15, alignSelf: 'center'}}>
                {' '}
                Field Required
              </Text>
            ) : null}
            <View style={GLOBALSTYLES.textInputView}>
              <TextInput
                placeholder="PAN Link"
                style={GLOBALSTYLES.textInput}
                value={panLink}
                onChangeText={data => {
                  setPanLink(data);
                  setpanTouched(false);
                }}
                keyboardType="default"
              />
            </View>
            {panTouched === true ? (
              <Text style={{color: 'red', fontSize: 15, alignSelf: 'center'}}>
                {' '}
                Field Required
              </Text>
            ) : null}
            <View style={GLOBALSTYLES.textInputView}>
              <TextInput
                placeholder="Pf Opt Out Form Link"
                style={GLOBALSTYLES.textInput}
                value={pf}
                onChangeText={data => {
                  setPf(data);
                  setpfTouched(false);
                }}
                keyboardType="default"
              />
            </View>
            {pfTouched === true ? (
              <Text style={{color: 'red', fontSize: 15, alignSelf: 'center'}}>
                {' '}
                Field Required
              </Text>
            ) : null}
            <View style={GLOBALSTYLES.textInputView}>
              <TextInput
                placeholder="Project"
                style={GLOBALSTYLES.textInput}
                value={project}
                onChangeText={data => {
                  setProject(data);
                  setprojectTouched(false);
                }}
                keyboardType="default"
              />
            </View>
            {projectTouched === true ? (
              <Text style={{color: 'red', fontSize: 15, alignSelf: 'center'}}>
                {' '}
                Field Required
              </Text>
            ) : null}
          </View>
        </ScrollView>
      </View>

      <View style={{flex: 1}}>
        <TouchableOpacity
          style={{
            width: width - 40,
            borderRadius: 10,
            alignSelf: 'center',
            // borderWidth:1,

            bottom: 5,
            backgroundColor: COLORS.skyBlue,
            position: 'absolute',
          }}
          onPress={() => postUser()}>
          <Text style={GLOBALSTYLES.textStyle}>Submit</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
};

export default AddResource;
