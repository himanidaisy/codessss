import React, {useState, useEffect} from 'react';
import {
  SafeAreaView,
  ScrollView,
  Text,
  TextInput,
  View,
  TouchableOpacity,
  StyleSheet,
  ToastAndroid,
  Dimensions,
} from 'react-native';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import DateTimePickerModal from 'react-native-modal-datetime-picker';
import moment from 'moment';
import {URL} from '../../constants/configure';
import CustomNavigationBar from '../../components/CustomNavigationBar';
import {GLOBALSTYLES, COLORS, FONTS} from '../../constants/theme';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import {Picker} from '@react-native-picker/picker';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import DatePicker from 'react-native-datepicker';

const {height, width} = Dimensions.get('window');

const EditInterview = ({navigation, route}) => {
  const [data, setData] = useState({});

  const [newData, setNewData] = useState([]);
  const [interviews, setInterviews] = useState([]);

  const [technologys, setTechnologys] = useState([]);
  const [clients, setClients] = useState([]);
  const [use, setUse] = useState([]);
  const [startDate, setStartDate] = useState('');
  const [year, setYear] = useState('');
  const [clientid, setClientid] = useState('');
  const [res, setRes] = useState('');
  const [schedules, setSchedules] = useState('');
  const [point, setPoint] = useState('');
  const [phone, setPhone] = useState('');
  const [mode, setMode] = useState('');
  const [address, setAddres] = useState('');
  const [type, setType] = useState('');
  const [locations, setLocations] = useState('');
  const [chosenDate, setChosenDate] = useState('');

  useEffect(() => {
    getResource();
    getClient();
    getTechnology();
    getUser();
    getInterview();
    setData(route.params.newData);
    setClientid(route.params.newData.client_name);
    setRes(route.params.newData.resources);
    setSchedules(route.params.newData.Schedule_id);
    setChosenDate(route.params.newData.datetime);
    setPoint(route.params.newData.contact_person);
    setPhone(route.params.newData.contact);
    setAddres(route.params.newData.address);
    setMode(route.params.newData.mode);
    setLocations(route.params.newData.location);
    setType(route.params.newData.interview_type);
  }, []);

  const getResource = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
      // console.log(requestOptions);
      const data = await axios.get(URL.BASE_URL + '/resource', requestOptions);

      // console.log(data.data.data.externalResource);

      setNewData(data.data.data.resources);
    } catch (error) {
      console.log(error);
    }
  };
  //get
  const getUser = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
      // console.log(requestOptions);
      const data = await axios.get(URL.BASE_URL + '/user', requestOptions);

      // console.log(data.data.data.externalResource);

      setUse(data.data.data.users);
    } catch (error) {
      console.log(error);
    }
  };
  //get
  const getInterview = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
      // console.log(requestOptions);
      const data = await axios.get(URL.BASE_URL + '/interview', requestOptions);

      // console.log(data.data.data.externalResource);

      setInterviews(data.data.data.interview);
    } catch (error) {
      console.log(error);
    }
  };
  const getClient = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
      // console.log(requestOptions);
      const data = await axios.get(URL.BASE_URL + '/client', requestOptions);

      // console.log(data.data.data.externalResource);

      setClients(data.data.data.clients);
    } catch (error) {
      console.log(error);
    }
  };
  const getTechnology = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
      // console.log(requestOptions);
      const data = await axios.get(
        URL.BASE_URL + '/technology',
        requestOptions,
      );

      // console.log(data.data.data.externalResource);

      setTechnologys(data.data.data.technologies);
    } catch (error) {
      console.log(error);
    }
  };

  //post

  const putUser = async () => {
    const store = {
      client: clientid,
      resource: res,
      contact_person: point,
      contact: phone,
      datetime: chosenDate,
      mode: mode,
      location: locations,
      address: address,

      interview_type: type,
      Schedule_id: schedules,
    };
    //console.log('store------>', store);
    const id = route.params.newData.id;

    try {
      const token = await AsyncStorage.getItem('token');

      const requestOptions = {
        method: 'PUT',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };

      const {data} = await axios.put(
        URL.BASE_URL + `/interview/${id}`,
        store,
        requestOptions,
      );
      setData(route.params.newData);

      // console.log('check-------------->', data);
      if (data.message) {
        ToastAndroid.showWithGravity(
          'Interview Data Updated Successfully',
          ToastAndroid.LONG,
          ToastAndroid.TOP,
        );
      }
      navigation.goBack();
    } catch (err) {
      console.log(err.response);
      ToastAndroid.showWithGravity(
        'Interview Data Not Updated Successfully',
        ToastAndroid.SHORT,
        ToastAndroid.BOTTOM,
      );
    }
  };

  const clientsOptions = clients.filter(t => t.client_name !== null);
  const technologyCheck = technologys.filter(t => t.technology !== null);
  const userCheck = use.filter(t => t.name !== null);
  const resourceCheck = newData.filter(t => t.resources !== null);
  const interviewCheck = interviews.filter(t => t.resources !== null);

  // const expDate= newData.filter(t=>t.exp_date !== null)
  const l1 = newData.map(e => e.l1);
  // console.log('---------',l1 )

  const handleConfirm = datetime => {
    console.log('A date has been picked: ', datetime);
    setChosenDate(moment(datetime).format('DD MMMM YYYY HH:mm'));
    hideDatePicker();
  };

  const showDatePicker = () => {
    setStartDate(true);
  };

  const hideDatePicker = () => {
    setStartDate(false);
  };
  return (
    <SafeAreaView style={GLOBALSTYLES.mainContainer}>
      <CustomNavigationBar back={true} headername="Edit Interview" />

      <View style={{height: height / 1.2}}>
        <ScrollView>
          <View style={{height: height / 0.6}}>
            <View
              style={{
                width: width - 40,
                height: height / 14,
                margin: 5,
                flexDirection: 'row',
                backgroundColor: COLORS.pureWhite,
                marginStart: 20,
                borderRadius: 10,
                marginTop: 10,
              }}>
              <Picker
                style={GLOBALSTYLES.textInput}
                selectedValue={clientid}
                mode="dropdown"
                onValueChange={value => {
                  setClientid(value);
                }}>
                <Picker.Item label="Client List" value="" color="grey" />

                {clientsOptions.map((item, index) => (
                  <Picker.Item
                    key={item.id}
                    label={item.client_name}
                    value={item.id}
                  />
                ))}
              </Picker>
            </View>

            <View style={GLOBALSTYLES.textInputView}>
              <Picker
                style={GLOBALSTYLES.textInput}
                selectedValue={res}
                mode="dropdown"
                onValueChange={value => {
                  setRes(value);
                }}>
                <Picker.Item label="Resource List" value="" color="grey" />

                {resourceCheck.map((item, index) => (
                  <Picker.Item
                    key={item.id}
                    label={`${item.fname} ${item.lname}`}
                    value={item.id}
                  />
                ))}
              </Picker>
            </View>

            <View style={GLOBALSTYLES.textInputView}>
              <Picker
                style={GLOBALSTYLES.textInput}
                selectedValue={schedules}
                mode="dropdown"
                onValueChange={value => {
                  setSchedules(value);
                }}>
                <Picker.Item label="Sheduled By" value="" color="grey" />

                {userCheck.map((item, index) => (
                  <Picker.Item
                    key={item.id}
                    label={item.name}
                    value={item.id}
                  />
                ))}
              </Picker>
            </View>

            <TouchableOpacity
              style={{
                width: width - 40,
                height: height / 14,
                margin: 5,
                flexDirection: 'row',
                justifyContent: 'space-between',
                backgroundColor: COLORS.pureWhite,
                marginStart: 20,
                borderRadius: 10,
              }}
              onPress={showDatePicker}>
              <TextInput
                placeholder="Select Date and Time"
                value={chosenDate}
                style={{
                  borderWidth: 0,
                  position: 'absolute',
                  left: 30,
                  marginTop: 5,
                  ...FONTS.appFontSemiBold,
                }}
                onChangeText={data => {
                  setChosenDate(data);
                }}
              />
              <DateTimePickerModal
                isVisible={startDate}
                mode="datetime"
                onConfirm={handleConfirm}
                onCancel={hideDatePicker}
                display="default"
              />

              <FontAwesome
                name="calendar-o"
                size={20}
                style={{alignSelf: 'center', position: 'absolute', right: 30}}
              />
            </TouchableOpacity>
            <View style={GLOBALSTYLES.textInputView}>
              <TextInput
                placeholder="Point Of Contact"
                style={GLOBALSTYLES.textInput}
                value={point}
                onChangeText={data => {
                  setPoint(data);
                }}
                keyboardType="default"
              />
            </View>

            <View
              style={{
                width: width - 40,
                height: height / 15,
                margin: 5,
                flexDirection: 'row',
                backgroundColor: COLORS.pureWhite,
                marginStart: 20,
                borderRadius: 10,
              }}>
              <View
                style={{
                  justifyContent: 'center',
                  borderRadius: 10,
                  padding: 12,

                  backgroundColor: COLORS.whiteBlue,
                }}>
                <FontAwesome
                  name="phone"
                  size={25}
                  style={{right: 12, marginStart: 20}}
                />
              </View>
              <TextInput
                placeholder="Phone Number*"
                style={GLOBALSTYLES.textInput}
                value={phone}
                onChangeText={data => setPhone(data)}
                keyboardType="number-pad"
              />
            </View>
            <View style={GLOBALSTYLES.textInputView}>
              <Picker
                style={GLOBALSTYLES.textInput}
                selectedValue={mode}
                mode="dropdown"
                onValueChange={value => {
                  setMode(value);
                }}>
                <Picker.Item
                  label="Select Interview Mode"
                  value=""
                  color="grey"
                />

                {interviewCheck.map((item, index) => (
                  <Picker.Item
                    key={item.id}
                    label={item.mode}
                    value={item.id}
                  />
                ))}
              </Picker>
            </View>
            <View style={GLOBALSTYLES.textInputView}>
              <Picker
                style={GLOBALSTYLES.textInput}
                selectedValue={locations}
                mode="dropdown"
                onValueChange={value => {
                  setLocations(value);
                }}>
                <Picker.Item
                  label="Select Interview Loction"
                  value=""
                  color="grey"
                />

                {interviewCheck.map((item, index) => (
                  <Picker.Item
                    key={item.id}
                    label={item.location}
                    value={item.id}
                  />
                ))}
              </Picker>
            </View>
            <View style={GLOBALSTYLES.textInputView}>
              <Picker
                style={GLOBALSTYLES.textInput}
                selectedValue={type}
                mode="dropdown"
                onValueChange={value => {
                  setType(value);
                }}>
                <Picker.Item
                  label="Select Interview Type"
                  value=""
                  color="grey"
                />

                {interviewCheck.map((item, index) => (
                  <Picker.Item
                    key={item.id}
                    label={item.interview_type}
                    value={item.id}
                  />
                ))}
              </Picker>
            </View>
            <View
              style={{
                width: wp('90%'),
                height: hp('15%'),
                marginBottom: 5,
                marginStart: 20,
                backgroundColor: COLORS.pureWhite,
                borderRadius: 10,
              }}>
              <TextInput
                placeholder=" Residential Address"
                style={{
                  marginHorizontal: 20,
                  ...FONTS.appFontSemiBold,
                  flex: 1,
                }}
                value={address}
                onChangeText={data => setAddres(data)}
                keyboardType="default"
              />
            </View>
          </View>
        </ScrollView>
      </View>

      <View style={{flex: 1}}>
        <TouchableOpacity
          style={{
            width: width - 40,
            borderRadius: 10,
            alignSelf: 'center',
            // borderWidth:1,

            bottom: 5,
            backgroundColor: COLORS.skyBlue,
            position: 'absolute',
          }}
          onPress={() => putUser()}>
          <Text style={GLOBALSTYLES.textStyle}>Submit</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
};

export default EditInterview;
