import React, {useEffect, useState} from 'react';
import {
  Text,
  View,
  SafeAreaView,
  TouchableOpacity,
  FlatList,
  ActivityIndicator,
  ToastAndroid,
  Dimensions,
} from 'react-native';
import {GLOBALSTYLES, COLORS, FONTS} from '../../constants/theme';
import SearchBox from '../../components/SearchBox';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {URL} from '../../constants/configure';
import {Picker} from '@react-native-picker/picker';
const {height, width} = Dimensions.get('window');

const Interview = ({navigation}) => {
  const [newData, setNewData] = useState([]);
  const [loding, setLoding] = useState(true);
  const [search, setSearch] = useState('');
  const [filterData, setFilterData] = useState([]);
  const [status, setStatus] = useState('');

  useEffect(() => {
    getResource();
    getAccountFilterData();
  }, [search, loding, newData]);

  //get

  const getResource = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
      // console.log(requestOptions);
      const data = await axios.get(URL.BASE_URL + '/interview', requestOptions);

      // console.log(data.data.data.technologies);
      setNewData(data.data.data.interview);
      setLoding(false);
    } catch (error) {
      console.log(error);
      setLoding(true);
    }
  };

  const setSearchValue = value => {
    setSearch(value);
  };
  const getAccountFilterData = () => {
    if (!loding) {
      const filterValue = newData?.filter(data => {
        if (search.length === 0) {
          return data;
        } else if (
          data.clients?.client_name
            .toLowerCase()
            .includes(!!search && search.toLowerCase()) ||
          data.resources?.fname
            .toLowerCase()
            .includes(!!search && search.toLowerCase()) ||
          data.resources?.lname
            .toLowerCase()
            .includes(!!search && search.toLowerCase()) ||
          // data.mode.toLowerCase().includes(search.toLowerCase()) ||
          // data.datetime.includes(search) ||
          // data.receive_question.toLowerCase().includes(search.toLowerCase()) || given null value
          data.interview_status.toLowerCase().includes(search.toLowerCase())
        ) {
          // console.log(data);
          return data;
        }
      });
      setFilterData(filterValue);
    }
  };

  //Delete User
  const deleteUser = async values => {
    console.log('check__', values);
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'DELETE',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
      const {data} = await axios.delete(
        `http://newresourcing.nimapinfotech.com/api/interview${values}`,
        //  values,
        requestOptions,
      );
      // console.log(data);
      setSearch('');
      const remaningData = newData.filter(t => t.id !== values);
      setFilterData([...remaningData]);
      if (data.message) {
        ToastAndroid.showWithGravity(
          ' Interview Deleted successfully',
          ToastAndroid.SHORT,
          ToastAndroid.BOTTOM,
        );
      }
    } catch (err) {
      // console.log(err.response);
      ToastAndroid.showWithGravity(
        ' Interview not deleted',
        ToastAndroid.SHORT,
        ToastAndroid.BOTTOM,
      );
    }
  };

  const handleDelete = item => {
    console.log('Delte hit', deleteUser(item.id));
    // deleteUser(item.id);
    getResource();
    console.log('check id', item.id);
  };
  return (
    <SafeAreaView style={GLOBALSTYLES.mainContainer}>
      <SearchBox search={search} setSearchValue={setSearchValue} />
      {loding ? (
        <ActivityIndicator
          animating={true}
          size="large"
          style={{
            opacity: 1,
            position: 'absolute',
            left: 0,
            right: 0,
            top: 0,
            bottom: 0,
            alignItems: 'center',
            justifyContent: 'center',
          }}
        />
      ) : (
        <FlatList
          data={filterData}
          renderItem={({item}) => (
            <View style={GLOBALSTYLES.appContainer}>
              <View style={GLOBALSTYLES.lebalView}>
                <Text style={GLOBALSTYLES.lebal}>Resources</Text>
                <View style={GLOBALSTYLES.contentView}>
                  <Text style={GLOBALSTYLES.content}>
                    {item.resources === null
                      ? '-'
                      : `${item.resources.fname} ${item.resources.lname}`}
                  </Text>
                </View>
              </View>
              <View
                style={{flexDirection: 'row', justifyContent: 'space-between'}}>
                <View style={{flexDirection: 'column'}}>
                  <View style={GLOBALSTYLES.lebalView}>
                    <Text style={GLOBALSTYLES.lebal}>Client</Text>

                    <Text style={GLOBALSTYLES.content}>
                      {item.clients === null ? '-' : item?.clients?.client_name}
                    </Text>
                  </View>
                  <View style={GLOBALSTYLES.lebalView}>
                    <Text style={GLOBALSTYLES.lebal}>Date & Time</Text>

                    <Text style={GLOBALSTYLES.content}>
                      {item.datetime === null ? '-' : item.datetime}
                    </Text>
                  </View>
                </View>
                <View style={{flexDirection: 'column'}}>
                  <View style={GLOBALSTYLES.lebalView}>
                    <Text style={GLOBALSTYLES.lebal}>Mode</Text>

                    <Text style={GLOBALSTYLES.content}>
                      {item.mode === null ? '-' : item.mode}
                    </Text>
                  </View>
                  <View
                    style={{
                      flexDirection: 'row',
                      justifyContent: 'space-between',
                    }}>
                    <View
                      style={{
                        marginStart: 6,
                        backgroundColor: COLORS.pureWhite,
                        borderRadius: 10,
                      }}>
                      <View
                        style={{
                          ...FONTS.appFontSemiBold,
                          width: width / 2,
                        }}>
                        <Picker
                          selectedValue={status}
                          mode="dropdown"
                          style={{marginRight: width / 6}}
                          onValueChange={itemValue => setStatus(itemValue)}>
                          <Picker.Item label="Status" value="" color="grey" />

                          <Picker.Item label="Selected" value="Selected" />
                          <Picker.Item label="Rejected" value="Rejected" />
                          <Picker.Item label="OnHold" value="OnHold" />
                          <Picker.Item label="Cancel" value="Cancel" />
                        </Picker>
                      </View>
                    </View>
                  </View>
                </View>
              </View>
              <View style={GLOBALSTYLES.lebalView}>
                <Text style={GLOBALSTYLES.lebal}>Receive Que?</Text>

                <Text style={GLOBALSTYLES.content}>
                  {item.receive_question === null ? '-' : item.receive_question}
                </Text>
              </View>

              <View style={{flexDirection: 'row', margin: 10}}>
                <TouchableOpacity
                  style={GLOBALSTYLES.editBtn}
                  onPress={() =>
                    navigation.navigate('Edit Interview', {
                      newData: item,
                    })
                  }>
                  <Text style={GLOBALSTYLES.editText}>Edit</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={GLOBALSTYLES.deleteBtn}
                  onPress={() => handleDelete(item)}>
                  <Text style={GLOBALSTYLES.deleteText}>Delete</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}
        />
      )}
    </SafeAreaView>
  );
};

export default Interview;
