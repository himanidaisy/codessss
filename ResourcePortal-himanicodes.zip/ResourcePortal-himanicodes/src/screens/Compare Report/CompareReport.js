import React, {useState} from 'react';
import {
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  Dimensions,
  _View,
} from 'react-native';
import SearchBox from '../../components/SearchBox';
// import DateTimePicker from '@react-native-community/datetimepicker';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import Icon from 'react-native-vector-icons/FontAwesome';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {FONTS, COLORS, GLOBALSTYLES} from '../../constants/theme';
import DatePicker from 'react-native-datepicker';
import InternalScreen from './InternalScreen';
import ExternalScreen from './ExternalScreen';
const {height, width} = Dimensions.get('window');

const CompareReport = () => {
  const [change, setChange] = useState(false);
  const [inbtn, setinbtn] = useState('skyblue');
  const [exbtn, setexbtn] = useState('white');
  const handleChange = () => {
    setChange(true);
  };
  const handleChange2 = () => {
    !setChange();
  };

  return (
    <SafeAreaView>
      <ScrollView>
        <View style={{flexDirection: 'row', margin: 20}}>
          <View style={styles.inbtn}>
            <TouchableOpacity onPress={handleChange2}>
              <Text style={styles.inbtntext}>Internal</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.exbtn}>
            <TouchableOpacity onPress={handleChange}>
              <Text style={styles.exbtntext}>External</Text>
            </TouchableOpacity>
          </View>
        </View>

        <View style={{alignItems: 'center'}}></View>
        <SearchBox />
        <View style={{flexDirection: 'row', justifyContent: 'space-between'}}>
          <View
            style={{
              width: width / 2.3,
              height: height / 14,
              margin: 5,
              flexDirection: 'row',
              justifyContent: 'space-between',
              backgroundColor: COLORS.pureWhite,
              marginStart: 20,
              borderRadius: 10,
              marginTop: 10,
            }}>
            <DatePicker
              style={{width: '100%', top: 7}}
              mode="date"
              placeholder="From Date"
              format="DD MMMM YYYY"
              minDate="01 01 2016"
              maxDate="01 01 2025"
              confirmBtnText="Confirm"
              cancelBtnText="Cancel"
              showIcon={false}
              customStyles={{
                dateInput: {
                  borderWidth: 0,

                  position: 'absolute',
                  left: 20,
                  ...FONTS.appFontSemiBold,
                },
              }}
            />
            <FontAwesome
              name="calendar-o"
              size={20}
              style={{alignSelf: 'center', right: 50}}
            />
          </View>
          <View
            style={{
              width: width / 2.3,
              height: height / 14,
              margin: 5,
              flexDirection: 'row',
              justifyContent: 'space-between',
              backgroundColor: COLORS.pureWhite,
              marginRight: 20,
              borderRadius: 10,
              marginTop: 10,
            }}>
            <DatePicker
              style={{width: '100%', top: 7}}
              mode="date"
              placeholder="To Date"
              format="DD MMMM YYYY"
              minDate="01 01 2016"
              maxDate="01 01 2025"
              confirmBtnText="Confirm"
              cancelBtnText="Cancel"
              showIcon={false}
              customStyles={{
                dateInput: {
                  borderWidth: 0,

                  position: 'absolute',
                  left: 20,
                  ...FONTS.appFontSemiBold,
                },
              }}
            />
            <FontAwesome
              name="calendar-o"
              size={20}
              style={{alignSelf: 'center', right: 50}}
            />
          </View>
        </View>
        <TouchableOpacity
          style={{
            height: height / 14,
            width: width - 40,
            borderRadius: 10,
            alignSelf: 'center',
            top: 0,
            backgroundColor: COLORS.skyBlue,
            padding: 8,
            margin: 10,
            position: 'relative',
          }}>
          <Text style={GLOBALSTYLES.textStyle}>Submit</Text>
        </TouchableOpacity>
        <View>{change ? <ExternalScreen /> : <InternalScreen />}</View>
      </ScrollView>
    </SafeAreaView>
  );
};
const styles = StyleSheet.create({
  inbtn: {
    width: width / 2.15,
    backgroundColor: 'skyblue',
    height: height / 14,
    borderRadius: 10,
  },
  inbtnn: {
    width: width / 2.15,
    backgroundColor: 'white',
    height: height / 14,
    borderRadius: 10,
  },
  inbtntext: {
    fontSize: 17,
    color: 'white',
    position: 'relative',
    left: 90,
    top: 23,
  },
  exbtntext: {
    fontSize: 17,
    color: 'skyblue',
    position: 'relative',
    left: 90,
    top: 23,
  },
  exbtn: {
    width: width / 2.15,
    backgroundColor: 'white',
    height: height / 14,
    borderRadius: 10,
    position: 'relative',
    right: 5,
  },
  numberText: {
    color: 'darkorange',
    fontSize: 40,
    fontWeight: 'bold',
    marginStart: 20,
    marginTop: 10,
  },
  titleText: {
    fontSize: 20,
    color: 'grey',
    marginStart: 20,
  },
  rtitleText: {
    fontSize: 18,
    color: 'grey',
    marginStart: 20,
  },
  contractboxtitleText: {
    color: COLORS.pureWhite,
    fontWeight: 'bold',
    fontSize: 17,
    marginStart: width / 4,
  },
  inumberText: {
    color: 'skyblue',
    fontSize: 40,
    fontWeight: 'bold',
    marginStart: 20,
    marginTop: 10,
  },
  viewcontainer: {
    flex: 1,
    backgroundColor: 'white',
    borderRadius: 10,
    marginTop: 15,
    marginStart: 20,
  },
  infocontainer: {
    borderRadius: 10,

    marginStart: 20,
    marginTop: 10,
    backgroundColor: COLORS.pureWhite,
  },
  boxcontainer: {
    borderRadius: 10,
    marginHorizontal: 20,

    marginTop: 10,
    backgroundColor: COLORS.pureWhite,
  },
  boxcontainerstyle: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 20,
    backgroundColor: 'skyblue',
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10,
  },
  projectboxcontainerstyle: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 20,
    backgroundColor: 'skyblue',
    borderRadius: 10,
  },
  boxtitleText: {
    color: COLORS.pureWhite,
    fontWeight: 'bold',
    fontSize: 17,
  },
  textStyle: {
    flexDirection: 'row',
    padding: '3%',
    justifyContent: 'space-between',
  },

  rnumberText: {
    color: 'black',
    fontSize: 18,
    fontWeight: 'bold',
    marginStart: 20,
  },
});

export default CompareReport;
