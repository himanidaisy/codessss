import React, {useState, useEffect} from 'react';
import {
  Text,
  View,
  SafeAreaView,
  TouchableOpacity,
  TextInput,
  ToastAndroid,
  Dimensions,
  StyleSheet,
} from 'react-native';
import CustomNavigationBar from '../../components/CustomNavigationBar';
import {COLORS, FONTS, GLOBALSTYLES} from '../../constants/theme';

import {Picker} from '@react-native-picker/picker';
import axios from 'axios';
import DatePicker from 'react-native-datepicker';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import {URL} from '../../constants/configure';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {ScrollView} from 'react-native-gesture-handler';
const {height, width} = Dimensions.get('window');

const AddNonJoiningScreen = ({navigation}) => {
  const [newData, setNewData] = useState([]);
  const [resources, setResources] = useState('');
  const [leavingdate, setleavingdate] = useState('');
  const clientsOptions = newData.filter(t => t.client_name !== null);

  return (
    <SafeAreaView style={GLOBALSTYLES.mainContainer}>
      <CustomNavigationBar back={true} headername="Add NonJoining" />
      <View style={styles.container}>
        <View
          style={{
            width: width - 40,
            height: height / 14,
            margin: 5,
            marginStart: 20,
            backgroundColor: COLORS.pureWhite,
            borderRadius: 10,
            marginTop: 10,
          }}>
          <Picker
            selectedValue={resources}
            style={{margin: 4, bottom: 0}}
            mode="dropdown"
            onValueChange={value => {
              setResources(value);
            }}>
            <Picker.Item label="Select Resources" value="" color="grey" />
            {clientsOptions.map((item, index) => (
              <Picker.Item key={item.id} label={item.product} value={item.id} />
            ))}
          </Picker>
        </View>

        <View style={GLOBALSTYLES.textInputView}>
          <TextInput
            placeholder="Client"
            style={GLOBALSTYLES.textInput}
            value={leavingdate}
            maxLength={20}
          />
        </View>
        <View
          style={{
            width: width - 50,
            height: height / 14,
            margin: 5,
            flexDirection: 'row',
            justifyContent: 'space-between',
            backgroundColor: COLORS.pureWhite,
            marginStart: 25,
            borderRadius: 10,
          }}>
          <DatePicker
            style={{width: '100%', top: 7}}
            date={leavingdate}
            value={leavingdate}
            mode="date"
            placeholder="End Date"
            format="DD MMMM YYYY"
            minDate="01 01 2016"
            maxDate="01 01 2025"
            confirmBtnText="Confirm"
            cancelBtnText="Cancel"
            showIcon={false}
            customStyles={{
              dateInput: {
                borderWidth: 0,

                position: 'absolute',
                left: 20,
                ...FONTS.appFontSemiBold,
              },
            }}
            onDateChange={date => {
              setleavingdate(date);
            }}
          />
          <FontAwesome
            name="calendar-o"
            size={20}
            style={{alignSelf: 'center', right: 50}}
          />
        </View>
        <View style={{flexDirection: 'row', justifyContent: 'space-between'}}>
          <TouchableOpacity style={styles.btnStyle} onPress={() => postUser()}>
            <Text style={GLOBALSTYLES.textStyle}>Preview</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.buttonStyle}
            onPress={() => postUser()}>
            <Text style={GLOBALSTYLES.textStyle}>Submit</Text>
          </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  btnStyle: {
    width: width / 2.3,
    backgroundColor: COLORS.skyBlue,
    padding: 10,
    borderRadius: 10,
    margin: 10,
    left: 10,
    position: 'absolute',
    top: height / 1.7,
  },
  buttonStyle: {
    width: width / 2.3,
    backgroundColor: COLORS.skyBlue,
    padding: 10,
    borderRadius: 10,
    margin: 10,
    right: 10,
    position: 'absolute',

    top: height / 1.7,
  },
  container: {
    flex: 1,
    backgroundColor: COLORS.white,
  },
});
export default AddNonJoiningScreen;
