import React, {useState, useEffect} from 'react';
import {
  SafeAreaView,
  ScrollView,
  Text,
  TextInput,
  View,
  Dimensions,
  ToastAndroid,
  TouchableOpacity,
  StyleSheet,
} from 'react-native';

import CustomNavigationBar from '../../components/CustomNavigationBar';
import {COLORS, FONTS, GLOBALSTYLES} from '../../constants/theme';
import {Formik} from 'formik';
import {URL} from '../../constants/configure';
import axios from 'axios';
import * as yup from 'yup';
import AsyncStorage from '@react-native-async-storage/async-storage';
const {height, width} = Dimensions.get('window');

const AddTechnology = ({navigation}) => {
  const [newData, setNewData] = useState([]);
  const [exist, setExist] = useState([]);
  const [technologyTouched, settechnologyTouched] = useState(false);
  const [urlTouched, seturlTouched] = useState(false);
  const [url, seturl] = useState('');
  const [technology, settechnology] = useState('');
  const loginValidationSchema = yup.object().shape({
    technology: yup.string().required('Please fill out this filed'),
    url: yup.string().required('Please fill out this filed'),
  });

  //post
  useEffect(() => {
    getResource();
    isExistech();
    isExisturl();
  }, []);
  const getResource = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
      const data = await axios.get(
        URL.BASE_URL + '/technology',
        requestOptions,
      );

      let arr = [];
      data.data.data.technologies.map(temp => {
        let obj = {
          technology: temp.technology,
          url: temp.url,
        };
        arr.push(obj);
      });
      console.log(arr);
      setNewData(arr);
    } catch (error) {
      console.log(error);
    }
  };
  const isExistech = technology => {
    return newData.some(function (el) {
      return el.technology === technology;
    });
  };
  const isExisturl = url => {
    return newData.some(function (el) {
      return el.url === url;
    });
  };

  const postUser = async values => {
    const store = {
      technology: technology,
      url: url,
    };
    try {
      const token = await AsyncStorage.getItem('token');

      const requestOptions = {
        method: 'POST',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };

      const {data} = await axios.post(
        URL.BASE_URL + '/technology',
        values,
        requestOptions,
      );
      // console.log(data);
      if (data.message) {
        ToastAndroid.showWithGravity(
          'Technology Added Successfully',
          ToastAndroid.SHORT,
          ToastAndroid.BOTTOM,
        );
      }
      navigation.goBack();
    } catch (err) {
      ToastAndroid.showWithGravity(
        'technology not created',
        ToastAndroid.SHORT,
        ToastAndroid.BOTTOM,
      );
    }
  };
  const handleSubmit = values => {
    JSON.stringify(values);
    const {technology: tech, url: Url} = values;
    //console.log(isExist(tech,Url));
    if (isExistech(tech) == true) {
      settechnologyTouched(true);
    } else {
      settechnologyTouched(false);
    }

    if (isExisturl(Url) == true) {
      seturlTouched(true);
    } else {
      seturlTouched(false);
      postUser(values);
    }
  };

  return (
    <SafeAreaView style={GLOBALSTYLES.mainContainer}>
      <CustomNavigationBar back={true} headername="Add Technology" />
      <Formik
        validationSchema={loginValidationSchema}
        initialValues={{technology: '', url: ''}}
        onSubmit={handleSubmit}>
        {({handleChange, handleBlur, handleSubmit, errors, touched}) => (
          <>
            <View style={{height: height / 1.2}}>
              <View
                style={{
                  width: width - 50,
                  height: height / 14,
                  margin: 5,
                  marginStart: 25,
                  backgroundColor: COLORS.pureWhite,
                  borderRadius: 10,
                  marginTop: 10,
                }}>
                <TextInput
                  placeholder="Name*"
                  name="tech"
                  style={GLOBALSTYLES.textInput}
                  onChangeText={handleChange('technology')}
                  onBlur={handleBlur('technology')}
                />
              </View>
              {errors.technology && touched.technology && (
                <Text style={GLOBALSTYLES.errorStyle}>{errors.technology}</Text>
              )}
              {technologyTouched === true ? (
                <Text style={{color: 'red', fontSize: 15, alignSelf: 'center'}}>
                  {' '}
                  Value Already Exist
                </Text>
              ) : null}

              <View style={GLOBALSTYLES.textInputView}>
                <TextInput
                  name="url"
                  placeholder="URL"
                  style={GLOBALSTYLES.textInput}
                  onChangeText={handleChange('url')}
                  onBlur={handleBlur('url')}
                />
              </View>
              {errors.url && touched.url && (
                <Text style={GLOBALSTYLES.errorStyle}>{errors.url}</Text>
              )}
              {urlTouched === true ? (
                <Text style={{color: 'red', fontSize: 15, alignSelf: 'center'}}>
                  {' '}
                  Value Already Exist
                </Text>
              ) : null}
            </View>
            <View
              style={{
                flex: 1,
                flexDirection: 'column',
                justifyContent: 'space-between',
              }}>
              <TouchableOpacity
                disable={technologyTouched}
                style={GLOBALSTYLES.buttonStyle}
                onPress={handleSubmit}>
                <Text style={GLOBALSTYLES.textStyle}>Submit</Text>
              </TouchableOpacity>
            </View>
          </>
        )}
      </Formik>
    </SafeAreaView>
  );
};

export default AddTechnology;
