import React, {useEffect, useState} from 'react';
import {
  Text,
  View,
  SafeAreaView,
  TouchableOpacity,
  FlatList,
  ActivityIndicator,
  ToastAndroid,
  Dimensions,
  StyleSheet,
} from 'react-native';
import {GLOBALSTYLES, COLORS, FONTS} from '../constants/theme';
import SearchBox from '../components/SearchBox';
import CheckBox from '@react-native-community/checkbox';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {Picker} from '@react-native-picker/picker';
const {height, width} = Dimensions.get('window');

const InvoiceHistory = ({navigation}) => {
  const [isptouched, setptouched] = useState(false);
  const [isitouched, setitouched] = useState(false);
  const [ishtouched, sethtouched] = useState(false);
  const [ispftouched, setpftouched] = useState(false);
  const [isttouched, setttouched] = useState(false);
  return (
    <SafeAreaView style={styles.mainContainer}>
      <View style={GLOBALSTYLES.appContainer}>
        <SearchBox />
        <View style={styles.lebalView}>
          <Text style={styles.lebal}>Month</Text>

          <Text style={styles.content}>April 2020</Text>
        </View>

        <View style={styles.lebalView}>
          <Text style={styles.lebal}>Client Name</Text>

          <Text style={styles.content}>Fino Payments Bank Ltd</Text>
        </View>
        <View style={styles.lebalView}>
          <Text style={styles.lebal}>Total Resources</Text>

          <Text style={styles.content}>2</Text>
        </View>
        <View style={{flexDirection: 'row', justifyContent: 'space-between'}}>
          <View style={styles.checkboxView}>
            <CheckBox value={isptouched} onValueChange={setptouched} />
            <View style={styles.checkView}>
              <Text style={styles.lebal}>Pay</Text>
            </View>
          </View>
          <View style={styles.checkboxView}>
            <CheckBox value={isitouched} onValueChange={setitouched} />
            <View style={styles.checkView}>
              <Text style={styles.lebal}>Inv</Text>
            </View>
          </View>
          <View style={styles.checkboxView}>
            <CheckBox value={ishtouched} onValueChange={sethtouched} />
            <View style={styles.checkView}>
              <Text style={styles.lebal}>HC</Text>
            </View>
          </View>
          <View style={styles.checkboxView}>
            <CheckBox value={ispftouched} onValueChange={setpftouched} />
            <View style={styles.checkView}>
              <Text style={styles.lebal}>PF</Text>
            </View>
          </View>
          <View style={styles.checkboxView}>
            <CheckBox value={isttouched} onValueChange={setttouched} />
            <View style={styles.checkView}>
              <Text style={styles.lebal}>TS</Text>
            </View>
          </View>
        </View>
      </View>
      <View style={GLOBALSTYLES.appContainer}>
        <View style={styles.lebalView}>
          <Text style={styles.lebal}>Month</Text>

          <Text style={styles.content}>April 2020</Text>
        </View>

        <View style={styles.lebalView}>
          <Text style={styles.lebal}>Client Name</Text>

          <Text style={styles.content}>Fino Payments Bank Ltd</Text>
        </View>
        <View style={styles.lebalView}>
          <Text style={styles.lebal}>Total Resources</Text>

          <Text style={styles.content}>2</Text>
        </View>
        <View style={{flexDirection: 'row', justifyContent: 'space-between'}}>
          <View style={styles.checkboxView}>
            <CheckBox value={isptouched} onValueChange={setptouched} />
            <View style={styles.checkView}>
              <Text style={styles.lebal}>Pay</Text>
            </View>
          </View>
          <View style={styles.checkboxView}>
            <CheckBox value={isitouched} onValueChange={setitouched} />
            <View style={styles.checkView}>
              <Text style={styles.lebal}>Inv</Text>
            </View>
          </View>
          <View style={styles.checkboxView}>
            <CheckBox value={ishtouched} onValueChange={sethtouched} />
            <View style={styles.checkView}>
              <Text style={styles.lebal}>HC</Text>
            </View>
          </View>
          <View style={styles.checkboxView}>
            <CheckBox value={ispftouched} onValueChange={setpftouched} />
            <View style={styles.checkView}>
              <Text style={styles.lebal}>PF</Text>
            </View>
          </View>
          <View style={styles.checkboxView}>
            <CheckBox value={isttouched} onValueChange={setttouched} />
            <View style={styles.checkView}>
              <Text style={styles.lebal}>TS</Text>
            </View>
          </View>
        </View>
      </View>
    </SafeAreaView>
  );
};
const styles = StyleSheet.create({
  lebalView: {
    margin: 10,
    flexDirection: 'row',
    marginStart: 20,
  },
  mainContainer: {
    flex: 1,
  },
  checkboxView: {
    margin: 10,

    marginStart: 20,
    marginTop: '10%',
  },
  content: {
    flex: 1,
    ...FONTS.appFontSemiBold,
    color: 'black',
  },
  lebal: {
    flex: 1,
    ...FONTS.appFontSemiBold,
    color: 'grey',
  },
  appContainer: {
    flex: 1,
    margin: 20,
    backgroundColor: COLORS.pureWhite,
    marginVertical: '1%',
    padding: 10,
    borderRadius: 10,
    backgroundColor: COLORS.pureWhite,
  },
  checkView: {
    margin: 3,
    flexDirection: 'row',
  },
});
export default InvoiceHistory;
