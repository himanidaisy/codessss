import React, {useEffect, useState} from 'react';
import {
  Text,
  View,
  SafeAreaView,
  TouchableOpacity,
  Dimensions,
  StyleSheet,
} from 'react-native';
import {GLOBALSTYLES, COLORS, FONTS} from '../../constants/theme';
import Check from 'react-native-vector-icons/MaterialCommunityIcons';
const {height, width} = Dimensions.get('window');
const TableModal = props => {
  closeModal = (bool, data) => {
    props.changeModalVisible(bool);
    props.setData(data);
  };

  return (
    <SafeAreaView style={styles.mainContainer}>
      <View styte={styles.viewContainerView}>
        <View style={styles.modalView}>
          <TouchableOpacity>
            <Text
              style={{
                fontSize: 16,
                marginStart: 15,
                elevation: 2,
                marginTop: 10,
              }}>
              Not Done
            </Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => closeModal(false)}>
            <Text
              style={{
                fontSize: 16,
                marginStart: 15,
                elevation: 2,
                marginTop: 10,
              }}>
              Full Done
            </Text>
          </TouchableOpacity>
          <TouchableOpacity>
            <Text
              style={{
                fontSize: 16,
                marginStart: 15,
                elevation: 2,
                marginTop: 10,
              }}>
              Partially Done
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );
};
const styles = StyleSheet.create({
  mainContainer: {
    flex: 1,
  },
  viewContainerView: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalView: {
    width: width / 2.5,
    backgroundColor: 'white',
    borderRadius: 10,
    alignSelf: 'center',
    marginTop: width / 0.9,
    height: height / 9,
    marginLeft: width / 2,
  },
  cell: {
    flex: 1,
    borderWidth: 1,
    borderColor: 'lightgrey',
    height: height / 14,
    justifyContent: 'center',

    alignItems: 'center',
  },

  appContainer: {
    backgroundColor: COLORS.pureWhite,
    margin: 20,
    flex: 1,
    borderRadius: 10,
    backgroundColor: COLORS.pureWhite,
  },
});
export default TableModal;
