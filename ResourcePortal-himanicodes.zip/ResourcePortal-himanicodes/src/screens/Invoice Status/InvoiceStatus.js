import React, {useEffect, useState} from 'react';
import {
  Text,
  View,
  SafeAreaView,
  TouchableOpacity,
  FlatList,
  ActivityIndicator,
  ToastAndroid,
  Dimensions,
  StyleSheet,
  ScrollView,
  TextInput,
} from 'react-native';
import {GLOBALSTYLES, COLORS, FONTS} from '../../constants/theme';
import CheckBox from '@react-native-community/checkbox';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {Picker} from '@react-native-picker/picker';
import Icon from 'react-native-vector-icons/FontAwesome';
import {Col, Row, Grid} from 'react-native-easy-grid';
import TableScreen from './TableScreen';
const {height, width} = Dimensions.get('window');

const InvoiceStatus = ({navigation}) => {
  const handleChangeValue = value => {
    setSearchValue(value);
  };
  return (
    <SafeAreaView style={styles.mainContainer}>
      <ScrollView>
        <View style={styles.appContainer}>
          <View
            style={{
              width: width / 1.15,
              height: height / 14,
              margin: 5,
              flexDirection: 'row',
              backgroundColor: COLORS.pureWhite,
              marginStart: '5%',
              borderRadius: 10,
              marginTop: 20,
              border: 'solid',
              borderColor: 'grey',
              borderWidth: 1,
            }}>
            <TextInput
              placeholder="search"
              style={GLOBALSTYLES.textInput}
              onChangeText={handleChangeValue}
            />
          </View>
          <View style={{flexDirection: 'row'}}>
            <Text
              style={{
                marginStart: '7%',
                fontSize: 15,
                color: 'black',
                marginTop: '9%',
              }}>
              Show
            </Text>

            <View
              style={{
                width: width / 4,
                height: height / 14,
                margin: 5,
                flexDirection: 'row',
                backgroundColor: COLORS.pureWhite,
                marginStart: 12,
                borderRadius: 10,
                marginTop: 20,
                border: 'solid',
                borderColor: 'grey',
                borderWidth: 1,
              }}>
              <TextInput style={GLOBALSTYLES.textInput} />
              <Icon name="angle-down" size={25} style={styles.iconStyledrop} />
            </View>

            <TouchableOpacity
              style={{
                backgroundColor: 'skyblue',
                padding: 20,
                borderRadius: 10,
                marginLeft: width / 5.2,
                position: 'relative',
                top: 20,
                height: height / 14,
                justifyContent: 'center',
              }}>
              <Text style={{fontSize: 15}}>Export & Send</Text>
            </TouchableOpacity>
          </View>
          <TableScreen />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};
const styles = StyleSheet.create({
  mainContainer: {
    flex: 1,
  },

  iconStyledrop: {
    marginRight: '15%',
    marginTop: '15%',
  },
  appContainer: {
    marginTop: 20,
    borderRadius: 10,
    margin: 10,
    backgroundColor: COLORS.pureWhite,
  },
});
export default InvoiceStatus;
