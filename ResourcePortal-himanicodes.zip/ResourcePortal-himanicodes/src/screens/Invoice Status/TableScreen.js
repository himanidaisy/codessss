import React, {useEffect, useState} from 'react';
import {
  Text,
  View,
  SafeAreaView,
  TouchableOpacity,
  FlatList,
  ActivityIndicator,
  ToastAndroid,
  Dimensions,
  StyleSheet,
  ScrollView,
  TextInput,
  Modal,
} from 'react-native';
import {GLOBALSTYLES, COLORS, FONTS} from '../../constants/theme';
import CheckBox from '@react-native-community/checkbox';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {Picker} from '@react-native-picker/picker';
import Icon from 'react-native-vector-icons/FontAwesome';
import {Col, Row, Grid} from 'react-native-easy-grid';

import TableModal from './TableModal';
const {height, width} = Dimensions.get('window');

const TableScreen = () => {
  const [isiModalVisible, setisiModalVisible] = useState(false);
  const [choosedata, setchoosedata] = useState();
  const changeModalVisible = bool => {
    setisiModalVisible(bool);
  };
  const setData = data => {
    setchoosedata(data);
  };
  return (
    <SafeAreaView style={styles.mainContainer}>
      <ScrollView>
        <View style={styles.container}>
          <Grid style={{marginRight: 20}}>
            <Col>
              <Row style={styles.cell}>
                <Text
                  style={{fontSize: 16, fontWeight: 'bold', color: 'black'}}>
                  Month
                </Text>
              </Row>
              <Row style={styles.cell}>
                <Text
                  style={{fontSize: 16, fontWeight: 'bold', color: 'black'}}>
                  Client Name
                </Text>
              </Row>
              <Row style={styles.cell}>
                <Text
                  style={{fontSize: 16, fontWeight: 'bold', color: 'black'}}>
                  Total Resources
                </Text>
              </Row>
              <Row style={styles.cell}>
                <Text
                  style={{fontSize: 16, fontWeight: 'bold', color: 'black'}}>
                  Pay
                </Text>
              </Row>
              <Row style={styles.cell}>
                <Text
                  style={{fontSize: 16, fontWeight: 'bold', color: 'black'}}>
                  Inv
                </Text>
              </Row>
              <Row style={styles.cell}>
                <Text
                  style={{fontSize: 16, fontWeight: 'bold', color: 'black'}}>
                  HC
                </Text>
              </Row>
              <Row style={styles.cell}>
                <Text
                  style={{fontSize: 16, fontWeight: 'bold', color: 'black'}}>
                  PF
                </Text>
              </Row>
              <Row style={styles.cell}>
                <Text
                  style={{fontSize: 16, fontWeight: 'bold', color: 'black'}}>
                  TS
                </Text>
              </Row>
            </Col>
            <Col>
              <Row style={styles.cell}>
                <Text style={{fontSize: 14, color: 'black'}}>March 2022</Text>
              </Row>
              <Row style={styles.cell}>
                <Text style={{fontSize: 14, color: 'black'}}>ABCD</Text>
              </Row>
              <Row style={styles.cell}>
                <Text style={{fontSize: 14, color: 'black'}}>2</Text>
              </Row>
              <Row style={styles.cell}>
                <Text style={{fontSize: 14, color: 'black'}}></Text>
              </Row>
              <Row style={styles.cell}>
                <Text style={{fontSize: 14, color: 'black'}}></Text>
              </Row>
              <Row style={styles.cell}>
                <Text style={{fontSize: 14, color: 'black'}}></Text>
              </Row>
              <Row style={styles.cell}>
                <Text style={{fontSize: 14, color: 'black'}}></Text>
              </Row>
              <Row style={styles.cell}>
                <Text style={{fontSize: 14, color: 'black'}}></Text>
              </Row>
            </Col>
          </Grid>
          <Grid style={{marginRight: 20, marginTop: 20}}>
            <Col>
              <Row style={styles.cell}>
                <Text
                  style={{fontSize: 16, fontWeight: 'bold', color: 'black'}}>
                  Month
                </Text>
              </Row>
              <Row style={styles.cell}>
                <Text
                  style={{fontSize: 16, fontWeight: 'bold', color: 'black'}}>
                  Client Name
                </Text>
              </Row>
              <Row style={styles.cell}>
                <Text
                  style={{fontSize: 16, fontWeight: 'bold', color: 'black'}}>
                  Total Resources
                </Text>
              </Row>
              <Row style={styles.cell}>
                <Text
                  style={{fontSize: 16, fontWeight: 'bold', color: 'black'}}>
                  Pay
                </Text>
              </Row>
              <Row style={styles.cell}>
                <Text
                  style={{fontSize: 16, fontWeight: 'bold', color: 'black'}}>
                  Inv
                </Text>
              </Row>
              <Row style={styles.cell}>
                <Text
                  style={{fontSize: 16, fontWeight: 'bold', color: 'black'}}>
                  HC
                </Text>
              </Row>
              <Row style={styles.cell}>
                <Text
                  style={{fontSize: 16, fontWeight: 'bold', color: 'black'}}>
                  PF
                </Text>
              </Row>
              <Row style={styles.cell}>
                <Text
                  style={{fontSize: 16, fontWeight: 'bold', color: 'black'}}>
                  TS
                </Text>
              </Row>
            </Col>
            <Col>
              <Row style={styles.cell}>
                <Text style={{fontSize: 14, color: 'black'}}>
                  February 2022
                </Text>
              </Row>
              <Row style={styles.cell}>
                <Text style={{fontSize: 14, color: 'black'}}>ABCD</Text>
              </Row>
              <Row style={styles.cell}>
                <Text style={{fontSize: 14, color: 'black'}}>2</Text>
              </Row>
              <Row style={styles.cell}>
                <Text></Text>
              </Row>
              <Row style={styles.cell}>
                <Text></Text>
              </Row>
              <Row style={styles.cell}>
                <Text></Text>
              </Row>
              <Row style={styles.cell}>
                <Text></Text>
              </Row>
              <Row style={styles.cell}>
                <Text></Text>
              </Row>
            </Col>
          </Grid>
          {/* <Grid style={{marginRight: 20, marginTop: 20}}>
            <Col>
              <Row style={styles.cell}>
                <Text
                  style={{fontSize: 16, fontWeight: 'bold', color: 'black'}}>
                  Month
                </Text>
              </Row>
              <Row style={styles.cell}>
                <Text
                  style={{fontSize: 16, fontWeight: 'bold', color: 'black'}}>
                  Client Name
                </Text>
              </Row>
              <Row style={styles.cell}>
                <Text
                  style={{fontSize: 16, fontWeight: 'bold', color: 'black'}}>
                  Total Resources
                </Text>
              </Row>
              <Row style={styles.cell}>
                <Text
                  style={{fontSize: 16, fontWeight: 'bold', color: 'black'}}>
                  Pay
                </Text>
              </Row>
              <Row style={styles.cell}>
                <Text
                  style={{fontSize: 16, fontWeight: 'bold', color: 'black'}}>
                  Inv
                </Text>
              </Row>
              <Row style={styles.cell}>
                <Text
                  style={{fontSize: 16, fontWeight: 'bold', color: 'black'}}>
                  HC
                </Text>
              </Row>
              <Row style={styles.cell}>
                <Text
                  style={{fontSize: 16, fontWeight: 'bold', color: 'black'}}>
                  PF
                </Text>
              </Row>
              <Row style={styles.cell}>
                <Text
                  style={{fontSize: 16, fontWeight: 'bold', color: 'black'}}>
                  TS
                </Text>
              </Row>
            </Col>
            <Col>
              <Row style={styles.cell}>
                <Text style={{fontSize: 16, color: 'black'}}>
                  February 2022
                </Text>
              </Row>
              <Row style={styles.cell}>
                <Text style={{fontSize: 16, color: 'black'}}>ABCD</Text>
              </Row>
              <Row style={styles.cell}>
                <Text style={{fontSize: 16, color: 'black'}}>2</Text>
              </Row>
              <Row style={styles.cell}>
                <Text>{choosedata}</Text>
                <TouchableOpacity
                  onPress={() => changeModalVisible(true)}
                  style={{
                    padding: 20,
                    backgroundColor: 'white',
                    flex: 1,
                  }}></TouchableOpacity>
                <Modal
                  animationType="fade"
                  transparent={true}
                  visible={isiModalVisible}
                  onRequestClose={() => changeModalVisible(false)}>
                  <TableModal
                    changeModalVisible={changeModalVisible}
                    setData={setData}
                  />
                </Modal>
              </Row>
              <Row style={styles.cell}>
                <TouchableOpacity
                  style={{
                    padding: 20,
                    backgroundColor: 'white',
                    flex: 1,
                  }}></TouchableOpacity>
              </Row>
              <Row style={styles.cell}>
                <TouchableOpacity
                  style={{
                    padding: 20,
                    backgroundColor: 'white',
                    flex: 1,
                  }}></TouchableOpacity>
              </Row>
              <Row style={styles.cell}>
                <TouchableOpacity
                  style={{
                    padding: 20,
                    backgroundColor: 'white',
                    flex: 1,
                  }}></TouchableOpacity>
              </Row>
              <Row style={styles.cell}>
                <TouchableOpacity
                  style={{
                    padding: 20,
                    backgroundColor: 'white',
                    flex: 1,
                  }}></TouchableOpacity>
              </Row>
            </Col>
          </Grid> */}
          <Grid style={{marginRight: 20, marginTop: 20}}>
            <Col>
              <Row style={styles.cell}>
                <Text
                  style={{fontSize: 16, fontWeight: 'bold', color: 'black'}}>
                  Month
                </Text>
              </Row>
              <Row style={styles.cell}>
                <Text
                  style={{fontSize: 16, fontWeight: 'bold', color: 'black'}}>
                  Client Name
                </Text>
              </Row>
              <Row style={styles.cell}>
                <Text
                  style={{fontSize: 16, fontWeight: 'bold', color: 'black'}}>
                  Total Resources
                </Text>
              </Row>
              <Row style={styles.cell}>
                <Text
                  style={{fontSize: 16, fontWeight: 'bold', color: 'black'}}>
                  Pay
                </Text>
              </Row>
              <Row style={styles.cell}>
                <Text
                  style={{fontSize: 16, fontWeight: 'bold', color: 'black'}}>
                  Inv
                </Text>
              </Row>
              <Row style={styles.cell}>
                <Text
                  style={{fontSize: 16, fontWeight: 'bold', color: 'black'}}>
                  HC
                </Text>
              </Row>
              <Row style={styles.cell}>
                <Text
                  style={{fontSize: 16, fontWeight: 'bold', color: 'black'}}>
                  PF
                </Text>
              </Row>
              <Row style={styles.cell}>
                <Text
                  style={{fontSize: 16, fontWeight: 'bold', color: 'black'}}>
                  TS
                </Text>
              </Row>
            </Col>
            <Col>
              <Row style={styles.cell}>
                <Text style={{fontSize: 14, color: 'black'}}>January 2022</Text>
              </Row>
              <Row style={styles.cell}>
                <Text style={{fontSize: 14, color: 'black'}}>ABCD</Text>
              </Row>
              <Row style={styles.cell}>
                <Text style={{fontSize: 14, color: 'black'}}>2</Text>
              </Row>
              <Row style={styles.cell}>
                <Text></Text>
              </Row>
              <Row style={styles.cell}>
                <Text></Text>
              </Row>
              <Row style={styles.cell}>
                <Text></Text>
              </Row>
              <Row style={styles.cell}>
                <Text></Text>
              </Row>
              <Row style={styles.cell}>
                <Text></Text>
              </Row>
            </Col>
          </Grid>
          <Grid style={{marginRight: 20, marginTop: 20}}>
            <Col>
              <Row style={styles.cell}>
                <Text
                  style={{fontSize: 16, fontWeight: 'bold', color: 'black'}}>
                  Month
                </Text>
              </Row>
              <Row style={styles.cell}>
                <Text
                  style={{fontSize: 16, fontWeight: 'bold', color: 'black'}}>
                  Client Name
                </Text>
              </Row>
              <Row style={styles.cell}>
                <Text
                  style={{fontSize: 16, fontWeight: 'bold', color: 'black'}}>
                  Total Resources
                </Text>
              </Row>
              <Row style={styles.cell}>
                <Text
                  style={{fontSize: 16, fontWeight: 'bold', color: 'black'}}>
                  Pay
                </Text>
              </Row>
              <Row style={styles.cell}>
                <Text
                  style={{fontSize: 16, fontWeight: 'bold', color: 'black'}}>
                  Inv
                </Text>
              </Row>
              <Row style={styles.cell}>
                <Text
                  style={{fontSize: 16, fontWeight: 'bold', color: 'black'}}>
                  HC
                </Text>
              </Row>
              <Row style={styles.cell}>
                <Text
                  style={{fontSize: 16, fontWeight: 'bold', color: 'black'}}>
                  PF
                </Text>
              </Row>
              <Row style={styles.cell}>
                <Text
                  style={{fontSize: 16, fontWeight: 'bold', color: 'black'}}>
                  TS
                </Text>
              </Row>
            </Col>
            <Col>
              <Row style={styles.cell}>
                <Text style={{fontSize: 14, color: 'black'}}>
                  December 2022
                </Text>
              </Row>
              <Row style={styles.cell}>
                <Text style={{fontSize: 14, color: 'black'}}>ABCD</Text>
              </Row>
              <Row style={styles.cell}>
                <Text style={{fontSize: 14, color: 'black'}}>2</Text>
              </Row>
              <Row style={styles.cell}>
                <Text></Text>
              </Row>
              <Row style={styles.cell}>
                <Text></Text>
              </Row>
              <Row style={styles.cell}>
                <Text></Text>
              </Row>
              <Row style={styles.cell}>
                <Text></Text>
              </Row>
              <Row style={styles.cell}>
                <Text></Text>
              </Row>
            </Col>
          </Grid>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};
const styles = StyleSheet.create({
  mainContainer: {
    flex: 1,
  },
  container: {
    width: width,
    padding: 20,

    backgroundColor: '#fff',
  },
  cell: {
    borderWidth: 1,
    borderColor: 'lightgrey',

    padding: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
export default TableScreen;
