import React, {useState, useEffect} from 'react';
import {
  Text,
  View,
  SafeAreaView,
  TouchableOpacity,
  TextInput,
  ToastAndroid,
  Dimensions,
} from 'react-native';
import CustomNavigationBar from '../../components/CustomNavigationBar';
import {COLORS, FONTS, GLOBALSTYLES} from '../../constants/theme';

import {Picker} from '@react-native-picker/picker';
import axios from 'axios';
import DatePicker from 'react-native-datepicker';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import {URL} from '../../constants/configure';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {ScrollView} from 'react-native-gesture-handler';
const {height, width} = Dimensions.get('window');

const AddAllInterview = ({navigation}) => {
  const [newData, setNewData] = useState([]);
  const [resources, setResources] = useState('');
  const [email, setEmail] = useState('');
  const [client, setClient] = useState('');
  const [name, setname] = useState('');
  const [phone, setPhone] = useState('');
  const [contractype, setcontractype] = useState('');
  const [address, setaddress] = useState('');
  const [startdate, setstartdate] = useState('');
  const [enddate, setenddate] = useState('');
  const clientsOptions = newData.filter(t => t.client_name !== null);
  useEffect(() => {
    getResource();
  }, []);

  const getResource = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
      console.log(requestOptions);
      const data = await axios.get(URL.BASE_URL + '/joining', requestOptions);

      // console.log(data.data.data.resources);

      setNewData(data.data.data.joining);
    } catch (error) {
      console.log(error);
    }
  };
  const postUser = async () => {
    const store = {
      resources: resources,
      start_date: startdate,
      end_date: enddate,
      name: name,
      client: client,
      phone: phone,
      email: email,
      contractype: contractype,
      address: address,
    };

    // console.log('checkv--------', store);
    try {
      const token = await AsyncStorage.getItem('token');

      const requestOptions = {
        method: 'POST',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };

      const {data} = await axios.post(
        URL.BASE_URL + '/joining',
        store,
        requestOptions,
      );

      // console.log('valuecheck------------->',data);
      if (data.message) {
        ToastAndroid.showWithGravity(
          ' Joining added successfully',
          ToastAndroid.SHORT,
          ToastAndroid.BOTTOM,
        );
      }
      navigation.goBack();
    } catch (err) {
      // console.log(err.response)
      ToastAndroid.showWithGravity(
        'Joining not Added',
        ToastAndroid.SHORT,
        ToastAndroid.BOTTOM,
      );
    }
  };

  return (
    <SafeAreaView style={GLOBALSTYLES.mainContainer}>
      <CustomNavigationBar back={true} headername="Schedule Interview" />
      <ScrollView>
        <View>
          <View
            style={{
              width: width - 40,
              height: height / 14,
              margin: 5,
              marginStart: 20,
              backgroundColor: COLORS.pureWhite,
              borderRadius: 10,
              marginTop: 10,
            }}>
            <Picker
              selectedValue={resources}
              style={{margin: 4, bottom: 0}}
              mode="dropdown"
              onValueChange={value => {
                setResources(value);
              }}>
              <Picker.Item label="Select Client" value="" color="grey" />
              {clientsOptions.map((item, index) => (
                <Picker.Item
                  key={item.id}
                  label={item.resources}
                  value={item.id}
                />
              ))}
            </Picker>
          </View>
          <View
            style={{
              width: width - 40,
              height: height / 14,
              margin: 5,
              marginStart: 20,
              backgroundColor: COLORS.pureWhite,
              borderRadius: 10,
              marginTop: 10,
            }}>
            <Picker
              selectedValue={resources}
              style={{margin: 4, bottom: 0}}
              mode="dropdown"
              onValueChange={value => {
                setResources(value);
              }}>
              <Picker.Item label="Select Resources" value="" color="grey" />
              {clientsOptions.map((item, index) => (
                <Picker.Item
                  key={item.id}
                  label={item.resources}
                  value={item.id}
                />
              ))}
            </Picker>
          </View>
          <View
            style={{
              width: width - 40,
              height: height / 14,
              margin: 5,
              marginStart: 20,
              backgroundColor: COLORS.pureWhite,
              borderRadius: 10,
              marginTop: 10,
            }}>
            <Picker
              selectedValue={resources}
              style={{margin: 4, bottom: 0}}
              mode="dropdown"
              onValueChange={value => {
                setResources(value);
              }}>
              <Picker.Item label="Schedule By" value="" color="grey" />
              {clientsOptions.map((item, index) => (
                <Picker.Item
                  key={item.id}
                  label={item.resources}
                  value={item.id}
                />
              ))}
            </Picker>
          </View>
          <View
            style={{
              width: width - 50,
              height: height / 14,
              margin: 5,
              flexDirection: 'row',
              justifyContent: 'space-between',
              backgroundColor: COLORS.pureWhite,
              marginStart: 25,
              borderRadius: 10,
            }}>
            <DatePicker
              style={{width: '100%', top: 7}}
              date={startdate}
              value={startdate}
              mode="date"
              placeholder="Select Date & Time"
              format="DD MMMM YYYY"
              minDate="01 01 2016"
              maxDate="01 01 2025"
              confirmBtnText="Confirm"
              cancelBtnText="Cancel"
              showIcon={false}
              customStyles={{
                dateInput: {
                  borderWidth: 0,

                  position: 'absolute',
                  left: 20,
                  ...FONTS.appFontSemiBold,
                },
              }}
              onDateChange={date => {
                setstartdate(date);
              }}
            />
            <FontAwesome
              name="calendar-o"
              size={20}
              style={{alignSelf: 'center', right: 50}}
            />
          </View>
          <View style={GLOBALSTYLES.textInputView}>
            <TextInput
              placeholder="Point of Contact"
              style={GLOBALSTYLES.textInput}
              value={name}
              maxLength={20}
            />
          </View>

          <View
            style={{
              width: width - 40,
              height: height / 14,
              margin: 5,
              flexDirection: 'row',
              backgroundColor: COLORS.pureWhite,
              marginStart: 20,
              borderRadius: 10,
            }}>
            <View
              style={{
                justifyContent: 'center',
                borderRadius: 10,
                padding: 15,
                backgroundColor: COLORS.whiteBlue,
              }}>
              <FontAwesome
                color={COLORS.lightBlue}
                name="phone"
                size={25}
                style={{right: 10, marginStart: 25}}
              />
            </View>
            <TextInput
              placeholder="Mobile*"
              style={GLOBALSTYLES.textInput}
              value={phone}
              keyboardType="default"
            />
          </View>
          <View
            style={{
              width: width - 40,
              height: height / 14,
              margin: 5,
              marginStart: 20,
              backgroundColor: COLORS.pureWhite,
              borderRadius: 10,
              marginTop: 5,
            }}>
            <Picker
              selectedValue={contractype}
              style={{margin: 4, bottom: 0}}
              mode="dropdown"
              onValueChange={value => {
                setcontractype(value);
              }}>
              <Picker.Item
                label="Select Interview Mode"
                value=""
                color="grey"
              />
              {clientsOptions.map((item, index) => (
                <Picker.Item
                  key={item.id}
                  label={item.contract_type}
                  value={item.id}
                />
              ))}
            </Picker>
          </View>
          <View
            style={{
              width: width - 40,
              height: height / 14,
              margin: 5,
              marginStart: 20,
              backgroundColor: COLORS.pureWhite,
              borderRadius: 10,
              marginTop: 5,
            }}>
            <Picker
              selectedValue={contractype}
              style={{margin: 4, bottom: 0}}
              mode="dropdown"
              onValueChange={value => {
                setcontractype(value);
              }}>
              <Picker.Item
                label="Select Interview Location"
                value=""
                color="grey"
              />
              {clientsOptions.map((item, index) => (
                <Picker.Item
                  key={item.id}
                  label={item.contract_type}
                  value={item.id}
                />
              ))}
            </Picker>
          </View>
          <View
            style={{
              width: width - 40,
              height: height / 14,
              margin: 5,
              marginStart: 20,
              backgroundColor: COLORS.pureWhite,
              borderRadius: 10,
              marginTop: 5,
            }}>
            <Picker
              selectedValue={contractype}
              style={{margin: 4, bottom: 0}}
              mode="dropdown"
              onValueChange={value => {
                setcontractype(value);
              }}>
              <Picker.Item
                label="Select Interview Type"
                value=""
                color="grey"
              />
              {clientsOptions.map((item, index) => (
                <Picker.Item
                  key={item.id}
                  label={item.contract_type}
                  value={item.id}
                />
              ))}
            </Picker>
          </View>

          <View
            style={{
              width: width - 50,
              height: height / 7,
              margin: 5,
              marginStart: 25,
              backgroundColor: COLORS.pureWhite,
              borderRadius: 10,
            }}>
            <TextInput
              placeholder="Company Address"
              style={{
                marginHorizontal: 20,
                ...FONTS.appFontSemiBold,

                marginTop: 1,
              }}
              maxLength={100}
            />
          </View>
          <TouchableOpacity
            style={{
              backgroundColor: COLORS.skyBlue,
              width: width - 40,
              padding: 10,
              borderRadius: 10,
              alignSelf: 'center',
              bottom: 0,
              position: 'relative',
              margin: 20,
            }}
            onPress={() => postUser()}>
            <Text style={GLOBALSTYLES.textStyle}>Submit</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};
export default AddAllInterview;
