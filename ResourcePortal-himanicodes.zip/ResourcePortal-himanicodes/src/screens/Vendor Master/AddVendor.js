import React, {useState, useEffect} from 'react';
import {
  SafeAreaView,
  ScrollView,
  Text,
  TextInput,
  View,
  StyleSheet,
  ToastAndroid,
  TouchableOpacity,
  Dimensions,
} from 'react-native';
import CustomNavigationBar from '../../components/CustomNavigationBar';
import {FONTS, COLORS, GLOBALSTYLES} from '../../constants/theme';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';
import {Picker} from '@react-native-picker/picker';
import {Formik} from 'formik';
import * as yup from 'yup';

const {height, width} = Dimensions.get('window');

const AddVendor = ({navigation}) => {
  const [newData, setNewData] = useState([]);
  const [cnameTouched, setcnameTouched] = useState(false);
  const [mobileTouched, setmobileTouched] = useState(false);
  const [emailTouched, setemailTouched] = useState(false);
  //get
  useEffect(() => {
    getResource();
    isExistcname();
    isExistmobile();
    isExistemail();
  }, []);
  const getResource = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
      const data = await axios.get(
        'http://newresourcing.nimapinfotech.com/api/vendor',
        requestOptions,
      );

      let arr = [];
      data.data.data.vendors.map(temp => {
        let obj = {
          cname: temp.cname,
          mobile: temp.mobile,
          email: temp.email,
        };
        arr.push(obj);
      });
      console.log(arr);
      setNewData(arr);
    } catch (error) {
      console.log(error);
    }
  };
  const isExistcname = cname => {
    return newData.some(function (el) {
      return el.cname === cname;
    });
  };

  const isExistmobile = mobile => {
    return newData.some(function (el) {
      return el.mobile === mobile;
    });
  };
  const isExistemail = email => {
    return newData.some(function (el) {
      return el.email === email;
    });
  };
  const postUser = async values => {
    try {
      const token = await AsyncStorage.getItem('token');

      const requestOptions = {
        method: 'POST',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };

      const {data} = await axios.post(
        URL.BASE_URL + '/vendor',
        values,

        requestOptions,
      );
      // console.log('check-------------->', data);
      if (data.message) {
        ToastAndroid.showWithGravity(
          'Vendor created successfully',
          ToastAndroid.SHORT,
          ToastAndroid.BOTTOM,
        );
      }
      navigation.goBack();
    } catch (err) {
      console.log(err.response);
      ToastAndroid.showWithGravity(
        'Vendor not created',
        ToastAndroid.SHORT,
        ToastAndroid.BOTTOM,
      );
    }
  };
  const loginValidationSchema = yup.object().shape({
    company_name: yup.string().required('These field is Required'),
    contact_person: yup.string().required('These field is Required'),
    company_address: yup.string().required('These field is Required'),
    contact_number: yup.string().required('These field is Required'),
    contact_email: yup.string().required('These field is Required'),
    gst_link: yup.string().required('These field is Required'),
    gst: yup.string().required('These field is Required'),
    pan: yup.string().required('These field is Required'),
    agreement_link: yup.string().required('These field is Required'),
    pan_link: yup.string().required('These field is Required'),
  });
  const handleSubmit = values => {
    JSON.stringify(values);
    const {cname: cname, mobile: mobile, email: email} = values;
    //console.log(isExist(tech,Url));
    if (isExistcname(cname) == true) {
      setcnameTouched(true);
    } else {
      setcnameTouched(false);
    }

    if (isExistmobile(mobile) == true) {
      setmobileTouched(true);
    } else {
      setmobileTouched(false);
    }
    if (isExistemail(email) == true) {
      setemailTouched(true);
    } else {
      setemailTouched(false);
      postUser(values);
    }
  };

  return (
    <SafeAreaView style={GLOBALSTYLES.mainContainer}>
      <CustomNavigationBar back={true} headername="Add Vendor" />
      <ScrollView>
        <Formik
          validationSchema={loginValidationSchema}
          initialValues={{
            company_name: '',
            contact_person: '',
            company_address: '',
            contact_number: '',
            contact_email: '',
            gst_link: '',
            gst: '',
            pan: '',
            agreement_link: '',
            pan_link: '',
          }}
          enableReinitialize={true}
          onSubmit={values => {
            handleSubmit(values);
          }}>
          {({
            handleChange,
            handleBlur,
            handleSubmit,
            errors,
            touched,
            values,
          }) => (
            <>
              <View
                style={{
                  width: width - 50,
                  height: height / 14,
                  margin: 5,
                  marginStart: 25,
                  backgroundColor: COLORS.pureWhite,
                  borderRadius: 10,
                  marginTop: 10,
                }}>
                <TextInput
                  placeholder="Company Name"
                  style={GLOBALSTYLES.textInput}
                  onChangeText={handleChange('company_name')}
                  onBlur={handleBlur('company_name')}
                  keyboardType="default"
                />
              </View>
              {errors.company_name && touched.company_name && (
                <Text style={GLOBALSTYLES.errorStyle}>
                  {errors.company_name}
                </Text>
              )}
              <View style={GLOBALSTYLES.textInputView}>
                <TextInput
                  placeholder="Contact Person*"
                  style={GLOBALSTYLES.textInput}
                  onChangeText={handleChange('contact_person')}
                  onBlur={handleBlur('contact_person')}
                  keyboardType="default"
                />
              </View>
              {errors.contact_person && touched.contact_person && (
                <Text style={GLOBALSTYLES.errorStyle}>
                  {errors.contact_person}
                </Text>
              )}
              {cnameTouched === true ? (
                <Text style={{color: 'red', fontSize: 15, alignSelf: 'center'}}>
                  {' '}
                  Value Already Exist
                </Text>
              ) : null}
              <View
                style={{
                  width: width - 50,
                  height: height / 14,
                  margin: 5,
                  marginStart: 25,
                  backgroundColor: COLORS.pureWhite,
                  flexDirection: 'row',

                  borderRadius: 10,
                }}>
                <View
                  style={{
                    justifyContent: 'center',
                    borderRadius: 10,
                    padding: 15,

                    backgroundColor: COLORS.whiteBlue,
                  }}>
                  <FontAwesome
                    color={COLORS.lightBlue}
                    name="phone"
                    size={25}
                    style={{right: 10, marginStart: 25}}
                  />
                </View>
                <TextInput
                  placeholder="Mobile*"
                  style={GLOBALSTYLES.textInput}
                  onChangeText={handleChange('contact_number')}
                  onBlur={handleBlur('contact_number')}
                  keyboardType="phone-pad"
                />
              </View>
              {errors.contact_number && touched.contact_number && (
                <Text style={GLOBALSTYLES.errorStyle}>
                  {errors.contact_number}
                </Text>
              )}
              {mobileTouched === true ? (
                <Text style={{color: 'red', fontSize: 15, alignSelf: 'center'}}>
                  {' '}
                  Value Already Exist
                </Text>
              ) : null}
              <View
                style={{
                  width: width - 50,
                  height: height / 14,
                  margin: 5,
                  marginStart: 25,
                  backgroundColor: COLORS.pureWhite,
                  flexDirection: 'row',

                  borderRadius: 10,
                }}>
                <View
                  style={{
                    justifyContent: 'center',
                    borderRadius: 10,
                    padding: 10,

                    backgroundColor: COLORS.whiteBlue,
                  }}>
                  <MaterialCommunityIcons
                    color={COLORS.lightBlue}
                    name="email-outline"
                    size={30}
                    style={{right: 12, marginStart: 25}}
                  />
                </View>
                <TextInput
                  placeholder="Email Id*"
                  style={GLOBALSTYLES.textInput}
                  onChangeText={handleChange('contact_email')}
                  onBlur={handleBlur('contact_email')}
                  keyboardType="email-address"
                />
              </View>
              {errors.contact_email && touched.contact_email && (
                <Text style={GLOBALSTYLES.errorStyle}>
                  {errors.contact_email}
                </Text>
              )}
              {emailTouched === true ? (
                <Text style={{color: 'red', fontSize: 15, alignSelf: 'center'}}>
                  {' '}
                  Value Already Exist
                </Text>
              ) : null}
              <View style={GLOBALSTYLES.textInputView}>
                <TextInput
                  placeholder="Company Address"
                  style={GLOBALSTYLES.textInput}
                  onChangeText={handleChange('company_address')}
                  onBlur={handleBlur('company_address')}
                  keyboardType="email-address"
                />
              </View>
              {errors.company_address && touched.company_address && (
                <Text style={GLOBALSTYLES.errorStyle}>
                  {errors.company_address}
                </Text>
              )}

              <View style={GLOBALSTYLES.textInputView}>
                <TextInput
                  placeholder="PAN Number"
                  style={GLOBALSTYLES.textInput}
                  onChangeText={handleChange('pan')}
                  onBlur={handleBlur('pan')}
                  keyboardType="default"
                />
              </View>
              {errors.pan && touched.pan && (
                <Text style={GLOBALSTYLES.errorStyle}>{errors.pan}</Text>
              )}
              <View style={GLOBALSTYLES.textInputView}>
                <TextInput
                  placeholder="Upload PAN"
                  style={GLOBALSTYLES.textInput}
                  onChangeText={handleChange('pan_link')}
                  onBlur={handleBlur('pan_link')}
                  keyboardType="default"
                />
              </View>
              {errors.pan_link && touched.pan_link && (
                <Text style={GLOBALSTYLES.errorStyle}>{errors.pan_link}</Text>
              )}
              <View style={GLOBALSTYLES.textInputView}>
                <TextInput
                  placeholder="GST Number"
                  style={GLOBALSTYLES.textInput}
                  onChangeText={handleChange('gst')}
                  onBlur={handleBlur('gst')}
                  keyboardType="default"
                />
              </View>
              {errors.gst && touched.gst && (
                <Text style={GLOBALSTYLES.errorStyle}>{errors.gst}</Text>
              )}
              <View style={GLOBALSTYLES.textInputView}>
                <TextInput
                  placeholder="Upload GST"
                  style={GLOBALSTYLES.textInput}
                  onChangeText={handleChange('gst_link')}
                  onBlur={handleBlur('gst_link')}
                  keyboardType="default"
                />
              </View>
              {errors.gst_link && touched.gst_link && (
                <Text style={GLOBALSTYLES.errorStyle}>{errors.gst_link}</Text>
              )}
              <View style={GLOBALSTYLES.textInputView}>
                <TextInput
                  placeholder="Agreement Attachment"
                  style={GLOBALSTYLES.textInput}
                  onChangeText={handleChange('agreement_link')}
                  onBlur={handleBlur('agreement_link')}
                  keyboardType="default"
                />
              </View>
              {errors.agreement_link && touched.agreement_link && (
                <Text style={GLOBALSTYLES.errorStyle}>
                  {errors.agreement_link}
                </Text>
              )}
            </>
          )}
        </Formik>
      </ScrollView>
      <TouchableOpacity
        style={{
          height: height / 14,
          width: width - 50,
          borderRadius: 10,
          alignSelf: 'center',
          bottom: 0,
          backgroundColor: COLORS.skyBlue,
          padding: 8,
          position: 'relative',
        }}
        onPress={() => {
          handleSubmit();
        }}>
        <Text style={GLOBALSTYLES.textStyle}>Submit</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
};
export default AddVendor;
