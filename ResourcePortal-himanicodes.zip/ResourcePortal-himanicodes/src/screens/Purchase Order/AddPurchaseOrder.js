import React, {useState, useEffect} from 'react';
import {
  SafeAreaView,
  ScrollView,
  Text,
  TextInput,
  View,
  ToastAndroid,
  TouchableOpacity,
  Dimensions,
  KeyboardAvoidingView,
  StyleSheet,
} from 'react-native';

import CustomNavigationBar from '../../components/CustomNavigationBar';
import {COLORS, GLOBALSTYLES, FONTS} from '../../constants/theme';
import {Picker} from '@react-native-picker/picker';
import {URL} from '../../constants/configure';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import DatePicker from 'react-native-datepicker/datepicker';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
const {height, width} = Dimensions.get('window');

const AddPurchaseOrder = ({navigation}) => {
  const [newData, setNewData] = useState([]);
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [id, setId] = useState('');
  const [idTouched, setidTouched] = useState(false);
  const [order, setOrder] = useState('');
  const [orderTouched, setorderTouched] = useState(false);
  const [sdateTouched, setsdateTouched] = useState(false);
  const [edateTouched, setedateTouched] = useState(false);

  const [title, setTitle] = useState('');
  const [titleTouched, settitleTouched] = useState(false);
  const [desTouched, setdesTouched] = useState(false);
  const [pdfTouched, setpdfTouched] = useState(false);
  const [description, setDescription] = useState('');
  const [pdf, setPdf] = useState('');

  useEffect(() => {
    getResource();
  }, []);

  const getResource = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
      console.log(requestOptions);
      const data = await axios.get(URL.BASE_URL + '/client', requestOptions);

      // console.log(data.data.data.clients);
      setNewData(data.data.data.clients);
    } catch (error) {
      console.log(error);
    }
  };
  //put
  const postUser = async () => {
    if (order === '') {
      setorderTouched(true);
    }
    if (startDate === '') {
      setsdateTouched(true);
    }
    if (endDate === '') {
      setedateTouched(true);
    }
    if (id === '') {
      setidTouched(true);
    }
    if (title === '') {
      settitleTouched(true);
    }
    if (description === '') {
      setdesTouched(true);
    }
    if (pdf === '') {
      setpdfTouched(true);
    }
    const store = {
      client_id: id,
      order_number: order,
      start_date: startDate,
      end_date: endDate,
      title: title,
      description: description,
      pdf_file: pdf,
    };
    console.log('valu--------', store);

    try {
      const token = await AsyncStorage.getItem('token');

      const requestOptions = {
        method: 'POST',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };

      const {data} = await axios.post(
        URL.BASE_URL + '/purchase',
        store,

        requestOptions,
      );
      console.log('check-------------->', data);
      if (data.message) {
        ToastAndroid.showWithGravity(
          'Purchase order created successfully',
          ToastAndroid.SHORT,
          ToastAndroid.BOTTOM,
        );
      }
      navigation.goBack();
    } catch (err) {
      console.log(err.response);
      ToastAndroid.showWithGravity(
        'Purchase order not created',
        ToastAndroid.SHORT,
        ToastAndroid.BOTTOM,
      );
    }
  };

  const clientsOptions = newData.filter(t => t.client_name !== null);
  return (
    <SafeAreaView style={GLOBALSTYLES.mainContainer}>
      <CustomNavigationBar back={true} headername="Add Purchase Order" />
      <ScrollView>
        <View style={{height: height / 1.2}}>
          <View
            style={{
              width: width - 50,
              height: height / 14,
              margin: 5,
              marginStart: 25,
              backgroundColor: COLORS.pureWhite,
              borderRadius: 10,

              marginTop: 10,
            }}>
            <Picker
              selectedValue={id}
              style={{margin: 5}}
              onValueChange={value => {
                setId(value);
                setidTouched(false);
              }}
              mode="dropdown">
              <Picker.Item label="Select Client" value="" color="grey" />
              {clientsOptions.map((item, index) => (
                <Picker.Item
                  key={item.id}
                  label={item.client_name}
                  value={item.id}
                />
              ))}
            </Picker>
          </View>
          {idTouched === true ? (
            <Text style={{color: 'red', fontSize: 15, alignSelf: 'center'}}>
              {' '}
              Field Required
            </Text>
          ) : null}
          <View style={GLOBALSTYLES.textInputView}>
            <TextInput
              placeholder="Purchase Order Number*"
              style={GLOBALSTYLES.textInput}
              value={order}
              onChangeText={data => {
                setOrder(data);
                setorderTouched(false);
              }}
            />
          </View>
          {orderTouched === true ? (
            <Text style={{color: 'red', fontSize: 15, alignSelf: 'center'}}>
              {' '}
              Field Required
            </Text>
          ) : null}
          <TouchableOpacity
            style={{
              width: width - 50,
              height: height / 14,
              margin: 5,
              flexDirection: 'row',
              justifyContent: 'space-between',
              backgroundColor: COLORS.pureWhite,
              marginStart: 25,
              borderRadius: 10,
            }}>
            <DatePicker
              style={{width: '100%', top: 7}}
              date={startDate}
              value={startDate}
              mode="date"
              placeholder="Start Date"
              format="DD MMMM YYYY"
              minDate="01 01 2016"
              maxDate="01 01 2025"
              confirmBtnText="Confirm"
              cancelBtnText="Cancel"
              showIcon={false}
              customStyles={{
                dateInput: {
                  borderWidth: 0,

                  position: 'absolute',
                  left: 20,
                  ...FONTS.appFontSemiBold,
                },
              }}
              onDateChange={startDate => {
                setStartDate(startDate);
                setsdateTouched(false);
              }}
            />
            <FontAwesome
              name="calendar-o"
              size={20}
              style={{alignSelf: 'center', right: 50}}
            />
          </TouchableOpacity>
          {sdateTouched === true ? (
            <Text style={{color: 'red', fontSize: 15, alignSelf: 'center'}}>
              {' '}
              Field Required
            </Text>
          ) : null}
          <TouchableOpacity
            style={{
              width: width - 50,
              height: height / 14,
              margin: 5,
              flexDirection: 'row',
              justifyContent: 'space-between',
              backgroundColor: COLORS.pureWhite,
              marginStart: 25,
              borderRadius: 10,
            }}>
            <DatePicker
              style={{width: '100%', top: 7}}
              date={endDate}
              value={endDate}
              mode="date"
              placeholder="End Date"
              format="DD MMMM YYYY"
              minDate="01 01 2016"
              maxDate="01 01 2025"
              confirmBtnText="Confirm"
              cancelBtnText="Cancel"
              showIcon={false}
              customStyles={{
                dateInput: {
                  borderWidth: 0,

                  position: 'absolute',
                  left: 20,
                  ...FONTS.appFontSemiBold,
                },
              }}
              onDateChange={endDate => {
                setEndDate(endDate);
                setedateTouched(false);
              }}
            />
            <FontAwesome
              name="calendar-o"
              size={20}
              style={{alignSelf: 'center', right: 50}}
            />
          </TouchableOpacity>
          {edateTouched === true ? (
            <Text style={{color: 'red', fontSize: 15, alignSelf: 'center'}}>
              {' '}
              Field Required
            </Text>
          ) : null}
          <View style={GLOBALSTYLES.textInputView}>
            <TextInput
              placeholder="Title"
              style={GLOBALSTYLES.textInput}
              value={title}
              onChangeText={data => {
                setTitle(data);
                settitleTouched(false);
              }}
            />
          </View>
          {titleTouched === true ? (
            <Text style={{color: 'red', fontSize: 15, alignSelf: 'center'}}>
              {' '}
              Field Required
            </Text>
          ) : null}
          <View
            style={{
              width: width - 50,
              height: height / 7,
              margin: 5,
              marginStart: 25,
              backgroundColor: COLORS.pureWhite,
              borderRadius: 10,
            }}>
            <TextInput
              placeholder="Description"
              style={{
                marginHorizontal: 20,
                ...FONTS.appFontSemiBold,

                marginTop: 1,
              }}
              value={description}
              onChangeText={data => {
                setDescription(data);
                setdesTouched(false);
              }}
            />
          </View>
          {desTouched === true ? (
            <Text style={{color: 'red', fontSize: 15, alignSelf: 'center'}}>
              {' '}
              Field Required
            </Text>
          ) : null}
          <View style={GLOBALSTYLES.textInputView}>
            <TextInput
              placeholder="Upload"
              style={GLOBALSTYLES.textInput}
              value={pdf}
              onChangeText={data => {
                setPdf(data);
                setpdfTouched(false);
              }}
            />
          </View>
          {pdfTouched === true ? (
            <Text
              style={{
                color: 'red',
                fontSize: 15,
                alignSelf: 'center',
                margintop: 10,
              }}>
              {' '}
              Field Required
            </Text>
          ) : null}
        </View>

        <View
          style={{
            flex: 1,
            flexDirection: 'column',
            justifyContent: 'space-between',
          }}>
          <TouchableOpacity
            style={styles.buttonStyle}
            onPress={() => postUser()}>
            <Text style={GLOBALSTYLES.textStyle}>Submit</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};
const styles = StyleSheet.create({
  buttonStyle: {
    backgroundColor: COLORS.skyBlue,
    width: width - 50,
    height: height / 14,
    borderRadius: 10,
    alignSelf: 'center',
    justifyContent: 'center',
    position: 'relative',
    bottom: 0,
  },
});
export default AddPurchaseOrder;
