import React, {useState, useEffect} from 'react';
import {
  SafeAreaView,
  FlatList,
  Text,
  TouchableOpacity,
  View,
  Button,
  Linking,
  ActivityIndicator,
  Dimensions,
} from 'react-native';
import SearchBox from '../../components/SearchBox';
import {COLORS, GLOBALSTYLES, FONTS} from '../../constants/theme';
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';
import {URL} from '../../constants/configure';
const {height, width} = Dimensions.get('window');

const PurchaseOrderMaster = ({navigation}) => {
  const [newData, setNewData] = useState([]);
  const [loding, setLoding] = useState(true);
  const [search, setSearch] = useState('');
  const [filterData, setFilterData] = useState([]);

  useEffect(() => {
    getResource();
    getAccountFilterData();
  }, [search, loding, newData]);

  //get

  const getResource = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
      // console.log(requestOptions);
      const data = await axios.get(URL.BASE_URL + '/purchase', requestOptions);

      // console.log(data.data.data.purchase);
      setNewData(data.data.data.purchase);
      setLoding(false);
    } catch (error) {
      console.log(error);
      setLoding(true);
    }
  };

  const setSearchValue = value => {
    setSearch(value);
  };
  const getAccountFilterData = () => {
    if (!loding) {
      const filterValue = newData?.filter(data => {
        if (search.length === 0) {
          return data;
        } else if (
          (data.title &&
            data.title.toLowerCase().includes(search.toLowerCase())) ||
          (data.clients?.client_name &&
            data.clients?.client_name
              .toLowerCase()
              .includes(!!search && search.toLowerCase())) ||
          (data.order_number &&
            data.order_number.toLowerCase().includes(search.toLowerCase())) ||
          (data.description &&
            data.description.toLowerCase().includes(search.toLowerCase())) ||
          data.start_date.includes(search) ||
          data.end_date.includes(search)
        ) {
          console.log(data);
          return data;
        }
      });
      setFilterData(filterValue);
    }
  };

  return (
    <SafeAreaView style={GLOBALSTYLES.mainContainer}>
      <SearchBox search={search} setSearchValue={setSearchValue} />
      {loding ? (
        <ActivityIndicator
          animating={true}
          size="large"
          style={{
            opacity: 1,
            position: 'absolute',
            left: 0,
            right: 0,
            top: 0,
            bottom: 0,
            alignItems: 'center',
            justifyContent: 'center',
          }}
        />
      ) : (
        <FlatList
          data={filterData}
          renderItem={({item}) => (
            <View style={GLOBALSTYLES.appContainer}>
              <View style={GLOBALSTYLES.lebalView}>
                <Text style={GLOBALSTYLES.lebal}>Client Name</Text>
                <View style={GLOBALSTYLES.contentView}>
                  <Text style={GLOBALSTYLES.content}>
                    {item.clients === null ? '-' : item?.clients.client_name}
                  </Text>
                </View>
              </View>
              <View style={GLOBALSTYLES.lebalView}>
                <Text style={GLOBALSTYLES.lebal}>Title</Text>
                <View style={GLOBALSTYLES.contentView}>
                  <Text style={GLOBALSTYLES.content}>
                    {item.title === null ? '-' : item.title}
                  </Text>
                </View>
              </View>
              <View style={GLOBALSTYLES.lebalView}>
                <Text style={GLOBALSTYLES.lebal}>Description</Text>
                <View style={GLOBALSTYLES.contentView}>
                  <Text style={GLOBALSTYLES.content}>
                    {item.description === null ? '-' : item.description}
                  </Text>
                </View>
              </View>
              <View
                style={{flexDirection: 'row', justifyContent: 'space-between'}}>
                <View
                  style={{
                    flexDirection: 'column',
                  }}>
                  <View style={GLOBALSTYLES.lebalView}>
                    <Text style={GLOBALSTYLES.lebal}>Order Number</Text>

                    <Text style={GLOBALSTYLES.content}>
                      {item.order_number === null ? '-' : item.order_number}
                    </Text>
                  </View>

                  <View style={GLOBALSTYLES.lebalView}>
                    <Text style={GLOBALSTYLES.lebal}>Start Date</Text>

                    <Text style={GLOBALSTYLES.content}>
                      {item.start_date === null ? '-' : item.start_date}
                    </Text>
                  </View>
                </View>
                <View
                  style={{
                    flexDirection: 'column',
                  }}>
                  <View style={GLOBALSTYLES.secondlabelView}>
                    <Text style={GLOBALSTYLES.lebal}>PDF</Text>

                    <Text
                      style={{
                        ...FONTS.appFontSemiBold,
                        color: COLORS.skyBlue,
                        marginStart: 3,
                      }}
                      onPress={() => {
                        Linking.openURL(
                          item.pdf_file === null ? '-' : item.pdf_file,
                        );
                      }}>
                      View
                    </Text>
                  </View>

                  <View style={GLOBALSTYLES.secondlabelView}>
                    <Text style={GLOBALSTYLES.lebal}>End Date</Text>
                    <Text style={GLOBALSTYLES.content}>
                      {item.end_date === null ? '-' : item.end_date}
                    </Text>
                  </View>
                </View>
              </View>
              <TouchableOpacity
                onPress={() =>
                  navigation.navigate('Edit Purchase Order', {newData: item})
                }
                style={{
                  backgroundColor: COLORS.skyBlue,
                  width: width / 1.2,
                  height: height / 14.5,
                  borderRadius: 10,
                  alignSelf: 'center',
                  margin: 10,
                }}>
                <Text
                  style={{
                    alignSelf: 'center',
                    ...FONTS.appFontSemi,
                    marginVertical: 23,
                    color: COLORS.pureWhite,
                    fontWeight: 'bold',
                  }}>
                  Edit
                </Text>
              </TouchableOpacity>
            </View>
          )}
        />
      )}
    </SafeAreaView>
  );
};

export default PurchaseOrderMaster;
