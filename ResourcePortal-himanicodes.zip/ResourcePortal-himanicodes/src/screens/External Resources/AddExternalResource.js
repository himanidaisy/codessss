import React, {useState, useEffect} from 'react';
import {
  SafeAreaView,
  ScrollView,
  Text,
  TextInput,
  View,
  TouchableOpacity,
  StyleSheet,
  ToastAndroid,
  Dimensions,
} from 'react-native';
import * as yup from 'yup';
import {Formik} from 'formik';
import {URL} from '../../constants/configure';
import CustomNavigationBar from '../../components/CustomNavigationBar';
import {GLOBALSTYLES, COLORS, FONTS} from '../../constants/theme';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import {Picker} from '@react-native-picker/picker';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import KeyboardAvoidingView from 'react-native/Libraries/Components/Keyboard/KeyboardAvoidingView';

const {height, width} = Dimensions.get('window');

const AddExternalResource = ({navigation}) => {
  const [newData, setNewData] = useState([]);
  const [technologys, setTechnologys] = useState([]);
  const [vendors, setVendors] = useState([]);

  useEffect(() => {
    getResource();
    getVendor();
    getTechnology();
  }, []);

  const validationSchema = yup.object().shape({
    vendor_id: yup.string().required('Vendor is Reqired'),
    fname: yup.string().required('First Name is Required'),
    lname: yup.string().required('Last Name is Required'),
    phone: yup.string().required('Contact Number is Required'),
    email: yup.string().required('Email is Required'),
    language: yup.string().required('Language is Required'),
    resident_address: yup.string().required('Resident Address is Required'),
    resume: yup.string().required('Resume Link is Required'),
    checklist: yup.string().required('Check List is Required'),
    other_docs: yup.string().required('Other Document is required'),
    passing_year: yup.string().required('Passing Year is Required'),
    cost: yup.string().required('Cost is Required'),
    aadhar_link: yup.string().required('Aadhar Attache is Required'),
    pan_link: yup.string().required('Pan Attached is Required'),
    pf_opt_out_form_link: yup.string().required('PF option is Required'),
    l1: yup.number().required('L1 is Required'),
    exp_date: yup.string(),
  });
  const getResource = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
      // console.log(requestOptions);
      const data = await axios.get(
        URL.BASE_URL + '/external-resource',
        requestOptions,
      );

      // console.log(data.data.data.externalResource);

      setNewData(data.data.data.externalResource);
    } catch (error) {
      console.log(error);
    }
  };
  const getVendor = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
      // console.log(requestOptions);
      const data = await axios.get(URL.BASE_URL + '/vendor', requestOptions);

      // console.log(data.data.data.externalResource);

      setVendors(data.data.data.vendors);
    } catch (error) {
      console.log(error);
    }
  };
  const getTechnology = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
      // console.log(requestOptions);
      const data = await axios.get(
        URL.BASE_URL + '/technology',
        requestOptions,
      );

      // console.log(data.data.data.externalResource);

      setTechnologys(data.data.data.technologies);
    } catch (error) {
      console.log(error);
    }
  };

  //post
  const postUser = async values => {
    console.log('store------>', values);
    try {
      const token = await AsyncStorage.getItem('token');

      const requestOptions = {
        method: 'POST',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };

      const {data} = await axios.post(
        URL.BASE_URL + '/external-resource',
        values,
        requestOptions,
      );
      console.log('check-------------->', data);
      if (data.message) {
        ToastAndroid.showWithGravity(
          'External created successfully',
          ToastAndroid.SHORT,
          ToastAndroid.BOTTOM,
        );
      }
      navigation.goBack();
    } catch (err) {
      console.log(err.response);
      ToastAndroid.showWithGravity(
        'External not created',
        ToastAndroid.SHORT,
        ToastAndroid.BOTTOM,
      );
    }
  };

  const clientsOptions = vendors.filter(t => t.company_name !== null);
  const technologyCheck = technologys.filter(t => t.technology !== null);
  // const expDate= newData.filter(t=>t.exp_date !== null)
  const l1 = newData.map(e => e.l1);
  // console.log('---------',l1 )

  const handleSubmit = values => {
    postUser(values);
  };
  return (
    <SafeAreaView style={GLOBALSTYLES.mainContainer}>
      <CustomNavigationBar back={true} headername="Add External Resource" />

      <ScrollView>
        <Formik
          validationSchema={validationSchema}
          initialValues={{
            vendor_id: '',
            fname: '',
            lname: '',
            phone: '',
            email: '',
            language: '',
            resident_address: '',
            resume: '',
            checklist: '',
            other_docs: '',
            passing_year: '',
            cost: '',
            aadhar_link: '',
            pan_link: '',
            pf_opt_out_form_link: '',
            l1: '',
            exp_date: '',
          }}
          enableReinitialize={true}
          onSubmit={values => {
            handleSubmit(values);
          }}>
          {({
            handleChange,
            handleBlur,
            handleSubmit,
            errors,
            touched,
            values,
            setFieldValue,
          }) => (
            <>
              <View
                style={{
                  width: width - 50,
                  height: height / 14,
                  margin: 5,
                  flexDirection: 'row',
                  backgroundColor: COLORS.pureWhite,
                  marginStart: 25,
                  borderRadius: 10,
                  marginTop: 10,
                }}>
                <Picker
                  style={GLOBALSTYLES.textInput}
                  selectedValue={values.vendor_id}
                  mode="dropdown"
                  onValueChange={itemValue =>
                    setFieldValue('vendor_id', itemValue)
                  }>
                  <Picker.Item label="Vendor List" value="" color="grey" />

                  {clientsOptions.map((item, index) => (
                    <Picker.Item
                      key={item.id}
                      label={item.company_name}
                      value={item.id}
                    />
                  ))}
                </Picker>
              </View>
              {errors.vendor_id && touched.vendor_id && (
                <Text style={GLOBALSTYLES.errorStyle}>{errors.vendor_id}</Text>
              )}
              <View style={GLOBALSTYLES.textInputView}>
                <TextInput
                  placeholder="First Name*"
                  style={GLOBALSTYLES.textInput}
                  value={values.fname}
                  onChangeText={handleChange('fname')}
                  onBlur={handleBlur('fname')}
                  keyboardType="default"
                />
              </View>
              {errors.fname && touched.fname && (
                <Text style={GLOBALSTYLES.errorStyle}>{errors.fname}</Text>
              )}

              <View style={GLOBALSTYLES.textInputView}>
                <TextInput
                  placeholder="Last Name*"
                  style={GLOBALSTYLES.textInput}
                  value={values.lname}
                  onChangeText={handleChange('lname')}
                  onBlur={handleBlur('lname')}
                  keyboardType="default"
                />
              </View>
              {errors.lname && touched.lname && (
                <Text style={GLOBALSTYLES.errorStyle}>{errors.lname}</Text>
              )}

              <View
                style={{
                  width: width - 50,
                  height: height / 14,
                  margin: 5,
                  flexDirection: 'row',
                  backgroundColor: COLORS.pureWhite,
                  marginStart: 25,
                  borderRadius: 10,
                }}>
                <View
                  style={{
                    justifyContent: 'center',
                    borderRadius: 10,
                    padding: 15,
                    backgroundColor: COLORS.whiteBlue,
                  }}>
                  <FontAwesome
                    color={COLORS.lightBlue}
                    name="phone"
                    size={25}
                    style={{right: 15, marginStart: 30}}
                  />
                </View>
                <TextInput
                  placeholder="Phone Number*"
                  style={GLOBALSTYLES.textInput}
                  value={values.phone}
                  onChangeText={handleChange('phone')}
                  onBlur={handleBlur('phone')}
                  keyboardType="default"
                />
              </View>
              {errors.phone && touched.phone && (
                <Text style={GLOBALSTYLES.errorStyle}>{errors.phone}</Text>
              )}
              <View
                style={{
                  width: width - 50,
                  height: height / 14,
                  margin: 5,
                  flexDirection: 'row',
                  backgroundColor: COLORS.pureWhite,
                  marginStart: 25,
                  borderRadius: 10,
                }}>
                <View
                  style={{
                    justifyContent: 'center',
                    borderRadius: 10,
                    padding: 10,

                    backgroundColor: COLORS.whiteBlue,
                  }}>
                  <MaterialCommunityIcons
                    color={COLORS.lightBlue}
                    name="email-outline"
                    size={30}
                    style={{right: 15, marginStart: 30}}
                  />
                </View>
                <TextInput
                  placeholder="Email Id*"
                  style={GLOBALSTYLES.textInput}
                  value={values.email}
                  onChangeText={handleChange('email')}
                  onBlur={handleBlur('email')}
                  keyboardType="default"
                />
              </View>
              {errors.email && touched.email && (
                <Text style={GLOBALSTYLES.errorStyle}>{errors.email}</Text>
              )}

              <View style={GLOBALSTYLES.textInputView}>
                <Picker
                  selectedValue={values.language}
                  style={GLOBALSTYLES.textInput}
                  onValueChange={itemValue =>
                    setFieldValue('language', itemValue)
                  }
                  mode="dropdown">
                  <Picker.Item label="Select Language" value="" color="grey" />

                  {technologyCheck.map((item, index) => (
                    <Picker.Item
                      key={item.id}
                      label={item.technology}
                      value={item.id}
                    />
                  ))}
                </Picker>
              </View>
              {errors.language && touched.language && (
                <Text style={GLOBALSTYLES.errorStyle}>{errors.language}</Text>
              )}
              <View style={GLOBALSTYLES.textInputView}>
                <Picker
                  selectedValue={values.exp_date}
                  mode="dropdown"
                  style={GLOBALSTYLES.textInput}
                  onValueChange={itemValue =>
                    setFieldValue('exp_date', itemValue)
                  }>
                  <Picker.Item
                    label="Select Experience Year*"
                    value=""
                    color="grey"
                  />
                  <Picker.Item label="0.5 year" />
                  <Picker.Item label="1 year" />
                  <Picker.Item label="1.5 year" />
                  <Picker.Item label="2 year" />
                  <Picker.Item label="2.5 year" />
                  <Picker.Item label="3 year" />
                  <Picker.Item label="3.5 year" />
                  <Picker.Item label="4 year" />
                  <Picker.Item label="4.5 year" />
                  <Picker.Item label="5 year" />
                  <Picker.Item label="5.5 year" />
                  <Picker.Item label="6 year" />
                  <Picker.Item label="6.5 year" />
                  <Picker.Item label="7 year" />
                  <Picker.Item label="7.5 year" />
                  <Picker.Item label="8 year" />
                  <Picker.Item label="8.5 year" />
                  <Picker.Item label="9 year" />
                  <Picker.Item label="9.5 year" />
                  <Picker.Item label="10 year" />
                  <Picker.Item label="10.5 year" />
                  <Picker.Item label="11 year" />
                  <Picker.Item label="11.5 year" />
                  <Picker.Item label="12 year" />
                  <Picker.Item label="12.5 year" />
                </Picker>
              </View>
              {errors.exp_date && touched.exp_date && (
                <Text style={GLOBALSTYLES.errorStyle}>{errors.exp_date}</Text>
              )}
              <View style={GLOBALSTYLES.textInputView}>
                <TextInput
                  placeholder=" Residential Address"
                  style={GLOBALSTYLES.textInput}
                  value={values.resident_address}
                  onChangeText={handleChange('resident_address')}
                  onBlur={handleBlur('resident_address')}
                  keyboardType="default"
                />
              </View>
              {errors.resident_address && touched.resident_address && (
                <Text style={GLOBALSTYLES.errorStyle}>
                  {errors.resident_address}
                </Text>
              )}

              <View style={GLOBALSTYLES.textInputView}>
                <TextInput
                  placeholder="  Upload Resume"
                  style={GLOBALSTYLES.textInput}
                  value={values.resume}
                  onChangeText={handleChange('resume')}
                  onBlur={handleBlur('resume')}
                  keyboardType="default"
                />
              </View>
              {errors.resume && touched.resume && (
                <Text style={GLOBALSTYLES.errorStyle}>{errors.resume}</Text>
              )}
              <View style={GLOBALSTYLES.textInputView}>
                <TextInput
                  placeholder="Check List"
                  style={GLOBALSTYLES.textInput}
                  value={values.checklist}
                  onChangeText={handleChange('checklist')}
                  onBlur={handleBlur('checklist')}
                  keyboardType="default"
                />
              </View>
              {errors.checklist && touched.checklist && (
                <Text style={GLOBALSTYLES.errorStyle}>{errors.checklist}</Text>
              )}
              <View style={GLOBALSTYLES.textInputView}>
                <TextInput
                  placeholder="Other Document"
                  style={GLOBALSTYLES.textInput}
                  value={values.other_docs}
                  onChangeText={handleChange('other_docs')}
                  onBlur={handleBlur('other_docs')}
                  keyboardType="default"
                />
              </View>
              {errors.other_docs && touched.other_docs && (
                <Text style={GLOBALSTYLES.errorStyle}>{errors.other_docs}</Text>
              )}

              <View style={GLOBALSTYLES.textInputView}>
                <TextInput
                  placeholder="Passing year*"
                  style={GLOBALSTYLES.textInput}
                  value={values.passing_year}
                  onChangeText={handleChange('passing_year')}
                  onBlur={handleBlur('passing_year')}
                  keyboardType="default"
                />
              </View>
              {errors.passing_year && touched.passing_year && (
                <Text style={GLOBALSTYLES.errorStyle}>
                  {errors.passing_year}
                </Text>
              )}

              <View style={GLOBALSTYLES.textInputView}>
                <TextInput
                  placeholder="Cost*"
                  style={GLOBALSTYLES.textInput}
                  value={values.cost}
                  onChangeText={handleChange('cost')}
                  onBlur={handleBlur('cost')}
                  keyboardType="default"
                />
              </View>
              {errors.cost && touched.cost && (
                <Text style={GLOBALSTYLES.errorStyle}>{errors.cost}</Text>
              )}
              <View style={GLOBALSTYLES.textInputView}>
                <TextInput
                  placeholder="Adhaar Link*"
                  style={GLOBALSTYLES.textInput}
                  value={values.aadhar_link}
                  onChangeText={handleChange('aadhar_link')}
                  onBlur={handleBlur('aadhar_link')}
                  keyboardType="default"
                />
              </View>
              {errors.aadhar_link && touched.aadhar_link && (
                <Text style={GLOBALSTYLES.errorStyle}>
                  {errors.aadhar_link}
                </Text>
              )}

              <View style={GLOBALSTYLES.textInputView}>
                <TextInput
                  placeholder="Pan Link*"
                  style={GLOBALSTYLES.textInput}
                  value={values.pan_link}
                  onChangeText={handleChange('pan_link')}
                  onBlur={handleBlur('pan_link')}
                  keyboardType="default"
                />
              </View>
              {errors.pan_link && touched.pan_link && (
                <Text style={GLOBALSTYLES.errorStyle}>{errors.pan_link}</Text>
              )}

              <View style={GLOBALSTYLES.textInputView}>
                <TextInput
                  placeholder="PF Opt Out Link"
                  style={GLOBALSTYLES.textInput}
                  value={values.pf_opt_out_form_link}
                  onChangeText={handleChange('pf_opt_out_form_link')}
                  onBlur={handleBlur('pf_opt_out_form_link')}
                  keyboardType="default"
                />
              </View>
              {errors.pf_opt_out_form_link && touched.pf_opt_out_form_link && (
                <Text style={GLOBALSTYLES.errorStyle}>
                  {errors.pf_opt_out_form_link}
                </Text>
              )}
              <View style={GLOBALSTYLES.textInputView}>
                <Picker
                  selectedValue={values.l1}
                  mode="dropdown"
                  style={GLOBALSTYLES.textInput}
                  onValueChange={itemValue => setFieldValue('l1', itemValue)}>
                  <Picker.Item label="L1" value="" color="grey" />

                  <Picker.Item label="Yes" value={1} />
                  <Picker.Item label="No" value={0} />
                </Picker>
              </View>
              {errors.l1 && touched.l1 && (
                <Text style={GLOBALSTYLES.errorStyle}>{errors.l1}</Text>
              )}
            </>
          )}
        </Formik>
      </ScrollView>

      <TouchableOpacity
        style={styles.buttonStyle}
        onPress={() => {
          handleSubmit();
        }}>
        <Text style={GLOBALSTYLES.textStyle}>Submit</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
};
const styles = StyleSheet.create({
  buttonStyle: {
    backgroundColor: COLORS.skyBlue,
    width: width - 50,
    height: height / 13,
    borderRadius: 10,
    alignSelf: 'center',
    justifyContent: 'center',
    position: 'relative',
    top: 0,
  },
});
export default AddExternalResource;
