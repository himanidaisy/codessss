import React, {useState, useEffect} from 'react';
import {
  Text,
  View,
  SafeAreaView,
  TouchableOpacity,
  TextInput,
  ToastAndroid,
  Animatable,
  Dimensions,
  StyleSheet,
} from 'react-native';
import {RadioButton} from 'react-native-paper';

import CustomNavigationBar from '../../components/CustomNavigationBar';
import {COLORS, FONTS, GLOBALSTYLES} from '../../constants/theme';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import {Picker} from '@react-native-picker/picker';
import axios from 'axios';
import EmailIcon from 'react-native-vector-icons/MaterialCommunityIcons';
import CheckBox from '@react-native-community/checkbox';
const {height, width} = Dimensions.get('window');
import AsyncStorage from '@react-native-async-storage/async-storage';
import {ScrollView} from 'react-native-gesture-handler';
import style from 'react-native-datepicker/style';

const AddClient = ({navigation}) => {
  const [newData, setNewData] = useState([]);
  const [ex, setEx] = useState([]);
  const [cname, setcname] = useState('');
  const [rname, setrname] = useState('');
  const [rcontact, setrcontact] = useState('');
  const [remail, setremail] = useState('');
  const [hname, sethname] = useState('');
  const [hcontact, sethcontact] = useState('');
  const [hemail, sethemail] = useState('');
  const [iname, setiname] = useState('');
  const [icontact, seticontact] = useState('');
  const [iemail, setiemail] = useState('');
  const [aname, setaname] = useState('');
  const [aemail, setaemail] = useState('');
  const [acontact, setacontact] = useState('');
  const [url, seturl] = useState('');
  const [address, setaddress] = useState('');
  const [description, setdescription] = useState('');
  const [baddress, setbaddress] = useState('');
  const [oaddress, setoaddress] = useState('');
  const [pan, setpan] = useState('');
  const [gst, setgst] = useState('');
  const [tan, settan] = useState('');
  const [creditperiod, setcreditperiod] = useState('');
  const [idate, setIdate] = useState('');
  const [nationaliti, setNationaliti] = useState('');
  const [checked, setChecked] = useState('');
  const [masine, setMasine] = useState('');
  const [weekend, setWeekend] = useState('');
  const [sign, setSign] = useState('');
  const [invoice, setInvoice] = useState('');
  const [physical, setPhysical] = useState('');
  const [purchase, setPurchase] = useState('');
  const [product, setProduct] = useState('');
  const [proof, setProof] = useState('');
  const [extern, setExtern] = useState('');
  const [map, setMap] = useState('');
  const [need, setNeed] = useState('');

  useEffect(() => {
    getResource();
    getExternal();
  }, []);

  const getResource = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
      console.log(requestOptions);
      const data = await axios.get(
        'http://newresourcing.nimapinfotech.com/api/client',
        requestOptions,
      );

      //  console.log(data.data.data.clientAgreements);

      setNewData(data.data.data.clients);
    } catch (error) {
      console.log(error);
    }
  };

  //get
  const getExternal = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
      // console.log(requestOptions);
      const data = await axios.get(
        URL.BASE_URL + '/external-products',
        requestOptions,
      );

      // console.log(data.data.data.product);
      setEx(data.data.data.product);
      // console.log('che---------')
    } catch (error) {
      console.log(error);
    }
  };
  const postUser = async () => {
    const store = {
      client_name: cname,
      reporting_name: rname,
      reporting_contact: rcontact,
      reporting_email: remail,
      hr_name: hname,
      hr_contact: hcontact,
      hr_email: hemail,
      Interviewer_name: iname,
      Interviewer_contact: icontact,
      Interviewer_email: iemail,
      account_name: aname,
      account_email: aemail,
      account_mobile: acontact,
      url: url,
      address: address,
      description: description,
      billing_address: baddress,
      operational_address: oaddress,
      pan: pan,
      gst: gst,
      tan: tan,
      credit_period: creditperiod,
      invoice_date: idate,
      nationality: nationaliti,
      need_timesheet: checked,
      need_machine: masine,
      weekend_working: weekend,
      aggrement_sign: sign,
      first_invoice: invoice,
      is_pruchase_ord_req: purchase,
      is_external_product: product,
      pf_proof: proof,
      address_map_link: map,
      is_invoice_need: need,
    };

    console.log('checkv--------', store);
    try {
      const token = await AsyncStorage.getItem('token');

      const requestOptions = {
        method: 'POST',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };

      const {data} = await axios.post(
        'http://newresourcing.nimapinfotech.com/api/client',
        store,
        requestOptions,
      );

      console.log('valuecheck------------->', data);
      if (data.message) {
        ToastAndroid.showWithGravity(
          ' Client added successfully',
          ToastAndroid.SHORT,
          ToastAndroid.BOTTOM,
        );
      }
      navigation.goBack();
    } catch (err) {
      // console.log(err.response)
      ToastAndroid.showWithGravity(
        'Client not added',
        ToastAndroid.SHORT,
        ToastAndroid.BOTTOM,
      );
    }
  };
  const clientsOptions = ex.filter(t => t.name !== null);
  // const languageOptions = newData.filter(t => t.languages !== null);
  // const experienceOptions = newData.filter(t => t.exp_date !== null);

  return (
    <SafeAreaView style={GLOBALSTYLES.mainContainer}>
      <ScrollView>
        <CustomNavigationBar back={true} headername="AddClientMaster" />

        <View
          style={{
            width: width - 50,
            height: height / 15,
            margin: 5,
            flexDirection: 'row',
            backgroundColor: COLORS.pureWhite,
            marginStart: 25,
            borderRadius: 10,
            marginTop: 10,
          }}>
          <TextInput
            placeholder="Client Name"
            style={GLOBALSTYLES.textInput}
            value={cname}
            onChangeText={data => {
              setcname(data);
            }}
          />
        </View>

        <View style={GLOBALSTYLES.textInputView}>
          <TextInput
            placeholder="Reporting Manager Name"
            style={GLOBALSTYLES.textInput}
            value={rname}
            onChangeText={data => {
              setrname(data);
            }}
          />
        </View>
        <View
          style={{
            width: width - 50,
            height: height / 15,
            margin: 5,
            flexDirection: 'row',
            backgroundColor: COLORS.pureWhite,
            marginStart: 25,
            borderRadius: 10,
          }}>
          <View
            style={{
              justifyContent: 'center',
              borderRadius: 10,
              padding: 12,

              backgroundColor: COLORS.whiteBlue,
            }}>
            <FontAwesome
              name="phone"
              size={25}
              style={{right: 12, marginStart: 25}}
            />
          </View>

          <TextInput
            placeholder="Reporting Manager Contact"
            style={GLOBALSTYLES.textInput}
            value={rcontact}
            onChangeText={data => {
              setrcontact(data);
            }}
          />
        </View>
        <View
          style={{
            width: width - 50,
            height: height / 15,
            margin: 5,
            flexDirection: 'row',
            backgroundColor: COLORS.pureWhite,
            marginStart: 25,
            borderRadius: 10,
          }}>
          <View
            style={{
              justifyContent: 'center',
              borderRadius: 10,
              padding: 8,
              backgroundColor: COLORS.whiteBlue,
            }}>
            <EmailIcon
              name="email-outline"
              size={30}
              style={{right: 12, marginStart: 25}}
            />
          </View>
          <TextInput
            placeholder="Reporting Manager Email"
            style={GLOBALSTYLES.textInput}
            value={remail}
            onChangeText={data => {
              setremail(data);
            }}
          />
        </View>

        <View style={GLOBALSTYLES.textInputView}>
          <TextInput
            placeholder="HR Name"
            style={GLOBALSTYLES.textInput}
            value={hname}
            onChangeText={data => {
              sethname(data);
            }}
          />
        </View>
        <View
          style={{
            width: width - 50,
            height: height / 15,
            margin: 5,
            flexDirection: 'row',
            backgroundColor: COLORS.pureWhite,
            marginStart: 25,
            borderRadius: 10,
          }}>
          <View
            style={{
              justifyContent: 'center',
              borderRadius: 10,
              padding: 12,

              backgroundColor: COLORS.whiteBlue,
            }}>
            <FontAwesome
              name="phone"
              size={25}
              style={{right: 12, marginStart: 25}}
            />
          </View>

          <TextInput
            placeholder="HR Contact"
            style={GLOBALSTYLES.textInput}
            value={hcontact}
            onChangeText={data => {
              sethcontact(data);
            }}
          />
        </View>
        <View
          style={{
            width: width - 50,
            height: height / 15,
            margin: 5,
            flexDirection: 'row',
            backgroundColor: COLORS.pureWhite,
            marginStart: 25,
            borderRadius: 10,
          }}>
          <View
            style={{
              justifyContent: 'center',
              borderRadius: 10,
              padding: 8,
              backgroundColor: COLORS.whiteBlue,
            }}>
            <EmailIcon
              name="email-outline"
              size={30}
              style={{right: 12, marginStart: 25}}
            />
          </View>
          <TextInput
            placeholder="HR Email"
            style={GLOBALSTYLES.textInput}
            value={hemail}
            onChangeText={data => {
              sethemail(data);
            }}
          />
        </View>

        <View style={GLOBALSTYLES.textInputView}>
          <TextInput
            placeholder="Interviewer Name"
            style={GLOBALSTYLES.textInput}
            value={iname}
            onChangeText={data => {
              setiname(data);
            }}
          />
        </View>
        <View
          style={{
            width: width - 50,
            height: height / 15,
            margin: 5,
            flexDirection: 'row',
            backgroundColor: COLORS.pureWhite,
            marginStart: 25,
            borderRadius: 10,
          }}>
          <View
            style={{
              justifyContent: 'center',
              borderRadius: 10,
              padding: 12,

              backgroundColor: COLORS.whiteBlue,
            }}>
            <FontAwesome
              name="phone"
              size={25}
              style={{right: 12, marginStart: 25}}
            />
          </View>

          <TextInput
            placeholder="Interviewer Contact"
            style={GLOBALSTYLES.textInput}
            value={icontact}
            onChangeText={data => {
              seticontact(data);
            }}
          />
        </View>
        <View
          style={{
            width: width - 50,
            height: height / 15,
            margin: 5,
            flexDirection: 'row',
            backgroundColor: COLORS.pureWhite,
            marginStart: 25,
            borderRadius: 10,
          }}>
          <View
            style={{
              justifyContent: 'center',
              borderRadius: 10,
              padding: 8,
              backgroundColor: COLORS.whiteBlue,
            }}>
            <EmailIcon
              name="email-outline"
              size={30}
              style={{right: 12, marginStart: 25}}
            />
          </View>
          <TextInput
            placeholder="Interviewer Email"
            style={GLOBALSTYLES.textInput}
            value={iemail}
            onChangeText={data => {
              setiemail(data);
            }}
          />
        </View>

        <View style={GLOBALSTYLES.textInputView}>
          <TextInput
            placeholder="Finance Name"
            style={GLOBALSTYLES.textInput}
            value={aname}
            onChangeText={data => {
              setaname(data);
            }}
          />
        </View>
        <View
          style={{
            width: width - 50,
            height: height / 15,
            margin: 5,
            flexDirection: 'row',
            backgroundColor: COLORS.pureWhite,
            marginStart: 25,
            borderRadius: 10,
          }}>
          <View
            style={{
              justifyContent: 'center',
              borderRadius: 10,
              padding: 12,

              backgroundColor: COLORS.whiteBlue,
            }}>
            <FontAwesome
              name="phone"
              size={25}
              style={{right: 12, marginStart: 25}}
            />
          </View>

          <TextInput
            placeholder="Finance Phone"
            style={GLOBALSTYLES.textInput}
            value={acontact}
            onChangeText={data => {
              setacontact(data);
            }}
          />
        </View>
        <View
          style={{
            width: width - 50,
            height: height / 15,
            margin: 5,
            flexDirection: 'row',
            backgroundColor: COLORS.pureWhite,
            marginStart: 25,
            borderRadius: 10,
          }}>
          <View
            style={{
              justifyContent: 'center',
              borderRadius: 10,
              padding: 8,
              backgroundColor: COLORS.whiteBlue,
            }}>
            <EmailIcon
              name="email-outline"
              size={30}
              style={{right: 12, marginStart: 25}}
            />
          </View>
          <TextInput
            placeholder="Finance Email"
            style={GLOBALSTYLES.textInput}
            value={aemail}
            onChangeText={data => {
              setaemail(data);
            }}
          />
        </View>

        <View style={GLOBALSTYLES.textInputView}>
          <TextInput
            placeholder="URL"
            style={GLOBALSTYLES.textInput}
            value={url}
            onChangeText={data => {
              seturl(data);
            }}
          />
        </View>

        <View style={styles.textInputView}>
          <TextInput
            placeholder="Residential Address"
            style={GLOBALSTYLES.textInput}
            value={address}
            onChangeText={data => {
              setaddress(data);
            }}
          />
        </View>
        <View style={styles.textInputView}>
          <TextInput
            placeholder="Description"
            style={GLOBALSTYLES.textInput}
            value={description}
            onChangeText={data => {
              setdescription(data);
            }}
          />
        </View>
        <View style={styles.textInputView}>
          <TextInput
            placeholder="Billing Address"
            style={GLOBALSTYLES.textInput}
            value={baddress}
            onChangeText={data => {
              setbaddress(data);
            }}
          />
        </View>
        <View style={styles.textInputView}>
          <TextInput
            placeholder="Operational Address"
            style={GLOBALSTYLES.textInput}
            value={oaddress}
            onChangeText={data => {
              setoaddress(data);
            }}
          />
        </View>

        <View style={GLOBALSTYLES.textInputView}>
          <TextInput
            placeholder="PAN Number"
            style={GLOBALSTYLES.textInput}
            value={pan}
            onChangeText={data => {
              setpan(data);
            }}
          />
        </View>
        <View style={GLOBALSTYLES.textInputView}>
          <TextInput
            placeholder="GST Number"
            style={GLOBALSTYLES.textInput}
            value={gst}
            onChangeText={data => {
              setgst(data);
            }}
          />
        </View>
        <View style={GLOBALSTYLES.textInputView}>
          <TextInput
            placeholder="TAN Number"
            style={GLOBALSTYLES.textInput}
            value={tan}
            onChangeText={data => {
              settan(data);
            }}
          />
        </View>
        <View style={GLOBALSTYLES.textInputView}>
          <TextInput
            placeholder="Map"
            style={GLOBALSTYLES.textInput}
            value={map}
            onChangeText={data => {
              setMap(data);
            }}
          />
        </View>
        <View style={GLOBALSTYLES.textInputView}>
          <TextInput
            placeholder="Credit Period"
            style={GLOBALSTYLES.textInput}
            value={creditperiod}
            onChangeText={data => {
              setcreditperiod(data);
            }}
          />
        </View>
        {/* <View style={GLOBALSTYLES.textInputView}>
          <Picker
            selectedValue={idate}
            mode="dropdown"
            style={GLOBALSTYLES.textInput}
            onValueChange={data => setIdate(data)}>
            <Picker.Item label="Date of Invoice" value="" color="grey" />
            <Picker.Item label="1st of Months"  />
            <Picker.Item label="15th of Months" />
            <Picker.Item label="30th of Months" />
            <Picker.Item label="1st Of Next Months" />
            <Picker.Item label="15th Of Next Months" />
            <Picker.Item label="30th Of Next Months" />
          </Picker>
        </View> */}
        <View style={GLOBALSTYLES.textInputView}>
          <Picker
            selectedValue={idate}
            onValueChange={value => setIdate(value)}
            mode="dropdown">
            <Picker.Item label="Date of Invoice" value="" color="grey" />
            <Picker.Item label="1st of Months" value="1st of Months" />
            <Picker.Item label="15th of Months" value="15th of Months" />
            <Picker.Item label="30th of Months" value="30th of Months" />
            <Picker.Item
              label="1st Of Next Months"
              value="1st Of Next Months"
            />
            <Picker.Item
              label="15th Of Next Months"
              value="15th Of Next Months"
            />
            <Picker.Item
              label="30th Of Next Months"
              value="30th Of Next Months"
            />
          </Picker>
        </View>

        <View style={GLOBALSTYLES.textInputView}>
          <Picker
            selectedValue={nationaliti}
            mode="dropdown"
            style={GLOBALSTYLES.textInput}
            onValueChange={data => setNationaliti(data)}>
            <Picker.Item label="Select Nationality" value="" color="grey" />
            <Picker.Item label="Indian" value="Indian" />
            <Picker.Item label="Other" value="Other" />
          </Picker>
        </View>

        <View style={styles.appContainer}>
          <View style={styles.lebalView}>
            <Text>Do You Need Timesheet?</Text>
          </View>

          <View style={styles.checkboxContainer}>
            <RadioButton.Group
              onValueChange={newValue => setChecked(newValue)}
              value={checked}>
              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  marginStart: 15,
                }}>
                <View>
                  <RadioButton value="N" />
                  <Text style={styles.radiotext}>No</Text>
                </View>
                <View style={styles.buttonContainer}>
                  <RadioButton value="Y" />
                  <Text style={styles.yradiotext}>Yes</Text>
                </View>
              </View>
            </RadioButton.Group>
          </View>
          <View style={styles.lebalView}>
            <Text>Do You Need Machine?</Text>
          </View>
          <View style={styles.checkboxContainer}>
            <RadioButton.Group
              onValueChange={newValue => setMasine(newValue)}
              value={masine}>
              <View
                style={{
                  flexDirection: 'row',
                  marginStart: 15,
                  justifyContent: 'space-between',
                }}>
                <View>
                  <RadioButton value="N" />
                  <Text style={styles.radiotext}>No</Text>
                </View>
                <View style={styles.buttonContainer}>
                  <RadioButton value="Y" />
                  <Text style={styles.yradiotext}>Yes</Text>
                </View>
              </View>
            </RadioButton.Group>
          </View>
          <View style={styles.lebalView}>
            <Text>Weekend Working?</Text>
          </View>
          <View style={styles.checkboxContainer}>
            <RadioButton.Group
              onValueChange={newValue => setWeekend(newValue)}
              value={weekend}>
              <View
                style={{
                  flexDirection: 'row',
                  marginStart: 15,
                  justifyContent: 'space-between',
                }}>
                <View>
                  <RadioButton value="N" />
                  <Text style={styles.radiotext}>No</Text>
                </View>
                <View style={styles.buttonContainer}>
                  <RadioButton value="Y" />
                  <Text style={styles.yradiotext}>Yes</Text>
                </View>
              </View>
            </RadioButton.Group>
          </View>
          <View style={styles.lebalView}>
            <Text>Agreement Sign?</Text>
          </View>
          <View style={styles.checkboxContainer}>
            <RadioButton.Group
              onValueChange={newValue => setSign(newValue)}
              value={sign}>
              <View
                style={{
                  flexDirection: 'row',
                  marginStart: 15,
                  justifyContent: 'space-between',
                }}>
                <View>
                  <RadioButton value="N" />
                  <Text style={styles.radiotext}>No</Text>
                </View>
                <View style={styles.buttonContainer}>
                  <RadioButton value="Y" />
                  <Text style={styles.yradiotext}>Yes</Text>
                </View>
              </View>
            </RadioButton.Group>
          </View>
          <View style={styles.lebalView}>
            <Text>First Invoice Send?</Text>
          </View>
          <View style={styles.checkboxContainer}>
            <RadioButton.Group
              onValueChange={newValue => setInvoice(newValue)}
              value={invoice}>
              <View
                style={{
                  flexDirection: 'row',
                  marginStart: 15,
                  justifyContent: 'space-between',
                }}>
                <View>
                  <RadioButton value="N" />
                  <Text style={styles.radiotext}>No</Text>
                </View>
                <View style={styles.buttonContainer}>
                  <RadioButton value="Y" />
                  <Text style={styles.yradiotext}>Yes</Text>
                </View>
              </View>
            </RadioButton.Group>
          </View>
          <View style={styles.lebalView}>
            <Text>Pf Proof Needed</Text>
          </View>
          <View style={styles.checkboxContainer}>
            <RadioButton.Group
              onValueChange={newValue => setProof(newValue)}
              value={proof}>
              <View
                style={{
                  flexDirection: 'row',
                  marginStart: 15,
                  justifyContent: 'space-between',
                }}>
                <View>
                  <RadioButton value="N" />
                  <Text style={styles.radiotext}>No</Text>
                </View>
                <View style={styles.buttonContainer}>
                  <RadioButton value="Y" />
                  <Text style={styles.yradiotext}>Yes</Text>
                </View>
              </View>
            </RadioButton.Group>
          </View>
          <View style={styles.lebalView}>
            <Text>Physical Copy Needed?</Text>
          </View>
          <View style={styles.checkboxContainer}>
            <RadioButton.Group
              onValueChange={newValue => setPhysical(newValue)}
              value={physical}>
              <View
                style={{
                  flexDirection: 'row',
                  marginStart: 15,
                  justifyContent: 'space-between',
                }}>
                <View>
                  <RadioButton value="N" />
                  <Text style={styles.radiotext}>No</Text>
                </View>
                <View style={styles.buttonContainer}>
                  <RadioButton value="Y" />
                  <Text style={styles.yradiotext}>Yes</Text>
                </View>
              </View>
            </RadioButton.Group>
          </View>
          <View style={styles.lebalView}>
            <Text>Is Purchase Order Required?</Text>
          </View>
          <View style={styles.checkboxContainer}>
            <RadioButton.Group
              onValueChange={newValue => setPurchase(newValue)}
              value={purchase}>
              <View
                style={{
                  flexDirection: 'row',
                  marginStart: 15,
                  justifyContent: 'space-between',
                }}>
                <View>
                  <RadioButton value="N" />
                  <Text style={styles.radiotext}>No</Text>
                </View>
                <View style={styles.buttonContainer}>
                  <RadioButton value="Y" />
                  <Text style={styles.yradiotext}>Yes</Text>
                </View>
              </View>
            </RadioButton.Group>
          </View>
          <View style={styles.lebalView}>
            <Text>Is External Product?</Text>
          </View>
          <View style={styles.checkboxContainer}>
            <RadioButton.Group
              onValueChange={newValue => setProduct(newValue)}
              value={product}>
              <View
                style={{
                  flexDirection: 'row',
                  marginStart: 15,
                  justifyContent: 'space-between',
                }}>
                <View>
                  <RadioButton value="N" />
                  <Text style={styles.radiotext}>No</Text>
                </View>
                <View style={styles.buttonContainer}>
                  <RadioButton value="Y" />
                  <Text style={styles.yradiotext}>Yes</Text>
                </View>
              </View>
            </RadioButton.Group>
          </View>
          <View style={styles.lebalView}>
            <Text>Is Invoice Needed</Text>
          </View>
          <View style={styles.checkboxContainer}>
            <RadioButton.Group
              onValueChange={newValue => setNeed(newValue)}
              value={need}>
              <View
                style={{
                  flexDirection: 'row',
                  marginStart: 15,
                  justifyContent: 'space-between',
                }}>
                <View>
                  <RadioButton value="N" />
                  <Text style={styles.radiotext}>No</Text>
                </View>
                <View style={styles.buttonContainer}>
                  <RadioButton value="Y" />
                  <Text style={styles.yradiotext}>Yes</Text>
                </View>
              </View>
            </RadioButton.Group>
          </View>
          {/* <View
          style={GLOBALSTYLES.textInputView}>
          <Picker
            selectedValue={extern}
            style={GLOBALSTYLES.textInput}
            onValueChange={value => setExtern(value)}
            mode="dropdown">
            <Picker.Item label="Select" value="" color='grey' />
            {clientsOptions.map((item, index) => (
              <Picker.Item
                key={item.id}
                label={item.name}
                value={item.id}
              />
            ))}
          </Picker>
        </View> */}

          <View style={{flexDirection: 'row', margin: 10}}>
            <TouchableOpacity
              style={GLOBALSTYLES.editBtn}
              onPress={() => postUser()}>
              <Text style={GLOBALSTYLES.editText}>Add</Text>
            </TouchableOpacity>
            <TouchableOpacity style={GLOBALSTYLES.deleteBtn}>
              <Text style={GLOBALSTYLES.deleteText}>Cancel</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};
const styles = StyleSheet.create({
  appContainer: {
    flex: 1,
    margin: 25,
    backgroundColor: COLORS.pureWhite,
    marginVertical: '1%',
    padding: 10,
    borderRadius: 10,
    backgroundColor: COLORS.pureWhite,
  },
  textInputView: {
    width: width - 50,
    height: height / 7,
    margin: 5,
    marginStart: 25,
    backgroundColor: COLORS.pureWhite,
    borderRadius: 10,
  },
  lebalView: {
    flexDirection: 'column',
    padding: 20,
  },
  lebal: {
    ...FONTS.appFontSemiBold,
    color: 'grey',
    padding: 2,
  },
  content: {
    ...FONTS.appFontSemiBold,
    color: 'black',
    margin: 2,
  },
  buttonContainer: {
    position: 'relative',
    right: 100,
  },
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  radiotext: {
    marginStart: 10,
  },
  yradiotext: {
    marginLeft: 7,
  },
  checkbox: {
    alignSelf: 'center',
    marginLeft: 15,
  },

  secondcheckbox: {
    alignSelf: 'center',
    position: 'relative',
    start: 90,
  },
  label: {
    margin: 8,
  },
  secondlabel: {
    margin: 8,
    position: 'relative',
    left: 90,
  },
  textInput: {},
});
export default AddClient;
