import React, {useState, useEffect} from 'react';
import {
  Text,
  View,
  SafeAreaView,
  TouchableOpacity,
  TextInput,
  ToastAndroid,
  Dimensions,
} from 'react-native';
import CustomNavigationBar from '../../components/CustomNavigationBar';
import {COLORS, FONTS, GLOBALSTYLES} from '../../constants/theme';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import {Picker} from '@react-native-picker/picker';
import axios from 'axios';
import DatePicker from 'react-native-datepicker';

import {URL} from '../../constants/configure';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {ScrollView} from 'react-native-gesture-handler';
const {height, width} = Dimensions.get('window');

const AddClientAgreement = ({navigation}) => {
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [newData, setNewData] = useState([]);
  const [id, setId] = useState('');
  const [sdateTouched, setsdateTouched] = useState(false);
  const [edateTouched, setedateTouched] = useState(false);
  const [idTouched, setidTouched] = useState(false);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  // const [drive, setDrive] = useState('');
  const [upload, setUpload] = useState('');
  const [titleTouched, setTitleTouched] = useState(false);
  const [desTouched, setDesTouched] = useState(false);
  const [linkTouched, setlinkTouched] = useState(false);

  useEffect(() => {
    getResource();
  }, []);

  const getResource = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
      console.log(requestOptions);
      const data = await axios.get(URL.BASE_URL + '/client', requestOptions);

      //  console.log(data.data.data.clientAgreements);

      setNewData(data.data.data.clients);
    } catch (error) {
      console.log(error);
    }
  };

  const postUser = async () => {
    if (title === '') {
      setTitleTouched(true);
    }
    if (description === '') {
      setDesTouched(true);
    }
    if (upload === '') {
      setlinkTouched(true);
    }
    if (endDate === '') {
      setedateTouched(true);
    }
    if (startDate === '') {
      setsdateTouched(true);
    }
    if (id === '') {
      setidTouched(true);
    }

    const store = {
      client_id: id,
      start_date: startDate,
      end_date: endDate,
      title: title,
      description: description,
      pdf_file: upload,
    };

    // console.log('checkv--------', store);
    try {
      const token = await AsyncStorage.getItem('token');

      const requestOptions = {
        method: 'POST',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };

      const {data} = await axios.post(
        URL.BASE_URL + '/client-agreement',
        store,
        requestOptions,
      );

      // console.log('valuecheck------------->',data);
      if (data.message) {
        ToastAndroid.showWithGravity(
          ' Client Agreement added successfully',
          ToastAndroid.SHORT,
          ToastAndroid.BOTTOM,
        );
      }
      navigation.goBack();
    } catch (err) {
      // console.log(err.response)
      ToastAndroid.showWithGravity(
        'Client Agreement not Added',
        ToastAndroid.SHORT,
        ToastAndroid.BOTTOM,
      );
    }
  };

  const clientsOptions = newData.filter(t => t.client_name !== null);

  return (
    <SafeAreaView style={GLOBALSTYLES.mainContainer}>
      <CustomNavigationBar back={true} headername="Add Client Agreement" />
      <ScrollView>
        <View style={{height: height / 1.2}}>
          <View
            style={{
              width: width - 50,
              height: height / 14,
              margin: 5,
              marginStart: 25,
              backgroundColor: COLORS.pureWhite,
              borderRadius: 10,
              marginTop: 10,
            }}>
            <Picker
              selectedValue={id}
              style={{margin: 4, bottom: 0}}
              mode="dropdown"
              onValueChange={value => {
                setId(value);
                setidTouched(false);
              }}>
              <Picker.Item label=" Client Name" value="" color="grey" />
              {clientsOptions.map((item, index) => (
                <Picker.Item
                  key={item.id}
                  label={item.client_name}
                  value={item.id}
                />
              ))}
            </Picker>
          </View>
          {idTouched === true ? (
            <Text style={{color: 'red', fontSize: 15, alignSelf: 'center'}}>
              {' '}
              Field Required
            </Text>
          ) : null}
          <View
            style={{
              width: width - 50,
              height: height / 14,
              margin: 5,
              flexDirection: 'row',
              justifyContent: 'space-between',
              backgroundColor: COLORS.pureWhite,
              marginStart: 25,
              borderRadius: 10,
            }}>
            <DatePicker
              style={{width: '100%', top: 7}}
              date={startDate}
              value={startDate}
              mode="date"
              placeholder="Start Date"
              format="DD MMMM YYYY"
              minDate="01 01 2016"
              maxDate="01 01 2025"
              confirmBtnText="Confirm"
              cancelBtnText="Cancel"
              showIcon={false}
              customStyles={{
                dateInput: {
                  borderWidth: 0,

                  position: 'absolute',
                  left: 20,
                  ...FONTS.appFontSemiBold,
                },
              }}
              onDateChange={startDate => {
                setStartDate(startDate);
                setsdateTouched(false);
              }}
            />
            <FontAwesome
              name="calendar-o"
              size={20}
              style={{alignSelf: 'center', right: 50}}
            />
          </View>
          {sdateTouched === true ? (
            <Text style={{color: 'red', fontSize: 15, alignSelf: 'center'}}>
              {' '}
              Field Required
            </Text>
          ) : null}
          <View
            style={{
              width: width - 50,
              height: height / 14,
              margin: 5,
              flexDirection: 'row',
              justifyContent: 'space-between',
              backgroundColor: COLORS.pureWhite,
              marginStart: 25,
              borderRadius: 10,
            }}>
            <DatePicker
              style={{width: '100%', top: 7}}
              date={endDate}
              value={endDate}
              mode="date"
              placeholder="End Date"
              format="DD MMMM YYYY"
              minDate="01 01 2016"
              maxDate="01 01 2025"
              confirmBtnText="Confirm"
              cancelBtnText="Cancel"
              showIcon={false}
              customStyles={{
                dateInput: {
                  borderWidth: 0,

                  position: 'absolute',
                  left: 20,
                  ...FONTS.appFontSemiBold,
                },
              }}
              onDateChange={endDate => {
                setEndDate(endDate);
                setedateTouched(false);
              }}
            />
            <FontAwesome
              name="calendar-o"
              size={20}
              style={{alignSelf: 'center', right: 50}}
            />
          </View>
          {edateTouched === true ? (
            <Text style={{color: 'red', fontSize: 15, alignSelf: 'center'}}>
              {' '}
              Field Required
            </Text>
          ) : null}
          <View style={GLOBALSTYLES.textInputView}>
            <TextInput
              placeholder="Title"
              style={GLOBALSTYLES.textInput}
              value={title}
              maxLength={20}
              onChangeText={data => {
                setTitle(data);
                setTitleTouched(false);
              }}
            />
          </View>
          {titleTouched === true ? (
            <Text style={{color: 'red', fontSize: 15, alignSelf: 'center'}}>
              {' '}
              Field Required
            </Text>
          ) : null}
          <View
            style={{
              width: width - 50,
              height: height / 7,
              margin: 5,
              marginStart: 25,
              backgroundColor: COLORS.pureWhite,
              borderRadius: 10,
            }}>
            <TextInput
              placeholder="Description"
              style={{
                marginHorizontal: 20,
                ...FONTS.appFontSemiBold,
                marginTop: 1,
              }}
              value={description}
              maxLength={100}
              onChangeText={data => {
                setDescription(data);
                setDesTouched(false);
              }}
            />
          </View>
          {desTouched === true ? (
            <Text style={{color: 'red', fontSize: 15, alignSelf: 'center'}}>
              {' '}
              Field Required
            </Text>
          ) : null}

          <View style={GLOBALSTYLES.textInputView}>
            <TextInput
              placeholder="Drive Link"
              style={GLOBALSTYLES.textInput}
              value={upload}
              onChangeText={data => {
                setUpload(data);
                setlinkTouched(false);
              }}
            />
          </View>
          {linkTouched === true ? (
            <Text style={{color: 'red', fontSize: 15, alignSelf: 'center'}}>
              {' '}
              Field Required
            </Text>
          ) : null}
        </View>
        <View
          style={{
            flex: 1,
            flexDirection: 'column',
            justifyContent: 'space-between',
          }}>
          <TouchableOpacity
            style={{
              backgroundColor: COLORS.skyBlue,
              width: width - 50,
              padding: 5,
              borderRadius: 10,
              alignSelf: 'center',
              bottom: 0,
              position: 'relative',
            }}
            onPress={() => postUser()}>
            <Text style={GLOBALSTYLES.textStyle}>Submit</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};
export default AddClientAgreement;
