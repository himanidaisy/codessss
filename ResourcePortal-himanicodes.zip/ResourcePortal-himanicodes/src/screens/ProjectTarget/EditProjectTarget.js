import React, {useState, useEffect} from 'react';
import {
  Text,
  View,
  SafeAreaView,
  StyleSheet,
  TouchableOpacity,
  ToastAndroid,
  Dimensions,
} from 'react-native';
import CustomNavigationBar from '../../components/CustomNavigationBar';
import {COLORS, FONTS, GLOBALSTYLES} from '../../constants/theme';
import {Picker} from '@react-native-picker/picker';
import {URL} from '../../constants/configure';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import DatePicker from 'react-native-datepicker';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
const {height, width} = Dimensions.get('window');

const EditProjectTarget = ({route, navigation}) => {
  const [id, setId] = useState('');
  const [newData, setNewData] = useState([]);
  const [startDate, setStartDate] = useState('');
  const [data, setData] = useState({});

  console.log('valuess', route.params.newData.id);
  useEffect(() => {
    getResource();
    setData(route.params.newData);
    setStartDate(route.params.newData.date);
    setId(route.params.newData.resource);
  }, []);
  console.log('get----------', route.params.newData);

  const getResource = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
      console.log(requestOptions);
      const data = await axios.get(URL.BASE_URL + '/resource', requestOptions);

      // console.log(data.data.data.projectTarget);

      setNewData(data.data.data.resources);
    } catch (error) {
      console.log(error);
    }
  };
  //put
  const putUser = async () => {
    const store = {
      resource: id,
      date: startDate,
    };
    console.log('check------------->>>>', store);

    try {
      const token = await AsyncStorage.getItem('token');

      const requestOptions = {
        method: 'PUT',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };

      const {data} = await axios.put(
        URL.BASE_URL + `/project-target/${id}`,
        store,
        requestOptions,
      );
      setData(route.params.newData);
      if (data.message) {
        ToastAndroid.showWithGravity(
          'Project Target Edited successfully',
          ToastAndroid.SHORT,
          ToastAndroid.BOTTOM,
        );
      }
      navigation.goBack();
    } catch (err) {
      ToastAndroid.showWithGravity(
        'Project Target not Edited',
        ToastAndroid.SHORT,
        ToastAndroid.BOTTOM,
      );
    }
  };

  const clientsOptions = newData.filter(t => t.fname !== null);
  return (
    <SafeAreaView style={GLOBALSTYLES.mainContainer}>
      <CustomNavigationBar back={true} headername="Edit Project Target" />
      <View
        style={{
          width: width - 50,
          height: height / 14,
          margin: 5,
          marginStart: 25,
          backgroundColor: COLORS.pureWhite,
          borderRadius: 10,
          marginTop: 10,
        }}>
        <Picker
          selectedValue={id}
          style={{margin: 4, bottom: 5}}
          onValueChange={value => setId(value)}
          mode="dropdown">
          <Picker.Item label="Select Resource" value="" color="grey" />
          {clientsOptions.map((item, index) => (
            <Picker.Item key={item.id} label={item.fname} value={item.id} />
          ))}
        </Picker>
      </View>
      <TouchableOpacity
        style={{
          width: width - 50,
          height: height / 14,
          margin: 5,
          flexDirection: 'row',
          justifyContent: 'space-between',
          backgroundColor: COLORS.pureWhite,
          marginStart: 25,
          borderRadius: 10,
        }}>
        <DatePicker
          style={{width: '100%', top: 5}}
          date={startDate}
          value={startDate}
          mode="date"
          placeholder="Start Date"
          format="DD MMMM YYYY"
          confirmBtnText="Confirm"
          cancelBtnText="Cancel"
          showIcon={false}
          customStyles={{
            dateInput: {
              borderWidth: 0,
              position: 'absolute',
              left: 20,
              ...FONTS.appFontSemiBold,
            },
          }}
          onDateChange={startDate => {
            setStartDate(startDate);
          }}
        />
        <FontAwesome
          name="calendar-o"
          size={20}
          style={{alignSelf: 'center', right: 50}}
        />
      </TouchableOpacity>

      <TouchableOpacity
        style={GLOBALSTYLES.buttonStyle}
        onPress={() => putUser()}>
        <Text style={GLOBALSTYLES.textStyle}>Submit</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
};

export default EditProjectTarget;
