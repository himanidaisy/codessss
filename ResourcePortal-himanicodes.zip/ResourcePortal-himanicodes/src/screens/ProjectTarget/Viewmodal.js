import React, {useState, useEffect} from 'react';
import {
  Text,
  View,
  SafeAreaView,
  TouchableOpacity,
  Alert,
  Modal,
  StyleSheet,
  TextInput,
  Dimensions,
  ActivityIndicator,
  FlatList,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {URL} from '../../constants/configure';
import {COLORS, GLOBALSTYLES} from '../../constants/theme';
import axios from 'axios';
const {height, width} = Dimensions.get('window');
const ViewModal = ({navigation}) => {
  const [newData, setNewData] = useState([]);
  const [loding, setLoding] = useState(true);
  const [modalVisible, setModalVisible] = useState(true);

  useEffect(() => {
    getResource();
  }, []);

  //get
  const getResource = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
      // console.log(requestOptions);
      const data = await axios.get(URL.RESOURCEMASTERGET_URL, requestOptions);
      //  console.log('find------------------->',data.data.data.projectTarget[0]);
      setNewData(data.data.data.resources);

      setLoding(false);
    } catch (error) {
      console.log(error);
      setLoding(true);
    }
  };
  return (
    <SafeAreaView>
      <FlatList
        data={newData}
        renderItem={({item}) => (
          <Modal
            animationType="fade"
            transparent={true}
            visible={modalVisible}
            onRequestClose={() => {
              Alert.alert('modal closed');
              setModalVisible(!modalVisible);
            }}>
            <View style={styles.modalView}>
              <View style={GLOBALSTYLES.lebalView}>
                <Text style={GLOBALSTYLES.lebal}>Name</Text>
                <View style={GLOBALSTYLES.contentView}>
                  <Text style={GLOBALSTYLES.content}>
                    {item.fname === null ? '-' : item.fname}
                  </Text>
                </View>
              </View>
              <View style={GLOBALSTYLES.lebalView}>
                <Text style={GLOBALSTYLES.lebal}>Address</Text>
                <View style={GLOBALSTYLES.contentView}>
                  <Text style={GLOBALSTYLES.content}>
                    {item.resident_address === null
                      ? '-'
                      : item.resident_address}
                  </Text>
                </View>
              </View>
              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                }}>
                <View style={GLOBALSTYLES.lebalView}>
                  <Text style={GLOBALSTYLES.lebal}>Email Id</Text>

                  <Text style={GLOBALSTYLES.content}>
                    {item.email === null ? '-' : item.email}
                  </Text>
                </View>
                <View style={GLOBALSTYLES.lebalView}>
                  <Text style={GLOBALSTYLES.lebal}>Mobile</Text>

                  <Text style={GLOBALSTYLES.content}>
                    {item.phone === null ? '-' : item.phone}
                  </Text>
                </View>
              </View>
              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                }}>
                <View style={GLOBALSTYLES.lebalView}>
                  <Text style={GLOBALSTYLES.lebal}>Language</Text>

                  <Text style={GLOBALSTYLES.content}>
                    {item.languages === null
                      ? '-'
                      : item?.languages[0].technology}
                  </Text>
                </View>
                <View
                  style={{
                    right: 50,
                    flexDirection: 'column',
                    // padding: 10,
                    margin: 10,
                  }}>
                  <Text style={GLOBALSTYLES.lebal}>CV</Text>
                  <TouchableOpacity>
                    <Text
                      style={{
                        fontSize: 15,
                        color: COLORS.blue,
                        marginStart: 4,
                      }}
                      onPress={() => {
                        Linking.openURL(
                          item.resume === null ? '-' : item.resume,
                        );
                      }}>
                      View
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                }}>
                <View style={GLOBALSTYLES.lebalView}>
                  <Text style={GLOBALSTYLES.lebal}>Vendor</Text>

                  <Text style={GLOBALSTYLES.content}>
                    {item.vendor == null ? '-' : item?.vendor?.company_name}
                  </Text>
                </View>
                <View style={GLOBALSTYLES.lebalView}>
                  <Text style={GLOBALSTYLES.lebal}>Passing Year</Text>

                  <Text style={GLOBALSTYLES.content}>
                    {item.passing_year === null ? '-' : item.passing_year}
                  </Text>
                </View>
              </View>
              <View style={GLOBALSTYLES.lebalView}>
                <Text style={GLOBALSTYLES.lebal}>Status</Text>
                <View style={GLOBALSTYLES.contentView}>
                  <Text style={GLOBALSTYLES.content}>
                    {item.on_bench === null ? '-' : item.on_bench}
                  </Text>
                </View>
              </View>
              <View style={{flexDirection: 'row'}}>
                <TouchableOpacity
                  style={styles.cancelButton}
                  onPress={() => navigation.navigate('ProjectTarget')}>
                  <Text style={styles.cancelButtonText}>Edit</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.cancelButton}
                  onPress={() => navigation.navigate('ProjectTarget')}>
                  <Text style={styles.cancelButtonText}>Cancel</Text>
                </TouchableOpacity>
              </View>
            </View>
          </Modal>
        )}
      />
    </SafeAreaView>
  );
};
const styles = StyleSheet.create({
  cancelButton: {
    backgroundColor: 'grey',
    borderRadius: 10,
    padding: '5%',
    margin: '2%',
    position: 'relative',
    alignSelf: 'center',
    marginStart: '20%',
  },
  cancelButtonText: {
    color: 'black',
    fontSize: 15,
  },

  lebalView: {
    flexDirection: 'column',
    margin: 10,
  },
  modalView: {
    width: width - 50,
    backgroundColor: 'white',
    borderRadius: 10,
    alignSelf: 'center',
    marginTop: width / 2.4,
    height: height / 2,
  },
});
export default ViewModal;
