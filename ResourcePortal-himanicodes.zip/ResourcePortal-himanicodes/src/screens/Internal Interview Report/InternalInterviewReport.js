import React, {useEffect, useState} from 'react';
import {
  Text,
  View,
  SafeAreaView,
  TouchableOpacity,
  FlatList,
  ActivityIndicator,
  ToastAndroid,
  Dimensions,
} from 'react-native';
import {GLOBALSTYLES, COLORS, FONTS} from '../../constants/theme';
import SearchBox from '../../components/SearchBox';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {URL} from '../../constants/configure';
import {Picker} from '@react-native-picker/picker';
const {height, width} = Dimensions.get('window');

const InternalInterviewReport = ({navigation}) => {
  const [newData, setNewData] = useState([]);
  const [loding, setLoding] = useState(true);
  const [search, setSearch] = useState('');
  const [filterData, setFilterData] = useState([]);
  const [status, setStatus] = useState('');

  useEffect(() => {
    getResource();
    getAccountFilterData();
  }, [search, loding, newData]);

  //get

  const getResource = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
      // console.log(requestOptions);
      const data = await axios.get(
        URL.BASE_URL + '/external-interviews',
        requestOptions,
      );

      // console.log(data.data.data.technologies);
      setNewData(data.data.data.externalinterview);
      setLoding(false);
    } catch (error) {
      console.log(error);
      setLoding(true);
    }
  };

  const setSearchValue = value => {
    setSearch(value);
  };
  const getAccountFilterData = () => {
    if (!loding) {
      const filterValue = newData?.filter(data => {
        if (search.length === 0) {
          return data;
        } else if (
          data.company_name.toLowerCase().includes(search.toLowerCase()) ||
          data.contact_person.toLowerCase().includes(search.toLowerCase()) ||
          data.contact_number.toLowerCase().includes(search.toLowerCase()) ||
          data.contact_email.toLowerCase().includes(search.toLowerCase()) ||
          data.pan.toLowerCase().includes(search.toLowerCase()) ||
          data.gst.toLowerCase().includes(search.toLowerCase())
        ) {
          // console.log(data);
          return data;
        }
      });
      setFilterData(filterValue);
    }
  };

  const deleteUser = async values => {
    console.log('check__', values);
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'DELETE',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
      const {data} = await axios.delete(
        `http://newresourcing.nimapinfotech.com/api/external-interviews/${values}`,
        //  values,
        requestOptions,
      );
      // console.log(data);
      setSearch('');
      const remaningData = newData.filter(t => t.id !== values);
      setFilterData([...remaningData]);
      if (data.message) {
        ToastAndroid.showWithGravity(
          'External Interview Deleted successfully',
          ToastAndroid.SHORT,
          ToastAndroid.BOTTOM,
        );
      }
    } catch (err) {
      // console.log(err.response);
      ToastAndroid.showWithGravity(
        'External Interview not deleted',
        ToastAndroid.SHORT,
        ToastAndroid.BOTTOM,
      );
    }
  };

  const handleDelete = item => {
    console.log('Delte hit', deleteUser(item.id));
    // deleteUser(item.id);
    getResource();
    console.log('check id', item.id);
  };

  return (
    <SafeAreaView style={GLOBALSTYLES.mainContainer}>
      <SearchBox search={search} setSearchValue={setSearchValue} />
      {loding ? (
        <ActivityIndicator
          animating={true}
          size="large"
          style={{
            opacity: 1,
            position: 'absolute',
            left: 0,
            right: 0,
            top: 0,
            bottom: 0,
            alignItems: 'center',
            justifyContent: 'center',
          }}
        />
      ) : (
        <FlatList
          data={filterData}
          renderItem={({item}) => (
            <View style={GLOBALSTYLES.appContainer}>
              <View style={GLOBALSTYLES.lebalView}>
                <Text style={GLOBALSTYLES.lebal}>Resources</Text>
                <View style={GLOBALSTYLES.contentView}>
                  <Text style={GLOBALSTYLES.content}>
                    {item.resource === null ? '-' : item.resource}
                  </Text>
                </View>
              </View>

              <View
                style={{flexDirection: 'row', justifyContent: 'space-between'}}>
                <View style={GLOBALSTYLES.lebalView}>
                  <Text style={GLOBALSTYLES.lebal}>Client</Text>

                  <Text style={GLOBALSTYLES.content}>
                    {item.client === null ? '-' : item.client}
                  </Text>
                </View>
                <View style={{flexDirection: 'column', margin: 10, right: 10}}>
                  <Text style={GLOBALSTYLES.lebal}>Mode</Text>

                  <Text style={GLOBALSTYLES.content}>
                    {item.mode === null ? '-' : item.mode}
                  </Text>
                </View>
              </View>
              <View
                style={{flexDirection: 'row', justifyContent: 'space-between'}}>
                <View style={GLOBALSTYLES.lebalView}>
                  <Text style={GLOBALSTYLES.lebal}>Date & Time</Text>

                  <Text style={GLOBALSTYLES.content}>
                    {item.datetime === null ? '-' : item.datetime}
                  </Text>
                </View>
                <View
                  style={{
                    width: width / 1,
                    height: height / 14,
                    // margin: 5,
                    marginStart: 20,
                    backgroundColor: COLORS.pureWhite,
                    borderRadius: 10,
                  }}>
                  <Text>Status</Text>
                  <View
                    style={{
                      ...FONTS.appFontSemiBold,
                      marginTop: 1,
                    }}>
                    <Picker
                      selectedValue={status}
                      mode="dropdown"
                      onValueChange={itemValue => setStatus(itemValue)}>
                      <Picker.Item label="Status" value="" color="grey" />

                      <Picker.Item label="Selected" value="Selected" />
                      <Picker.Item label="Rejected" value="Rejected" />
                      <Picker.Item label="OnHold" value="OnHold" />
                      <Picker.Item label="Cancel" value="Cancel" />
                    </Picker>
                  </View>
                </View>
              </View>
              <View style={GLOBALSTYLES.lebalView}>
                <Text style={GLOBALSTYLES.lebal}>Receive Que?</Text>
                <View style={GLOBALSTYLES.contentView}>
                  <Text style={GLOBALSTYLES.content}>
                    {item.receive_question === null
                      ? '-'
                      : item.receive_question}
                  </Text>
                </View>
              </View>

              <View style={{flexDirection: 'row', margin: 10}}>
                <TouchableOpacity
                  style={GLOBALSTYLES.editBtn}
                  onPress={() =>
                    navigation.navigate('Edit External Interview', {
                      newData: item,
                    })
                  }>
                  <Text style={GLOBALSTYLES.editText}>Edit</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => handleDelete(item)}
                  style={GLOBALSTYLES.deleteBtn}>
                  <Text style={GLOBALSTYLES.deleteText}>Delete</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}
        />
      )}
    </SafeAreaView>
  );
};

export default InternalInterviewReport;
