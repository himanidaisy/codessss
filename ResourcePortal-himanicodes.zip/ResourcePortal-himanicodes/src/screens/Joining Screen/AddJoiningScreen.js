import React, {useState, useEffect} from 'react';
import {
  Text,
  View,
  SafeAreaView,
  TouchableOpacity,
  TextInput,
  ToastAndroid,
  Dimensions,
} from 'react-native';
import CustomNavigationBar from '../../components/CustomNavigationBar';
import {COLORS, FONTS, GLOBALSTYLES} from '../../constants/theme';

import {Picker} from '@react-native-picker/picker';
import axios from 'axios';
import DatePicker from 'react-native-datepicker';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import {URL} from '../../constants/configure';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {ScrollView} from 'react-native-gesture-handler';
const {height, width} = Dimensions.get('window');

const AddJoiningScreen = ({navigation}) => {
  const [newData, setNewData] = useState([]);
  const [clientid, setclientid] = useState('');
  const [resourceid, setresourceid] = useState('');
  const [startdate, setstartdate] = useState('');
  const [enddate, setenddate] = useState('');
  const [cperiod, setcperiod] = useState('');
  const [doinvoice, setdoinvoice] = useState('');
  const [contractype, setcontractype] = useState('');
  const [deleted, setdeleted] = useState('');
  const [address, setaddress] = useState('');
  const [createdat, setcreatedat] = useState('');

  const [updatedat, setupdatedat] = useState('');
  const [amail, setamail] = useState('');
  const [rmail, setrmail] = useState('');
  const [geomail, setgeomail] = useState('');
  const [adminmail, setadminmail] = useState('');
  const [hmail, sethmail] = useState('');
  const [remail, setremail] = useState('');
  const clientsOptions = newData.filter(t => t.client_name !== null);
  useEffect(() => {
    getResource();
  }, []);

  const getResource = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const requestOptions = {
        method: 'GET',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };
      console.log(requestOptions);
      const data = await axios.get(URL.BASE_URL + '/joining', requestOptions);

      // console.log(data.data.data.resources);

      setNewData(data.data.data.joining);
    } catch (error) {
      console.log(error);
    }
  };
  const postUser = async () => {
    const store = {
      client_id: clientid,
      resource_id: resourceid,
      start_date: startdate,
      end_date: enddate,
      credit_period: cperiod,
      date_of_invoice: doinvoice,
      contract_type: contractype,
      deleted: deleted,
      address: address,
      created_at: createdat,
      updated_at: updatedat,
      account_mail: amail,
      resource_mail: rmail,
      geofence_mail: geomail,
      admin_mail: adminmail,
      hr_mail: hmail,
      resources_email: remail,
    };

    // console.log('checkv--------', store);
    try {
      const token = await AsyncStorage.getItem('token');

      const requestOptions = {
        method: 'POST',
        Accept: 'application/json',
        'Content-Type': 'application/json',
        headers: {Authorization: 'Bearer ' + token},
      };

      const {data} = await axios.post(
        URL.BASE_URL + '/joining',
        store,
        requestOptions,
      );

      // console.log('valuecheck------------->',data);
      if (data.message) {
        ToastAndroid.showWithGravity(
          ' Joining added successfully',
          ToastAndroid.SHORT,
          ToastAndroid.BOTTOM,
        );
      }
      navigation.goBack();
    } catch (err) {
      // console.log(err.response)
      ToastAndroid.showWithGravity(
        'Joining not Added',
        ToastAndroid.SHORT,
        ToastAndroid.BOTTOM,
      );
    }
  };

  return (
    <SafeAreaView style={GLOBALSTYLES.mainContainer}>
      <CustomNavigationBar back={true} headername="Add Joining" />
      <ScrollView>
        <View>
          <View
            style={{
              width: width - 40,
              height: height / 14,
              margin: 5,
              marginStart: 20,
              backgroundColor: COLORS.pureWhite,
              borderRadius: 10,
              marginTop: 10,
            }}>
            <Picker
              selectedValue={resourceid}
              style={{margin: 4, bottom: 0}}
              mode="dropdown"
              onValueChange={value => {
                setresourceid(value);
              }}>
              <Picker.Item label="Select Resources" value="" color="grey" />
              {clientsOptions.map((item, index) => (
                <Picker.Item
                  key={item.id}
                  label={item.resource_id}
                  value={item.id}
                />
              ))}
            </Picker>
          </View>
          <View
            style={{
              width: width - 40,
              height: height / 14,
              margin: 5,
              flexDirection: 'row',
              backgroundColor: COLORS.pureWhite,
              marginStart: 20,
              borderRadius: 10,
            }}>
            <View
              style={{
                justifyContent: 'center',
                borderRadius: 10,
                padding: 10,

                backgroundColor: COLORS.whiteBlue,
              }}>
              <MaterialCommunityIcons
                color={COLORS.lightBlue}
                name="email-outline"
                size={30}
                style={{right: 12, marginStart: 25}}
              />
            </View>
            <TextInput
              placeholder="Email Id*"
              style={GLOBALSTYLES.textInput}
              value={remail}
              keyboardType="default"
            />
          </View>
          <View
            style={{
              width: width - 40,
              height: height / 14,
              margin: 5,
              marginStart: 20,
              backgroundColor: COLORS.pureWhite,
              borderRadius: 10,
              marginTop: 5,
            }}>
            <Picker
              selectedValue={clientid}
              style={{margin: 4, bottom: 0}}
              mode="dropdown"
              onValueChange={value => {
                setclientid(value);
              }}>
              <Picker.Item label="Select Client" value="" color="grey" />
              {clientsOptions.map((item, index) => (
                <Picker.Item
                  key={item.id}
                  label={item.client_id}
                  value={item.id}
                />
              ))}
            </Picker>
          </View>
          <View style={GLOBALSTYLES.textInputView}>
            <TextInput
              placeholder="Reporting Manager Name"
              style={GLOBALSTYLES.textInput}
              value={name}
              maxLength={20}
            />
          </View>
          <View
            style={{
              width: width - 40,
              height: height / 14,
              margin: 5,
              flexDirection: 'row',
              backgroundColor: COLORS.pureWhite,
              marginStart: 20,
              borderRadius: 10,
            }}>
            <View
              style={{
                justifyContent: 'center',
                borderRadius: 10,
                padding: 10,

                backgroundColor: COLORS.whiteBlue,
              }}>
              <MaterialCommunityIcons
                color={COLORS.lightBlue}
                name="email-outline"
                size={30}
                style={{right: 12, marginStart: 25}}
              />
            </View>
            <TextInput
              placeholder="Email Id*"
              style={GLOBALSTYLES.textInput}
              value={email}
              keyboardType="default"
            />
          </View>
          <View
            style={{
              width: width - 40,
              height: height / 14,
              margin: 5,
              flexDirection: 'row',
              backgroundColor: COLORS.pureWhite,
              marginStart: 20,
              borderRadius: 10,
            }}>
            <View
              style={{
                justifyContent: 'center',
                borderRadius: 10,
                padding: 15,
                backgroundColor: COLORS.whiteBlue,
              }}>
              <FontAwesome
                color={COLORS.lightBlue}
                name="phone"
                size={25}
                style={{right: 10, marginStart: 25}}
              />
            </View>
            <TextInput
              placeholder="Phone Number*"
              style={GLOBALSTYLES.textInput}
              value={phone}
              keyboardType="default"
            />
          </View>
          <View
            style={{
              width: width - 40,
              height: height / 14,
              margin: 5,
              marginStart: 20,
              backgroundColor: COLORS.pureWhite,
              borderRadius: 10,
              marginTop: 5,
            }}>
            <Picker
              selectedValue={contractype}
              style={{margin: 4, bottom: 0}}
              mode="dropdown"
              onValueChange={value => {
                setcontractype(value);
              }}>
              <Picker.Item label="Contract Type" value="" color="grey" />
              {clientsOptions.map((item, index) => (
                <Picker.Item
                  key={item.id}
                  label={item.contract_type}
                  value={item.id}
                />
              ))}
            </Picker>
          </View>
          <View
            style={{
              width: width - 50,
              height: height / 14,
              margin: 5,
              flexDirection: 'row',
              justifyContent: 'space-between',
              backgroundColor: COLORS.pureWhite,
              marginStart: 25,
              borderRadius: 10,
            }}>
            <DatePicker
              style={{width: '100%', top: 7}}
              date={startdate}
              value={startdate}
              mode="date"
              placeholder="Start Date"
              format="DD MMMM YYYY"
              minDate="01 01 2016"
              maxDate="01 01 2025"
              confirmBtnText="Confirm"
              cancelBtnText="Cancel"
              showIcon={false}
              customStyles={{
                dateInput: {
                  borderWidth: 0,

                  position: 'absolute',
                  left: 20,
                  ...FONTS.appFontSemiBold,
                },
              }}
              onDateChange={date => {
                setstartdate(date);
              }}
            />
            <FontAwesome
              name="calendar-o"
              size={20}
              style={{alignSelf: 'center', right: 50}}
            />
          </View>
          <View
            style={{
              width: width - 50,
              height: height / 14,
              margin: 5,
              flexDirection: 'row',
              justifyContent: 'space-between',
              backgroundColor: COLORS.pureWhite,
              marginStart: 25,
              borderRadius: 10,
            }}>
            <DatePicker
              style={{width: '100%', top: 7}}
              date={enddate}
              value={enddate}
              mode="date"
              placeholder="Tentative End Date"
              format="DD MMMM YYYY"
              minDate="01 01 2016"
              maxDate="01 01 2025"
              confirmBtnText="Confirm"
              cancelBtnText="Cancel"
              showIcon={false}
              customStyles={{
                dateInput: {
                  borderWidth: 0,

                  position: 'absolute',
                  left: 20,
                  ...FONTS.appFontSemiBold,
                },
              }}
              onDateChange={date => {
                setenddate(date);
              }}
            />
            <FontAwesome
              name="calendar-o"
              size={20}
              style={{alignSelf: 'center', right: 50}}
            />
          </View>

          <View style={GLOBALSTYLES.textInputView}>
            <TextInput
              placeholder="Address"
              style={GLOBALSTYLES.textInput}
              value={address}
              maxLength={20}
            />
          </View>
          <TouchableOpacity
            style={{
              backgroundColor: COLORS.skyBlue,
              width: width - 40,
              padding: 10,
              borderRadius: 10,
              alignSelf: 'center',
              bottom: 0,
              position: 'relative',
              margin: 20,
            }}
            onPress={() => postUser()}>
            <Text style={GLOBALSTYLES.textStyle}>Submit</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};
export default AddJoiningScreen;
