import React from 'react';
import AntDesign from 'react-native-vector-icons/AntDesign';
// import Fontisto from 'react-native-vector-icons/Fontisto'
import {createDrawerNavigator} from '@react-navigation/drawer';
import ResourceMaster from '../screens/Resource/ResourceMaster';
import ExternalResourcesMaster from '../screens/External Resources/ExternalResourcesMaster';
import TechnologyMaster from '../screens/Technology Master/TechnologyMaster';
import InvoiceHistory from '../screens/InvoiceHistory';
import InvoiceStatus from '../screens/Invoice Status/InvoiceStatus';
import CompareReport from '../screens/Compare Report/CompareReport';
import ProjectTarget from '../screens/ProjectTarget/ProjectTarget';
import ExternalProductMaster from '../screens/External Product/ExternalProductMaster';
import PurchaseOrderMaster from '../screens/Purchase Order/PurchaseOrderMaster';
import ClientAgreementMaster from '../screens/Client Agreement Master/ClientAgreementMaster';
import AccountMaster from '../screens/Account Master/AccountMaster';
import Vendor from '../screens/Vendor Master/Vendor';
import Home from '../screens/Home Screen/Home';
import Login from '../screens/Login';
import {StatusBar} from 'react-native';
import UserSetting from '../screens/User Setting/UserSetting';
import ClientRequest from '../screens/Client Request/ClientRequest';
import AddUserSetting from '../screens/User Setting/AddUserSetting';
import ClientMaster from '../screens/Client Master/ClientMaster';
import Setting from '../screens/Setting Master/Setting';
import Interview from '../screens/Interview/Interview';
import JoiningScreen from '../screens/Joining Screen/JoiningScreen';
import LeavingScreen from '../screens/Leaving Screen/LeavingScreen';
import NonJoiningScreen from '../screens/NonJoining Screen/NonJoining';
import AllInterview from '../screens/All Interview/AllInterview';
import ExternalInterview from '../screens/External Interview/ExternalInterview';
import ExternalInterviewReport from '../screens/External Interview Report/ExternalInterviewReport';
import InternalInterviewReport from '../screens/Internal Interview Report/InternalInterviewReport';
const Drawer = createDrawerNavigator();

const DrawerNav = ({navigation}) => {
  return (
    <Drawer.Navigator initialRouteName="LoginScreen">
      <Drawer.Screen
        name="LoginScreen"
        component={Login}
        options={{headerShown: true, headerTitleAlign: 'center'}}
      />
      <Drawer.Screen
        name="HomeScreen"
        component={Home}
        options={{headerShown: true, headerTitleAlign: 'center'}}
      />
      <Drawer.Screen
        name="InvoiceHistory"
        component={InvoiceHistory}
        options={{headerShown: true, headerTitleAlign: 'center'}}
      />
      <Drawer.Screen
        name="InvoiceStatus"
        component={InvoiceStatus}
        options={{headerShown: true, headerTitleAlign: 'center'}}
      />
      <Drawer.Screen
        name="Compare Report"
        component={CompareReport}
        options={{
          headerShown: true,
          headerTitleAlign: 'center',
          headerTitleAlign: 'center',
        }}
      />
      <Drawer.Screen
        name="ProjectTarget"
        component={ProjectTarget}
        options={{
          headerShown: true,
          headerTitleAlign: 'center',
          headerRight: () => (
            <AntDesign
              name="plus"
              size={25}
              color="black"
              style={{marginTop: '5%', marginEnd: '10%', fontWeight: 'bold'}}
              onPress={() => navigation.navigate('AddProjectScreen')}
            />
          ),
        }}
      />
      <Drawer.Screen
        name="Resource Master"
        component={ResourceMaster}
        options={{
          headerShown: true,
          headerTitleAlign: 'center',
          headerRight: () => (
            <AntDesign
              name="plus"
              size={25}
              color="black"
              style={{marginEnd: '10%', marginTop: '5%', fontWeight: 'bold'}}
              onPress={() => navigation.navigate('Add Resource')}
            />
          ),
        }}
      />
      <Drawer.Screen
        name="External Resources Master"
        component={ExternalResourcesMaster}
        options={{
          headerShown: true,
          headerTitleAlign: 'center',
          headerRight: () => (
            <AntDesign
              name="plus"
              size={25}
              color="black"
              style={{marginEnd: '10%', marginTop: '5%', fontWeight: 'bold'}}
              onPress={() => navigation.navigate('Add External Resource')}
            />
          ),
        }}
      />
      <Drawer.Screen
        name="Interview"
        component={Interview}
        options={{
          headerShown: true,
          headerTitleAlign: 'center',
          headerRight: () => (
            <AntDesign
              name="plus"
              size={25}
              color="black"
              style={{marginEnd: '10%', marginTop: '5%', fontWeight: 'bold'}}
              onPress={() => navigation.navigate('Add Interview')}
            />
          ),
        }}
      />
      <Drawer.Screen
        name="External Interview"
        component={ExternalInterview}
        options={{
          headerShown: true,
          headerTitleAlign: 'center',
          headerRight: () => (
            <AntDesign
              name="plus"
              size={25}
              color="black"
              style={{marginEnd: '10%', marginTop: '5%', fontWeight: 'bold'}}
              onPress={() => navigation.navigate('Add External Interview')}
            />
          ),
        }}
      />
      <Drawer.Screen
        name="External Interview Report"
        component={ExternalInterviewReport}
        options={{
          headerShown: true,
          headerTitleAlign: 'center',
          headerRight: () => (
            <AntDesign
              name="plus"
              size={25}
              color="black"
              style={{marginEnd: '10%', marginTop: '5%', fontWeight: 'bold'}}
              //onPress={() => navigation.navigate('Add External Interview')}
            />
          ),
        }}
      />
      <Drawer.Screen
        name="Internal Interview Report"
        component={InternalInterviewReport}
        options={{
          headerShown: true,
          headerTitleAlign: 'center',
          headerRight: () => (
            <AntDesign
              name="plus"
              size={25}
              color="black"
              style={{marginEnd: '10%', marginTop: '5%', fontWeight: 'bold'}}
              //onPress={() => navigation.navigate('Add External Interview')}
            />
          ),
        }}
      />
      <Drawer.Screen
        name="All Interview"
        component={AllInterview}
        options={{
          headerShown: true,
          headerTitleAlign: 'center',
          headerRight: () => (
            <AntDesign
              name="plus"
              size={25}
              color="black"
              style={{marginEnd: '10%', marginTop: '5%', fontWeight: 'bold'}}
              onPress={() => navigation.navigate('Add All Interview')}
            />
          ),
        }}
      />
      <Drawer.Screen
        name="Joining Screen"
        component={JoiningScreen}
        options={{
          headerShown: true,
          headerTitleAlign: 'center',
          headerRight: () => (
            <AntDesign
              name="plus"
              size={25}
              color="black"
              style={{marginEnd: '10%', marginTop: '5%', fontWeight: 'bold'}}
              onPress={() => navigation.navigate('Add Joining Screen')}
            />
          ),
        }}
      />
      <Drawer.Screen
        name="Leaving Screen"
        component={LeavingScreen}
        options={{
          headerShown: true,
          headerTitleAlign: 'center',
          headerRight: () => (
            <AntDesign
              name="plus"
              size={25}
              color="black"
              style={{marginEnd: '10%', marginTop: '5%', fontWeight: 'bold'}}
              onPress={() => navigation.navigate('Add Leaving Screen')}
            />
          ),
        }}
      />
      <Drawer.Screen
        name="NonJoining Screen"
        component={NonJoiningScreen}
        options={{
          headerShown: true,
          headerTitleAlign: 'center',
          headerRight: () => (
            <AntDesign
              name="plus"
              size={25}
              color="black"
              style={{marginEnd: '10%', marginTop: '5%', fontWeight: 'bold'}}
              onPress={() => navigation.navigate('Add NonJoining')}
            />
          ),
        }}
      />
      <Drawer.Screen
        name="External Product Master"
        component={ExternalProductMaster}
        options={{
          headerShown: true,
          swipeEnabled: true,
          headerTitleAlign: 'center',
          headerRight: () => (
            <AntDesign
              name="plus"
              size={25}
              color="black"
              style={{marginEnd: '10%', marginTop: '5%', fontWeight: 'bold'}}
              onPress={() => navigation.navigate('Add External Product')}
            />
          ),
        }}
      />
      <Drawer.Screen
        name="Purchase Order Master"
        component={PurchaseOrderMaster}
        options={{
          headerShown: true,
          headerTitleAlign: 'center',
          headerRight: () => (
            <AntDesign
              name="plus"
              size={25}
              color="black"
              style={{marginEnd: '10%', marginTop: '5%', fontWeight: 'bold'}}
              onPress={() => navigation.navigate('Add Purchase Order')}
            />
          ),
        }}
      />
      <Drawer.Screen
        name="Client Agreement Master"
        component={ClientAgreementMaster}
        options={{
          headerShown: true,
          headerTitleAlign: 'center',
          headerRight: () => (
            <AntDesign
              name="plus"
              size={25}
              color="black"
              style={{marginEnd: '10%', marginTop: '5%', fontWeight: 'bold'}}
              onPress={() => navigation.navigate('AddClientAgreementScreen')}
            />
          ),
        }}
      />
      <Drawer.Screen
        name="Account Master"
        component={AccountMaster}
        options={{
          headerShown: true,
          headerTitleAlign: 'center',
          headerRight: () => (
            <AntDesign
              name="plus"
              size={25}
              color="black"
              style={{marginEnd: '10%', marginTop: '5%', fontWeight: 'bold'}}
              onPress={() => navigation.navigate('AddAccountantScreen')}
            />
          ),
        }}
      />
      <Drawer.Screen
        name="Technology Master"
        component={TechnologyMaster}
        options={{
          headerShown: true,
          headerTitleAlign: 'center',
          headerRight: () => (
            <AntDesign
              name="plus"
              size={25}
              color="black"
              style={{marginEnd: '10%', marginTop: '5%', fontWeight: 'bold'}}
              onPress={() => navigation.navigate('AddTechnologyScreen')}
            />
          ),
        }}
      />
      <Drawer.Screen
        name="Vendor Master"
        component={Vendor}
        options={{
          headerShown: true,
          headerTitleAlign: 'center',
          headerRight: () => (
            <AntDesign
              name="plus"
              size={25}
              color="black"
              style={{marginEnd: '10%', marginTop: '5%', fontWeight: 'bold'}}
              onPress={() => navigation.navigate('AddVendor')}
            />
          ),
        }}
      />
      <Drawer.Screen
        name="User Setting"
        component={UserSetting}
        options={{
          headerShown: true,
          headerTitleAlign: 'center',
          headerRight: () => (
            <AntDesign
              name="plus"
              size={25}
              color="black"
              style={{marginEnd: '10%', marginTop: '5%', fontWeight: 'bold'}}
              onPress={() => navigation.navigate('Add UserSetting')}
            />
          ),
        }}
      />
      <Drawer.Screen
        name="Client Request"
        component={ClientRequest}
        options={{
          headerShown: true,
          headerTitleAlign: 'center',
          headerRight: () => (
            <AntDesign
              // name={'plus'}
              size={25}
              color="black"
              style={{marginEnd: '10%', marginTop: '5%', fontWeight: 'bold'}}
            />
          ),
        }}
      />
      <Drawer.Screen
        name="Client Master"
        component={ClientMaster}
        options={{
          headerShown: true,
          headerTitleAlign: 'center',
          headerRight: () => (
            <AntDesign
              name={'plus'}
              size={25}
              color="black"
              style={{marginEnd: '10%', marginTop: '5%', fontWeight: 'bold'}}
              onPress={() => navigation.navigate('Add Client')}
            />
          ),
        }}
      />
      <Drawer.Screen
        name="Setting Master"
        component={Setting}
        options={{
          headerShown: true,
          headerTitleAlign: 'center',
          headerTitleAlign: 'center',
        }}
      />
    </Drawer.Navigator>
  );
};

export default DrawerNav;
